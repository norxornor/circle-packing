"""C0: rational bounds for the common outward/angle reductions of the paper."""
from fractions import Fraction as F
from pathlib import Path
from math import isqrt
import importlib.util
if not __debug__:raise RuntimeError('Assertions must be enabled.')
HERE=Path(__file__).resolve().parent
Q=10**45
def sqrt_bounds(x):
    a=isqrt(x.numerator*Q*Q//x.denominator)
    lo,hi=F(a,Q),F(a+1,Q)
    assert lo*lo<=x<=hi*hi
    return lo,hi
def atan_bounds(x):
    lo=sum(((-1)**j*x**(2*j+1)/F(2*j+1) for j in range(40)),F(0))
    return lo,lo+x**81/81
alo,ahi=atan_bounds(F(1,5));blo,bhi=atan_bounds(F(1,239))
PILO=16*alo-4*bhi;PIHI=16*ahi-4*blo
assert F('3.141592653589793238')<PILO<PIHI<F('3.141592653589793239')<F(355,113)
def sin_bound(x,degree):
    assert 0<=x<=F(355,113)
    t=x;s=t
    for j in range(1,(degree+1)//2):t*=-x*x/F(2*j*(2*j+1));s+=t
    return s
def cos_lower(x):
    assert 0<=x<=F(355,113)
    t=F(1);s=t
    for j in range(1,14):t*=-x*x/F((2*j-1)*2*j);s+=t
    return s
def load(name,filename):
    spec=importlib.util.spec_from_file_location(name,HERE/filename)
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
c16=load('constant16','n16/certify_construction16.py')
c17=load('constant17','n17/verify17_exact.py')
c20=load('constant20','n20/verify20_exact.py')
s5=sqrt_bounds(F(5));tlo,thi=sqrt_bounds(1+2/s5[1])[0],sqrt_bounds(1+2/s5[0])[1]
B15=(sqrt_bounds((tlo+2)**2+1)[0],sqrt_bounds((thi+2)**2+1)[1])
B18=(sqrt_bounds(F(2))[0]+sqrt_bounds(F(6))[0],sqrt_bounds(F(2))[1]+sqrt_bounds(F(6))[1])
brackets={15:B15,16:(F(c16.BL),F(c16.BH)),17:(F(c17.LO),F(c17.HI)),18:B18,20:(F(c20.LO),F(c20.HI))}
ROWS=[
 (15,'3.5213569','3.521357','2.386','1.64','.287943','.287944',10,7),
 (16,'3.615425','3.615426','2.510','1.7','.280246539','.280246620',11,7),
 (17,'3.792033','3.792034','2.738','1.9','.266867080','.266867153',11,8),
 (18,'3.863703305','3.863703306','2.828428','1.9999999','.261799387740','.261799387810',12,8),
 (20,'4.122320736','4.122320737','3.151994','2.26714','.245026263334','.245026263395',12,9)]
for n,bl,bh,C,e,el,eh,mcap,auxcap in ROWS:
    bl,bh,C,e,el,eh=map(F,(bl,bh,C,e,el,eh))
    rootlo,roothi=brackets[n]
    assert bl<rootlo<=roothi<bh
    assert bh-4/bh<C and C*C<bl*bl-4
    assert e<sqrt_bounds(bl*bl-1)[0]-sqrt_bounds(F(3))[1]
    assert sin_bound(el,25)<1/bh and sin_bound(eh,27)>1/bl
    assert (mcap+1)*el>PIHI
    assert C*sin_bound(PIHI/F(auxcap+1),25)<1
    d=C-4/C
    if n in (15,16):assert d<1
    if n==17:assert d*d<2
    if n==18:assert d<F(3,2) and 2*F(3,2)**2*(1-cos_lower(2*PIHI/5))<4
    if n==20:assert d<2
    a0=1-2/bl**2
    assert all(r*r+s*s-2*r*s*a0<4 for r in [e,C] for s in [e,C])
    print('C0',n,'PASS: root enclosure, angle bounds, capacity, monotonicity, and four corners')
print('C0 ALL CONSTANTS PASSED')
