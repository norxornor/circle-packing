"""C0: shared geometric data of Appendix A (Tables 14-17) and the preliminary
counts of Sections 7.2, 8.2, 9.2, 10.2 and 11.2.

For every case this checks, with exact rational arithmetic:
  * Table 14 / (A.1): b- < b_N < b+, c(b_N) < c+, c+^2 < b-^2 - 4, r*- < r*(b_N),
    and the remaining hypotheses of Lemma 2.6 and (4.7): 2 < b-, c+ < b-,
    r*(b_N) < c(b_N), and the four corner inequalities (2.14);
  * Table 15: eta- < eta(b_N) < eta+;
  * Table 16: every column, i.e. the outer bound (2.8), the two layers of
    Lemma 2.8 (nu, mu and the small-disk condition (2.17));
  * Table 17 coverage: the excluded inner counts, the counts treated by the
    full-order computations and the analytic m = 12 case for N = 18 together
    are exactly all counts permitted by Table 16;
  * the constants hard-coded in the inner-count programs and in the n17/n20
    angle validators equal the values printed in the paper.
"""
from fractions import Fraction as F
from pathlib import Path
from math import isqrt
import importlib.util
import sys
if not __debug__:raise RuntimeError('Assertions must be enabled.')
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from exact_arithmetic import check_alternating_tail
Q=10**45
def sqrt_bounds(x):
    a=isqrt(x.numerator*Q*Q//x.denominator)
    lo,hi=F(a,Q),F(a+1,Q)
    assert lo*lo<=x<=hi*hi
    return lo,hi
def atan_bounds(x):
    lo=sum(((-1)**j*x**(2*j+1)/F(2*j+1) for j in range(40)),F(0))
    return lo,lo+x**81/81
alo,ahi=atan_bounds(F(1,5));blo,bhi=atan_bounds(F(1,239))
PILO=16*alo-4*bhi;PIHI=16*ahi-4*blo
assert F('3.141592653589793238')<PILO<PIHI<F('3.141592653589793239')<F(355,113)
for degree in (25,26,27):check_alternating_tail(degree)
def sin_bound(x,degree):
    """Degree 25 ends with a positive term (upper bound); degree 27 with a
    negative term (lower bound), Appendix B.2."""
    assert 0<=x<=F(355,113)
    t=x;s=t
    for j in range(1,(degree+1)//2):t*=-x*x/F(2*j*(2*j+1));s+=t
    return s
def cos_lower(x):
    assert 0<=x<=F(355,113)
    t=F(1);s=t
    for j in range(1,14):t*=-x*x/F((2*j-1)*2*j);s+=t
    return s
def load(name,filename):
    spec=importlib.util.spec_from_file_location(name,HERE/filename)
    m=importlib.util.module_from_spec(spec)
    sys.path.insert(0,str((HERE/filename).parent))
    spec.loader.exec_module(m);return m

# Table 14 (b-, b+, c+, r*-), Table 15 (eta-, eta+), Table 16 (nu-1, mu-1,
# k at most, m at most, permitted m) and Table 17 (excluded k).
TABLE14={15:('3.5213569','3.521357','2.386','1.64'),
         16:('3.615425','3.615426','2.510','1.7'),
         17:('3.792033','3.792034','2.738','1.9'),
         18:('3.863703305','3.863703306','2.828428','1.9999999'),
         20:('4.122320736','4.122320737','3.151994','2.26714')}
TABLE15={15:('.287943','.287944'),16:('.280246539','.280246620'),
         17:('.266867080','.266867153'),18:('.261799387740','.261799387810'),
         20:('.245026263334','.245026263395')}
TABLE16={15:(7,1,8,10,(7,10)),16:(7,1,8,11,(8,11)),17:(8,3,11,11,(6,11)),
         18:(8,4,12,12,(6,12)),20:(9,5,14,12,(6,12))}
EXCLUDED={15:[6,7,8],16:[6,7,8],17:[8,9,10,11],18:[9,10,11,12],20:[9,10,11,12,13,14]}
# Remaining counts and where they are treated in the paper.
ORDER_SEARCH={15:[5],16:[5],17:[6,7],18:[7,8],20:[8]}   # Props 7.4, 8.4, 9.4, 10.4, 11.4
ANALYTIC={18:[6]}                                       # m = 12, Section 10.2

def brackets():
    c16=load('constant16','n16/certify_construction16.py')
    c17=load('constant17','n17/verify17_exact.py')
    c20=load('constant20','n20/verify20_exact.py')
    s5=sqrt_bounds(F(5));tlo,thi=sqrt_bounds(1+2/s5[1])[0],sqrt_bounds(1+2/s5[0])[1]
    b15=(sqrt_bounds((tlo+2)**2+1)[0],sqrt_bounds((thi+2)**2+1)[1])
    b18=(sqrt_bounds(F(2))[0]+sqrt_bounds(F(6))[0],sqrt_bounds(F(2))[1]+sqrt_bounds(F(6))[1])
    return {15:b15,16:(F(c16.BL),F(c16.BH)),17:(F(c17.LO),F(c17.HI)),18:b18,20:(F(c20.LO),F(c20.HI))}

def check_case(n,root):
    bl,bh,C,e=map(F,TABLE14[n]);el,eh=map(F,TABLE15[n])
    auxcap,inside,kmax,mmax,(mlo,mhi)=TABLE16[n]
    rootlo,roothi=root
    # (A.1) and the remaining hypotheses of Lemma 2.6 and (4.7).
    assert 2<bl<rootlo<=roothi<bh
    assert bh-4/bh<C                         # c(b_N) < c+ (c is increasing)
    assert C*C<bl*bl-4 and C<bl              # (4.7)
    rstar_lo=sqrt_bounds(bl*bl-1)[0]-sqrt_bounds(F(3))[1]
    rstar_hi=sqrt_bounds(bh*bh-1)[1]-sqrt_bounds(F(3))[0]
    assert 0<=e<rstar_lo                     # r*- < r*(b_N)  (r* is increasing)
    assert rstar_hi<bl-4/bl                  # r*(b_N) < c(b_N)
    a0=1-2/bl**2                             # cos(2 eta(b)) = 1-2/b^2 > 1-2/b-^2
    assert all(r*r+s*s-2*r*s*a0<4 for r in [e,C] for s in [e,C])   # (2.14)
    # Table 15: sin is increasing on these small angles.
    assert sin_bound(el,25)<1/bh and sin_bound(eh,27)>1/bl
    # Table 16, column 'm at most': (2.8) with (m_max+1) eta > pi.
    assert (mmax+1)*el>PIHI
    # Lemma 2.8 with nu = auxcap+1 and mu = inside+1.
    nu,mu=auxcap+1,inside+1
    assert C>2 and C*sin_bound(PIHI/nu,25)<1          # nu*arcsin(1/c+) > pi
    d=C-4/C
    assert 0<=d<2
    if mu==2:
        # The exact angle is pi. Its rational upper enclosure is beyond pi,
        # where cosine no longer decreases, so use 1-cos(pi)=2 directly.
        one_minus_cos=F(2)
    else:
        assert 0<2*PIHI/mu<PILO
        one_minus_cos=1-cos_lower(2*PIHI/mu)          # >= 1-cos(2pi/mu)
    assert max(d*d,2*d*d*one_minus_cos)<4             # (2.17)
    assert kmax==nu+mu-2
    # The specific forms printed in Sections 7.2-11.2 and Appendix A.3.
    if n in (15,16):assert d<1 and mu==2
    if n==17:assert d*d<2 and mu==4
    if n==18:assert d<F(3,2) and mu==5 and 2*F(3,2)**2*(1-cos_lower(2*PIHI/5))<4
    if n==20:assert d<2 and mu==6
    assert (mlo,mhi)==(n-kmax,mmax)
    # Table 17 coverage: every k in [n-m_max, k_max] is treated exactly once.
    treated=EXCLUDED[n]+ORDER_SEARCH[n]+ANALYTIC.get(n,[])
    assert sorted(treated)==list(range(n-mmax,kmax+1)),(n,treated)
    return dict(bl=bl,bh=bh,C=C,e=e,el=el,eh=eh)

def check_program_constants(rows):
    """The constants typed into each inner-count program are Table 14/15 values."""
    files={15:'n15/inner_energy_certificate.py',16:'n16/energy16.py',17:'n17/energy17.py',
           18:'n18/energy18.py',20:'n20/energy20.py'}
    for n,file in files.items():
        m=load(f'energy_constants{n}',file);r=rows[n]
        assert (m.B_LO,m.B_HI,m.C,m.ETA_LO,m.ETA_HI)==(r['bl'],r['bh'],r['C'],r['el'],r['eh']),n
        assert m.EXCLUDED_K==EXCLUDED[n],n
    # The n17/n20 angle validators use the construction root brackets.
    for n,file,construction in [(17,'n17/validate_angles.py','n17/verify17_exact.py'),
                                (20,'n20/validate_angles.py','n20/verify20_exact.py')]:
        v=load(f'validator{n}',file);c=load(f'construction{n}',construction)
        assert (v.BLO,v.BHI)==(F(c.LO),F(c.HI)),n

def main():
    roots=brackets();rows={}
    for n in (15,16,17,18,20):
        rows[n]=check_case(n,roots[n])
        print('C0',n,'PASS: Table 14 hypotheses (A.1), Lemma 2.6 and (4.7); Table 15; Table 16 counts; Table 17 coverage')
    check_program_constants(rows)
    print('C0 program constants equal Tables 14 and 15; validator brackets equal construction brackets')
    print('C0 ALL CONSTANTS PASSED')
if __name__=='__main__':main()
