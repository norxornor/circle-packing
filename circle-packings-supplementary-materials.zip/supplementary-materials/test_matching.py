"""Compare the C++ acceptance predicates with a cyclic-word specification.
The oracle reverses complete inner/outer words instead of reindexing gaps.
"""
from pathlib import Path
from fractions import Fraction as F
import random,subprocess
ROOT=Path(__file__).resolve().parent
import tempfile
_temporary=tempfile.TemporaryDirectory(prefix='circle-matching-')
OUT=Path(_temporary.name)
RQ=2**40
if not __debug__:raise RuntimeError('Assertions must be enabled.')
random.seed(10102026)

def ceilq(x):return (F(x)*RQ).__ceil__()
def floorq(x):return (F(x)*RQ).__floor__()
def word(radii,gaps):
    out=[]
    for r,q in zip(radii,gaps):out+=[r]+[None]*q
    return out
def decode(w):
    start=next(i for i,x in enumerate(w) if x is not None)
    w=w[start:]+w[:start];r=[];q=[]
    for x in w:
        if x is None:q[-1]+=1
        else:r.append(x);q.append(0)
    return r,q
def images(w):
    for oriented in (w,list(reversed(w))):
        for i in range(len(w)):yield oriented[i:]+oriented[:i]
def oracle(n,rs,qs,templates):
    if n==17:
        if len(rs)!=7 or qs!=[0,1,2,2,2,2,1]:return False
        omitted=[None]
    else:omitted=list(range(len(rs)))
    full=word(list(enumerate(rs)),qs)
    for omitted_index in omitted:
        if n==18 and rs[omitted_index][1]*10**6>RQ:continue
        w=[None if x is None else x[1] for x in full if x is None or x[0]!=omitted_index]
        for template in templates:
            if len(w)!=len(template):continue
            for candidate in images(template):
                if all((x is None and y is None) or (x is not None and y is not None and
                        F(x[0],RQ)>=y[0] and F(x[1],RQ)<=y[1]) for x,y in zip(w,candidate)):
                    return True
    return False

specs={17:[(['.10925499699','2.54742230599','2.06840968290','1.94669000932','1.92575180443','1.94669000932','2.06840968290'],[0,1,2,2,2,2,1])],
       18:[([2]*6,[1,2,2,2,2,2]),(['c',2,2,2,2,2],[1,2,2,2,2,2]),
           (['c',2,2,2,2,2],[1,2,2,2,3,1]),(['c',2,2,2,2,2],[1,2,2,3,2,1]),
           (['c',2,'c',2,2,2,2],[1,1,1,2,2,2,1]),(['c',2,2,'c',2,2,2],[1,2,1,1,2,2,1])],
       20:[(['2.171529956399','2.805316132579','2.171529956399','2.193139842425','2.235344370918','2.235344370918','2.193139842425'],[1,1,2,2,2,2,2])]}
total=0
for n,rows in specs.items():
    source=OUT/f'match{n}.cpp';exe=source.with_suffix('')
    source.write_text('#define main original_main\n#include "'+str(ROOT/f'n{n}/radial_integer.cpp')+'"\n#undef main\nint main(){ while(std::cin>>K){ M=N-K; RadiusBox z{}; GapCounts p(K); for(int i=0;i<K;i++)std::cin>>z.lo[i]>>z.hi[i];for(int i=0;i<K;i++)std::cin>>p[i]; std::cout<<within_reference_ranges(z,p)<<"\\n"; }}\n')
    r=subprocess.run(['g++','-O2','-std=c++17','-fsanitize=undefined,bounds','-fno-sanitize-recover=all',str(source),'-o',str(exe)],capture_output=True,text=True)
    assert r.returncode==0,r.stderr
    templates=[]
    eps=F(1,{17:10**7,18:10**6,20:10**5}[n])
    for radii,gaps in rows:
        limits=[(F('2.828426124746191'),F('2.828428124746190')) if t=='c' else (F(t)-eps,F(t)+eps) for t in radii]
        templates.append(word(limits,gaps))
    cases=[]
    for template in templates:
        w=[None if x is None else (ceilq(x[0]),floorq(x[1])) for x in template]
        insertions=range(len(w)) if n!=17 else [None]
        for where in insertions:
            if n==17: inserted=w
            else:
                core=(0,RQ) if n==20 else (0,floorq(F(1,10**6)))
                inserted=w[:where]+[core]+w[where:]
            for variant in images(inserted):
                rs,qs=decode(variant)
                if n==17 and qs!=rows[0][1]:continue
                cases.append((rs,qs))
                # Force full containment to fail at each endpoint; an intersection is insufficient.
                for index in range(len(rs)):
                    changed=rs.copy();a,b=changed[index];changed[index]=(a-1,b)
                    if a>0:cases.append((changed,qs))
                    changed=rs.copy();a,b=changed[index];changed[index]=(a,b+1);cases.append((changed,qs))
        # Mutations of labels, gaps, and ranges supply negative as well as alternative valid cases.
    for _ in range(1500):
        rs,qs=random.choice(cases);rs=rs.copy();qs=qs.copy()
        a,b=random.sample(range(len(rs)),2)
        if random.randrange(2):rs[a],rs[b]=rs[b],rs[a]
        else:
            if qs[a]>0:qs[a]-=1;qs[b]+=1
        cases.append((rs,qs))
    cases=list(dict.fromkeys((tuple(rs),tuple(qs)) for rs,qs in cases))
    incoming=''.join(str(len(rs))+' '+' '.join(str(v) for pair in rs for v in pair)+' '+' '.join(map(str,qs))+'\n' for rs,qs in cases)
    result=subprocess.run([str(exe)],input=incoming,capture_output=True,text=True)
    assert result.returncode==0 and not result.stderr,result.stderr
    observed=list(map(int,result.stdout.split()));assert len(observed)==len(cases)
    accepted=0
    for (rs,qs),got in zip(cases,observed):
        expected=oracle(n,rs,list(qs),templates)
        assert got==expected,(n,rs,qs,got,expected)
        accepted+=got
    total+=len(cases)
    print(n,len(cases),'predicate comparisons,',accepted,'accepted: PASS',flush=True)
print('ALL',total,'CYCLIC-WORD COMPARISONS PASSED',flush=True)
