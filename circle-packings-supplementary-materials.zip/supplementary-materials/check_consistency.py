"""Check every count/position table row and the interval primitives.
The driver runs this after all case computations have completed.
"""
from pathlib import Path
from fractions import Fraction as F
import ast, importlib.util, random, re

if not __debug__: raise RuntimeError('Assertions must be enabled.')

ROOT=Path(__file__).resolve().parent
text=(ROOT/'verification-output.txt').read_text()
parts=dict((m.group(1),m.group(2)) for m in re.finditer(r'^=== ([^:]+):[^\n]*\n(.*?)(?=^=== |\Z)',text,re.M|re.S))
expected_energy=[(15,6,1819,394,516),(15,7,1149,242,333),(15,8,81,5,36),
 (16,6,1463,352,380),(16,7,2599,556,744),(16,8,817,114,295),
 (17,8,100475,23391,26847),(17,9,4585,481,1812),(17,10,1267,22,612),(17,11,777,0,389),
 (18,9,12733,1726,4641),(18,10,6281,463,2678),(18,11,2273,31,1106),(18,12,1035,0,518),
 (20,9,396147,82039,116035),(20,10,320407,51626,108578),(20,11,217719,26231,82629),
 (20,12,109203,9425,45177),(20,13,16371,270,7916),(20,14,3799,0,1900)]
for n,k,nodes,length,angular in expected_energy:
    if n!=20:
        m=re.search(r'CERTIFIED '+str(k)+r' energy (\{[^}]+\})',parts['E'+str(n)])
        d=ast.literal_eval(m[1]);assert (d['boxes'],d['energy'],d['angle'],d['pair'])==(nodes,length,angular,0)
    else:assert f'CERTIFIED k={k} nodes={nodes} energy={length} angular={angular} empty_radial=0' in parts['E20']
    assert nodes==2*(length+angular)-1
print('All 20 inner-count table rows agree exactly with the replay.')

groups={16:[([5,6],6313444,'22.760'),([9,10],2895618,'11.522'),([11],1606966,'7.285'),([1,2,3,4,7,8,12,13,14,15],1606966,'5.285')],
 17:[([10],2134475,'7.562'),([5],642620,'2.417'),([15,6,7,13,14],564969,'2.149'),([16,17],595888,'2.056'),([2,3,4,8,9,11,12],564969,'1.949')],
 20:[([5,6],25805253,'116.750'),([9,10],23929317,'109.717'),([14,15],21680556,'101.286'),([18],4023210,'35.084'),([2,3,4,7,8,12,13,16,17,19,20],4023210,'15.084')]}
inner={16:{5,6,9,10,11},17:{5,6,7,10,13,14,15},20:{5,6,9,10,14,15,18}}
bhi={16:F('3.61542559487319398553924416199196524760827792283368976231959231778348360154823159'),17:F('3.7920337483105791701491239534'),20:F('4.1223207369915283214476857923')}
eps={16:F(1,10**6),17:F(1,10**7),20:F(1,10**5)}
for n,rows in groups.items():
    widths={int(m[1]):int(m[2]) for m in re.finditer(r'point (\d+) relative-angle numerators: [-0-9]+ [-0-9]+ width numerator: ([-0-9]+)',parts['P'+str(n)])}
    assert len(widths)==(n if n!=20 else 19)
    assert min(widths.values())==0
    covered=set()
    for ids,bound,pos in rows:
        assert max(widths[i] for i in ids)<=bound
        assert max(widths[i] for i in ids)==bound,(n,ids,'printed value is not the group maximum')
        for i in ids:
            assert widths[i]>=0
            assert (2*eps[n] if i in inner[n] else 0)+bhi[n]*F(bound,2**40)<F(pos)/10**6
            covered.add(i)
    assert set(widths)-covered=={0 if n==16 else 1}
    assert F({16:'22.760',17:'7.562',20:'116.750'}[n])/10**6 < F(1,{16:10000,17:16000,20:8400}[n])
    print('All position-table rows and strict rigidity margins:',n,'PASS')

# Exercise every primitive on positive, negative, zero-crossing and exact-grid inputs.
# Expected rational ranges below are computed independently of each implementation.
random.seed(7312026)
sample=[F(x,7) for x in range(-20,21)]+[F(0),F(1),F(4),F(-1),F(1,10**90)]
cases=[tuple(sorted(random.sample(sample,2))) for _ in range(160)]
operations=0
for n,file in [(16,'certify_construction16.py'),(17,'verify17_exact.py'),(18,'exact18.py'),(20,'verify20_exact.py')]:
    spec=importlib.util.spec_from_file_location(f'arithmetic{n}',ROOT/f'n{n}'/file)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    I=module.I;scale=getattr(module,'Q',getattr(module,'D',None))
    def bounds(x):return F(getattr(x,'l',getattr(x,'lo',0)),scale),F(getattr(x,'h',getattr(x,'hi',0)),scale)
    def encloses(x,lo,hi):
        a,b=bounds(x);assert a<=lo<=hi<=b
        # Tight grid enclosure prevents a mistaken test that only allows huge errors.
        assert lo-a<F(1,scale) and b-hi<F(1,scale)
    for a,b in cases:
        x=I(a,b);encloses(x,a,b);a,b=bounds(x)
        encloses(-x,-b,-a)
        square=x.sq() if hasattr(x,'sq') else x.square()
        encloses(square,0 if a<=0<=b else min(a*a,b*b),max(a*a,b*b))
        if a>=0:
            lo,hi=bounds(x.sqrt());assert 0<=lo and lo*lo<=a<=b<=hi*hi
            assert (lo+F(1,scale))**2>a and (hi-F(1,scale))**2<b or a==b==0
        for c,d in cases[::16]:
            y=I(c,d);c,d=bounds(y)
            encloses(x+y,a+c,b+d);encloses(x-y,a-d,b-c)
            endpoints=[v*w for v in (a,b) for w in (c,d)]
            encloses(x*y,min(endpoints),max(endpoints))
            if c*d>0:
                endpoints=[v/w for v in (a,b) for w in (c,d)]
                encloses(x/y,min(endpoints),max(endpoints))
            else:
                try:x/y
                except AssertionError:pass
                else:raise AssertionError('division by zero-containing interval accepted')
            operations+=4
    print('Rational interval primitive sign, domain and rounding checks:',n,'PASS')
print('Arithmetic operation comparisons:',operations)
