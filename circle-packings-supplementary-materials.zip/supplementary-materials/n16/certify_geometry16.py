#!/usr/bin/env python3
"""Rigorous radical bounds supporting the n=16 radial reduction.
Conditional on exactly eleven projected boundary centers, proves inner radius
bounds and that at most one inner direction belongs to each boundary gap.
"""
from certify_construction16 import I, Q, BL, BH, dist2

if not __debug__:
    raise RuntimeError('Run without -O: assertions are part of this certificate.')

def constants(B):
    eta_cos=(B.sq()-1).sqrt()/B; eta_sin=1/B
    cs,sn=I(1),I(0)
    for _ in range(7): cs,sn=cs*eta_cos-sn*eta_sin,sn*eta_cos+cs*eta_sin
    # q=(pi-7 eta)/4. Positive square roots implement two half-angle formulas.
    cos2q=((1-cs)/2).sqrt(); cosq=((1+cos2q)/2).sqrt()
    sinq=((1-cos2q)/2).sqrt()
    cs2=1-2/B.sq(); sn2=2*(B.sq()-1).sqrt()/B.sq()
    x,y=I(0),-B
    for _ in range(5): x,y=cs2*x-sn2*y,sn2*x+cs2*y
    # A=pi-10 eta, hence (B cos A,B sin A)=(y,x).
    cosA,sinA=y/B,x/B
    u=y-(4-x.sq()).sqrt()
    st=B*cosq-(4-(B*sinq).sq()).sqrt()
    v=2-st
    c=B-4/B; E=(B.sq()-1).sqrt()-I(3).sqrt(); ell=B-2
    return dict(B=B,c=c,E=E,ell=ell,cosA=cosA,sinA=sinA,u=u,v=v,st=st,
                cosq=cosq,sinq=sinq,BcosA=y,BsinA=x)

def verify(verbose=True):
    z=constants(I(BL,BH)); B,c,E,ell,u,v=[z[k] for k in ('B','c','E','ell','u','v')]
    co,si=z['cosA'],z['sinA']; X,Y=z['BsinA'],z['BcosA']
    # B>csc(pi/10)=1+sqrt(5) gives eta<pi/10, so A>0.
    assert B.l>(1+I(5).sqrt()).h
    # eta>1/B>1/3.7; therefore 12eta>120/37>22/7>pi.
    assert B.h<I('3.7').l
    assert 120*7>22*37
    # Likewise 10eta>100/37>pi/2, and A<pi/2.
    assert 100*14>22*37
    # The interior disk contains at most eight separated points.
    assert (c-4/c).h<Q
    assert c.h<(4+2*I(2).sqrt()).sqrt().l  # c<csc(pi/8)
    # The arc nonoverlap and monotonicity hypotheses in the paper.
    assert (c.sq()-E.sq()).h<4*Q
    assert c.sq().h<(B.sq()-4).l
    assert 0<E.l<c.h<B.l
    # X>1 gives sin(10eta)>sin eta, hence 11eta<pi and S>0.
    assert X.l>Q
    assert z['st'].l>E.h and z['st'].h<c.l
    # Domain and branch checks for gap inversion and its enclosing polygon.
    assert 0<co.l<co.h<Q and 0<si.l<si.h<Q
    assert 0<v.l<u.h<Y.l
    assert (u*si).h<X.l and X.h<2*Q
    assert v.h<ell.l and ell.h<u.l
    assert E.h<u.l
    assert I('.242').h<v.l and v.h<I('.243').l
    assert I('1.811').h<u.l and u.h<I('1.812').l
    assert ell.h<E.l and u.h<c.l
    vertices=[(u,I(0)),(ell*co,ell*si),(v*co,v*si),(v*co,-v*si),(ell*co,-ell*si)]
    diam_upper=0
    for i in range(5):
        for j in range(i+1,5):
            d=dist2(vertices[i],vertices[j]); assert d.h<4*Q
            diam_upper=max(diam_upper,d.h)
    assert diam_upper<I('2.512607').l
    if verbose:
        print('n=16 geometric reduction bounds: PASS')
        for name in ('c','E','u','v','st','cosA','sinA'): print(name,z[name])
        print('Five-vertex enclosing polygon squared diameter upper bound:',I(diam_upper,diam_upper,raw=True))
        print('All five inner radii lie in [.242,1.812]; each outer gap contains at most one inner direction.')
        print('This certificate assumes that the projected configuration has eleven outer centers.')
    return z
if __name__=='__main__': verify()
