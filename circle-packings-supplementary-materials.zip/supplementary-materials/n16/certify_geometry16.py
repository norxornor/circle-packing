#!/usr/bin/env python3
"""Rigorous radical bounds supporting the n=16 radial reduction (Proposition 8.2).
Conditional on exactly eleven projected boundary centers, proves inner radius
bounds and that at most one inner direction belongs to each boundary gap.
"""
from certify_construction16 import I, Q, BL, BH, dist2
from fractions import Fraction
from pathlib import Path as _Path
import sys as _sys
_sys.path.insert(0, str(_Path(__file__).resolve().parents[1]))
from exact_arithmetic import sine_bounds

if not __debug__:
    raise RuntimeError('Run without -O: assertions are part of this certificate.')

def constants(B):
    eta_cos=(B.sq()-1).sqrt()/B; eta_sin=1/B
    cs,sn=I(1),I(0)
    for _ in range(7): cs,sn=cs*eta_cos-sn*eta_sin,sn*eta_cos+cs*eta_sin
    # q=(pi-7 eta)/4. Positive square roots implement two half-angle formulas.
    cos2q=((1-cs)/2).sqrt(); cosq=((1+cos2q)/2).sqrt()
    sinq=((1-cos2q)/2).sqrt()
    cs2=1-2/B.sq(); sn2=2*(B.sq()-1).sqrt()/B.sq()
    x,y=I(0),-B
    for _ in range(5): x,y=cs2*x-sn2*y,sn2*x+cs2*y
    # A=pi-10 eta, hence (B cos A,B sin A)=(y,x).
    cosA,sinA=y/B,x/B
    u=y-(4-x.sq()).sqrt()
    st=B*cosq-(4-(B*sinq).sq()).sqrt()
    v=2-st
    c=B-4/B; E=(B.sq()-1).sqrt()-I(3).sqrt(); ell=B-2
    return dict(B=B,c=c,E=E,ell=ell,cosA=cosA,sinA=sinA,u=u,v=v,st=st,
                cosq=cosq,sinq=sinq,BcosA=y,BsinA=x)

def pi_bounds():
    """Machin's identity with alternating arctangent tails (Appendix B.4)."""
    def atan_bounds(x):
        lo=sum(((-1)**j*x**(2*j+1)/Fraction(2*j+1) for j in range(20)),Fraction(0))
        return lo,lo+x**41/Fraction(41)
    a,b=atan_bounds(Fraction(1,5));c,d=atan_bounds(Fraction(1,239))
    return 16*a-4*d,16*b-4*c

def verify(verbose=True):
    """Proposition 8.2 for m = 11: the gap hypotheses (3.9), the bounds (8.7)
    and the vertex-distance bound of Lemma 3.4. The Lemma 2.6 / (4.7)
    hypotheses and the counts are checked in constants.py."""
    z=constants(I(BL,BH)); B,c,E,ell,u,v=[z[k] for k in ('B','c','E','ell','u','v')]
    co,si=z['cosA'],z['sinA']; X,Y=z['BsinA'],z['BcosA']
    pilo,pihi=pi_bounds()
    # eta(b) between the Table 15 values, for every b in the root bracket.
    eta_lo,eta_hi=Fraction('.280246539'),Fraction('.280246620')
    assert sine_bounds(eta_lo)[1]<Fraction(1)/Fraction(B.h,Q)
    assert sine_bounds(eta_hi)[0]>Fraction(1)/Fraction(B.l,Q)
    # The half-angle formulas in constants() use q = (pi-7eta)/4 in (0, pi/4).
    assert 7*eta_hi<pilo
    # (3.9) with m = 11, lambda = pi-11eta and omega = pi-10eta, one condition at a time.
    assert 11*eta_hi<pilo                                   # lambda_11 > 0
    assert 0<pilo-10*eta_hi and pihi-10*eta_lo<pilo/2       # 0 < omega_11 < pi/2
    assert 0<v.l and v.h<ell.l and ell.h<E.l and E.h<u.l and u.h<c.l   # 0 < v < l < r* < u < c
    assert z['st'].l>E.h and z['st'].h<c.l                  # r* < 2 - v < c  (st = 2 - v)
    assert u.h<Y.l                                          # u < b cos(omega)
    assert X.h<2*Q                                          # b sin(omega) < 2
    assert 0<co.l and 0<si.l                                # cos, sin of omega used for the vertices
    # (8.7)
    assert I('.242').h<v.l and v.h<I('.243').l
    assert I('1.811').h<u.l and u.h<I('1.812').l
    # Lemma 3.4: every squared distance between vertices of V_gap is below 2.512607 < 4.
    vertices=[(u,I(0)),(ell*co,ell*si),(v*co,v*si),(v*co,-v*si),(ell*co,-ell*si)]
    diam_upper=0
    for i in range(5):
        for j in range(i+1,5):
            d=dist2(vertices[i],vertices[j])
            diam_upper=max(diam_upper,d.h)
    assert diam_upper<I('2.512607').l and Fraction('2.512607')<4
    if verbose:
        print('n=16 geometric reduction bounds: PASS')
        for name in ('c','E','u','v','st','cosA','sinA'): print(name,z[name])
        print('Five-vertex enclosing polygon squared diameter upper bound:',I(diam_upper,diam_upper,raw=True))
        print('All five inner radii lie in [.242,1.812]; each outer gap contains at most one inner direction.')
        print('This certificate assumes that the projected configuration has eleven outer centers.')
    return z
if __name__=='__main__': verify()
