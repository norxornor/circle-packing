#!/usr/bin/env python3
"""Stdlib-only exact interval certificate for the n=16 candidate construction.
Checks construction feasibility (Proposition 8.1) and the distances used to
undo the projection (Proposition 8.7). Contact lists are compared with the
paper by label in check_reference_certificates.py.
The global exclusion and local determination are separate parts of the proof.
All enclosures use integer arithmetic rounded outwards on a 10^-80 grid.
"""
from fractions import Fraction

if not __debug__:
    raise RuntimeError('Run without -O: assertions are part of this certificate.')
from math import isqrt
Q=10**80
class I:
    __slots__=('l','h')
    def __init__(self,a,b=None,raw=False):
        if raw: self.l,self.h=a,b; return
        if isinstance(a,I): self.l,self.h=a.l,a.h; return
        a=Fraction(a); b=a if b is None else Fraction(b)
        self.l=a.numerator*Q//a.denominator
        self.h=-((-b.numerator*Q)//b.denominator)
    def __add__(a,b):
        b=I(b); return I(a.l+b.l,a.h+b.h,raw=True)
    __radd__=__add__
    def __neg__(a): return I(-a.h,-a.l,raw=True)
    def __sub__(a,b): return a+-I(b)
    def __rsub__(a,b): return I(b)+-a
    def __mul__(a,b):
        b=I(b); v=[a.l*b.l,a.l*b.h,a.h*b.l,a.h*b.h]
        return I(min(v)//Q,-((-max(v))//Q),raw=True)
    __rmul__=__mul__
    def __truediv__(a,b):
        b=I(b); assert b.l*b.h>0
        v=[Fraction(x*Q,y) for x in (a.l,a.h) for y in (b.l,b.h)]
        lo,hi=min(v),max(v)
        return I(lo.numerator//lo.denominator,-((-hi.numerator)//hi.denominator),raw=True)
    def __rtruediv__(a,b): return I(b)/a
    def sq(a):
        v=[a.l*a.l,a.h*a.h]
        low=0 if a.l<=0<=a.h else min(v)
        return I(low//Q,-((-max(v))//Q),raw=True)
    def sqrt(a):
        assert a.l>=0
        lo,hi=isqrt(a.l*Q),isqrt(a.h*Q)
        if hi*hi<a.h*Q: hi+=1
        return I(lo,hi,raw=True)
    def contains_zero(a): return a.l<=0<=a.h
    def __repr__(a):
        def dec(z):
            s='-' if z<0 else ''; z=abs(z)
            return s+str(z//Q)+'.'+str(z%Q).zfill(80)
        return '['+dec(a.l)+', '+dec(a.h)+']'
def dist2(p,q): return (p[0]-q[0]).sq()+(p[1]-q[1]).sq()
def positive_sqrt(value):
    # The paper uses continuity and derivatives of these radicals.
    # Certify the strict domain condition over the whole input interval.
    assert value.l > 0
    return value.sqrt()

def construction(B):
    # Q_k=(B sin(2 k eta), -B cos(2 k eta)); eta=asin(1/B).
    cs=1-2/B.sq(); sn=2*positive_sqrt(B.sq()-1)/B.sq()
    outer=[(I(0),-B)]
    for _ in range(5):
        x,y=outer[-1]; outer.append((cs*x-sn*y,sn*x+cs*y))
    a=(I(1),outer[1][1]+positive_sqrt(4-(outer[1][0]-1).sq()))
    c=(I(0),outer[5][1]-positive_sqrt(4-outer[5][0].sq()))
    d2=dist2(a,c); h=positive_sqrt(4/d2-I('0.25'))
    m=(I('0.5')+(c[1]-a[1])*h,(a[1]+c[1])/2+h)
    def negx(p): return -p[0],p[1]
    # Point order used in the paper's matrix appendix, zero-based here.
    P=[outer[0],negx(outer[1]),outer[1],negx(outer[2]),outer[2],negx(a),a,
       negx(outer[3]),outer[3],negx(m),m,c,negx(outer[4]),outer[4],negx(outer[5]),outer[5]]
    return dist2(m,outer[3])-4,P
CONTACTS={(0,1),(0,2),(1,3),(1,5),(2,4),(2,6),(3,7),(4,8),(5,6),(5,9),(6,10),
          (7,9),(7,12),(8,10),(8,13),(9,11),(10,11),(11,14),(11,15),(12,14),(13,15)}
BOUNDARY={0,1,2,3,4,7,8,12,13,14,15}
BL='3.61542559487319398553924416199196524760827792283368976231959231763302032464297878'
BH='3.61542559487319398553924416199196524760827792283368976231959231778348360154823159'

def verify(verbose=True):
    fl,_=construction(I(BL)); fh,_=construction(I(BH))
    assert fl.h<0<fh.l or fh.h<0<fl.l, (fl,fh)
    B=I(BL,BH); residual,P=construction(B)
    assert residual.contains_zero()
    min_slack=None
    noncontacts=0
    for i in range(16):
        radius=P[i][0].sq()+P[i][1].sq()
        if i in BOUNDARY:
            assert (radius-B.sq()).contains_zero()
        else:
            assert radius.h<B.sq().l
        for j in range(i+1,16):
            d=dist2(P[i],P[j])
            if (i,j) in CONTACTS:
                assert (d-4).contains_zero()
            else:
                assert d.l>4*Q,(i,j,d)
                min_slack=d.l-4*Q if min_slack is None else min(min_slack,d.l-4*Q)
                noncontacts+=1
    assert Fraction(min_slack, Q) > Fraction('0.15861')
    # Algebraic construction proves the 21 contacts exactly when F(B)=0.
    # Positive radicands throughout the whole interval also prove continuity.
    assert len(CONTACTS)==21 and len(BOUNDARY)==11 and noncontacts==99   # Proposition 8.1
    # Every unchanged inner point lies strictly below the replacement cutoff.
    cutoff = B - 4/B
    inner = set(range(16)) - BOUNDARY
    for i in inner:
        assert (P[i][0].sq() + P[i][1].sq()).h < cutoff.sq().l
    fixed = {i for i in BOUNDARY
             if any(tuple(sorted((i, j))) in CONTACTS for j in inner)}
    # Each remaining outer point touches a fixed outer point. Its original
    # radius is c or B; the following strict distance bounds exclude c.
    witnesses = {0: (6, '2.4924'), 3: (5, '1.6250'),
                 4: (6, '1.6250'), 12: (9, '1.0159'),
                 13: (10, '1.0159')}
    assert BOUNDARY - fixed == set(witnesses)
    for i, (j, upper) in witnesses.items():
        assert any(tuple(sorted((i, a))) in CONTACTS for a in fixed)
        moved = tuple(cutoff/B*x for x in P[i])
        bound = Fraction(upper)
        assert Fraction(dist2(moved, P[j]).h, Q) < bound < 4
    if verbose:
        print('PASS original-position checks: all 11 outer centres fixed')
        print('n=16 feasible construction: PASS')
        print('B bracket:',B)
        print('F(B_lo):',fl)
        print('F(B_hi):',fh)
        print('Minimum noncontact squared-distance slack lower bound:',Fraction(min_slack,Q))
        print('Contacts: 21 circle-circle; 11 circle-boundary.')
        print('Construction and original-position checks passed; see verify.py for the full proof checks.')
    return P
if __name__=='__main__': verify()
