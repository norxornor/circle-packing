"""Exact angular-closure certificate taking local radial box to Cartesian closeness.
Align original candidate point 0 (a boundary point) to the downward ray.
Each angular difference lies in one common interval for all feasible packings
in this box, including the exact candidate, so interval width bounds the
angle difference between two packings. No floating value certifies a bound.
"""
from fractions import Fraction as F
from math import acos, floor
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from certify_construction16 import verify, I, BL, BH, Q
from radial_integer_validate import cos_lower, PILO, PIHI, AQ, TWO_PI_UP
from functools import lru_cache
nominal=list(map(F,['1.63017421','1.72048802','1.81155545','1.72048802','1.63017421']))
EPS=F(1,10**6)
ranges=[(x-EPS,x+EPS) for x in nominal]+[(F(BL),F(BH))]
order=[0,5,5,1,5,5,2,5,5,3,5,5,4,5,5,5]
labels=[6,4,8,10,13,15,11,14,12,9,7,3,5,1,0,2]

@lru_cache(None)
def lower(x,y):
    # For boundary radius treat its entire exact enclosure.
    xl,xh=(F(BL),F(BH)) if x is None else (x,x)
    yl,yh=(F(BL),F(BH)) if y is None else (y,y)
    num=xh*xh+yh*yh-4
    den=2*(xl*yl if num>=0 else xh*yh)
    z=num/den
    if z>=1:return 0
    if z<=-1:return floor(PILO*AQ)
    n=max(0,floor(acos(float(z))*AQ)-2)
    while cos_lower(F(n,AQ))<z:n-=1
    assert 0<=F(n,AQ)<=PILO and cos_lower(F(n,AQ))>=z
    return n

def main():
    P=verify(False)
    # Verify the candidate has precisely the same cyclic order. Rotate the
    # displayed coordinates by pi/2, so candidate point0 is on +x axis.
    ref=labels.index(0)
    seq=labels[ref:]+labels[:ref]
    vectors=[(-P[j][1],P[j][0]) for j in seq]
    def half(v):
        x,y=v
        if y.l>0:return 0
        if y.h<0:return 1
        assert y.l==y.h==0
        assert x.l>0 or x.h<0
        return 0 if x.l>0 else 1
    halves=list(map(half,vectors))
    assert halves==sorted(halves)
    for i in range(16):
        for j in range(i+1,16):
            if halves[i]==halves[j]:
                a,b=vectors[i],vectors[j]
                assert (a[0]*b[1]-a[1]*b[0]).l>0
    for i,label in enumerate([6,10,11,9,5]):
        r=(P[label][0].sq()+P[label][1].sq()).sqrt()
        assert ranges[i][0] <= F(r.l,Q) <= F(r.h,Q) <= ranges[i][1]
    g=[[0]*6 for _ in range(6)]
    for i in range(6):
        for j in range(6):
            a=[None] if i==5 else ranges[i]
            b=[None] if j==5 else ranges[j]
            g[i][j]=min(lower(x,y) for x in a for y in b)
    # Exact bounds and sums in the paper's worked directed-angle example.
    paper_bounds = [(5,5,616268729228), (5,2,372873202735),
                    (2,1,1322619375527), (1,0,1405480958256),
                    (0,4,1452229930672)]
    for i,j,numerator in paper_bounds:
        assert numerator <= g[i][j]
    outer, qz, zm, ma, aa = [entry[2] for entry in paper_bounds]
    chain = 5*outer+qz+zm+ma
    assert chain == 6182317182658
    assert chain-TWO_PI_UP == -726118122058
    assert TWO_PI_UP-chain-aa == -726111808614
    assert 2*TWO_PI_UP-2*chain-aa == 6313444
    D=[[0]*16 for _ in range(16)]
    for i in range(16):
        for j in range(i+1,16):
            t=g[order[i]][order[j]]
            D[i][j]=t;D[j][i]=t-TWO_PI_UP
    for k in range(16):
        for i in range(16):
            for j in range(16):D[i][j]=max(D[i][j],D[i][k]+D[k][j])
    assert all(D[i][i]==0 for i in range(16))
    ref=labels.index(0)
    maximum=F(0)
    for j,label in enumerate(labels):
        width=F(-D[j][ref]-D[ref][j],AQ)
        assert width>=0
        # For an inner point, r,r* in same radius interval of width2EPS.
        dr=2*EPS if order[j]!=5 else F(0)
        upper=dr+F(BH)*width
        assert 0<=upper<F(1,10000),(label,upper)
        maximum=max(maximum,upper)
        print('point',label,'relative-angle numerators:',D[ref][j],-D[j][ref],
              'width numerator:',-D[j][ref]-D[ref][j],'denominator:',AQ)
        print('point',label,'angle-width <=',float(width),'position-distance <=',float(upper))
    assert maximum<F('0.00002276')
    print('PASS: after rotational alignment, every coordinate error <1/10000')
    print('Maximum exact error bound:', maximum)
if __name__=='__main__':main()
