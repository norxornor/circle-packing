#!/usr/bin/env python3
"""Exact rational certificate for local isolation of the 16-circle candidate.

The theorem proved by the bounds is documented in the paper's local-rigidity lemma and matrix appendix.
This certificate uses only Python's standard library; the inverse table is
untrusted data and is verified against interval candidate coordinates.
"""
from fractions import Fraction as F
from pathlib import Path
import importlib.util
import json

if not __debug__:
    raise RuntimeError('Run without -O: assertions are part of this certificate.')

ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('candidate16',ROOT/'certify_construction16.py')
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)

def verify(verbose=True):
    c.verify(False)
    _,points=c.construction(c.I(c.BL,c.BH))
    Q=c.Q;m=32
    rows=[]
    def bounds(z):return z.l,z.h
    for i,j in sorted(c.CONTACTS):
        row=[c.I(0) for _ in range(32)]
        for d in range(2):
            z=2*(points[i][d]-points[j][d]);row[2*i+d]=z;row[2*j+d]=-z
        rows.append(row[1:]+[c.I(1)])
    for i in sorted(c.BOUNDARY):
        row=[c.I(0) for _ in range(32)]
        for d in range(2):row[2*i+d]=-2*points[i][d]
        rows.append(row[1:]+[c.I(1)])
    assert len(rows)==m and all(len(row)==m for row in rows)
    data=json.loads(Path(__file__).with_name('inverse16.json').read_text())
    S=data['scale'];P=data['inverse'];assert S>0 and len(P)==m
    assert all(len(row)==m and all(isinstance(x,int) for x in row) for row in P)
    # P is an approximate inverse. Rigorously enclose E=I-PH.
    maximum=0
    for i in range(m):
        total=0
        for j in range(m):
            lo=hi=0
            for k in range(m):
                a,b=bounds(rows[k][j]);v=P[i][k]
                lo+=min(v*a,v*b);hi+=max(v*a,v*b)
            target=Q*S if i==j else 0
            total+=max(abs(target-lo),abs(target-hi))
        maximum=max(maximum,total)
    rho=F(maximum,Q*S)
    pnorm=F(max(sum(abs(v) for v in row) for row in P),S)
    assert rho<F(1,10**10)
    # Neumann series: ||H^-1-P||inf <= rho/(1-rho)*||P||inf.
    error=rho*pnorm/(1-rho)
    assert pnorm+error<5
    stress_lower=min(F(v,S)-error for v in P[-1])
    assert stress_lower>F(1,250)
    # Proposition 8.6 and Lemma 5.4: sigma*/(8 kappa) with kappa = 5, sigma* = 1/250.
    assert F(1,250)/(8*5)==F(1,10000)
    if verbose:
        print('CERTIFIED n=16 bordered Jacobian invertible, inverse infinity norm < 5')
        print('CERTIFIED normalized positive stress: every weight > 1/250')
        print('residual norm upper bound:',float(rho))
        print('inverse norm upper bound:',float(pnorm+error))
        print('minimum stress lower bound:',float(stress_lower))
        print('LOCAL THEOREM: after fixing x_0=0, every feasible configuration')
        print('with max coordinate displacement < 1/10000 is exactly the candidate.')
    return rho,pnorm+error,stress_lower

if __name__=='__main__':verify()
