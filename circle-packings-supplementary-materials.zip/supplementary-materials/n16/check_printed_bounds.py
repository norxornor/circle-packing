"""Check the printed radial bounds and the decomposed root endpoints."""
from fractions import Fraction
if not __debug__: raise RuntimeError('Assertions must be enabled.')

def verify():
    import certify_construction16 as construction
    import certify_geometry16 as geometry
    original_sqrt = construction.I.sqrt
    radicands = []

    def strict_sqrt(interval):
        assert interval.l > 0
        radicands.append(str(Fraction(interval.l, construction.Q)))
        return original_sqrt(interval)

    construction.I.sqrt = strict_sqrt
    try:
        construction.construction(construction.I(construction.BL, construction.BH))
        bounds = geometry.verify(False)
    finally:
        construction.I.sqrt = original_sqrt
    interval = construction.I
    assert interval('.242').h < bounds['v'].l
    assert bounds['v'].h < interval('.243').l
    assert interval('1.811').h < bounds['u'].l
    assert bounds['u'].h < interval('1.812').l
    assert bounds['ell'].h < bounds['E'].l
    base = (Fraction('3.615425594873193985539244161991965')
            + Fraction(247608277922833689762319592317, 10**63))
    assert base + Fraction(63302032464297878, 10**80) == Fraction(construction.BL)
    assert base + Fraction(78348360154823159, 10**80) == Fraction(construction.BH)
    return dict(all_sqrt_arguments_strictly_positive=True,
                sqrt_calls=len(radicands), printed_gap_bounds_and_root_endpoints=True,
                radicand_lower_bounds=radicands)

if __name__=='__main__':
    verify()
    print('PRINTED BOUNDS PASSED')
