"""Check the printed form of the sixteen-circle root interval.

  * Appendix A.1: b16^- and b16^+ equal b16^base plus the printed corrections;
  * Section 8.1: both endpoints lie strictly between 3.61542559487319 and
    3.61542559487320.
The bounds (8.7) are checked in certify_geometry16.py and the radicand and
divisor margins of Table 13 in certificate_summary.py.
"""
from fractions import Fraction
if not __debug__: raise RuntimeError('Assertions must be enabled.')

def verify():
    import certify_construction16 as construction
    base = (Fraction('3.615425594873193985539244161991965')
            + Fraction(247608277922833689762319592317, 10**63))
    lo, hi = Fraction(construction.BL), Fraction(construction.BH)
    assert base + Fraction(63302032464297878, 10**80) == lo
    assert base + Fraction(78348360154823159, 10**80) == hi
    assert Fraction('3.61542559487319') < lo < hi < Fraction('3.61542559487320')
    return dict(root_endpoints=(lo, hi))

if __name__=='__main__':
    verify()
    print('PRINTED BOUNDS PASSED')
