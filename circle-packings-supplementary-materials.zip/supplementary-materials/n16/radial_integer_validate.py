"""Validate every angle used by radial_integer.cpp using exact rationals, and
derive from the paper every constant that radial_integer.cpp uses
(Proposition 8.4).

No floating-point value is used to certify a bound. The C++ proposer is
untrusted; the replay build performs only integer arithmetic.

Usage:
  radial_integer_validate.py TABLE       validate the angle table
  radial_integer_validate.py --parameters   print the PARAMETERS line that
                                        radial_integer.cpp must print
"""

# Locate the shared arithmetic from any working directory.
from pathlib import Path as _Path
import sys as _sys
_sys.path.insert(0, str(_Path(__file__).resolve().parents[1]))
_sys.path.insert(0, str(_Path(__file__).resolve().parent))
from exact_arithmetic import (
    cosine_lower_34 as cos_lower,
)
from fractions import Fraction as F
from math import isqrt
from pathlib import Path
import sys

RQ, AQ = 2**30, 2**40           # Appendix C: radial grid 2^30 for N=16; (B.7) Q_theta = 2^40
TWO_PI_UP = 6908435304716        # (B.7)
BLO, BHI = F("3.6154255948731939855392441619"), F("3.6154255948731939855392441621")
PILO, PIHI = F(3141592653589793238, 10**18), F(3141592653589793239, 10**18)
START = (F('.242'), F('1.812'))  # (8.7) and Lemma 3.3; start of Proposition 8.4
# (8.8): targets in the cyclic order (A, M, Z, SM, SA) and their common radius.
TARGETS = [F(x) for x in ('1.63017421', '1.72048802', '1.81155545', '1.72048802', '1.63017421')]
TARGET_RADIUS = F(1, 10**6)
PATTERN = (2, 2, 2, 2, 3)        # Proposition 8.4
OUTER, INNER = 11, 5

def floor_grid(x, q): return (x*q).numerator // (x*q).denominator
def ceil_grid(x, q): return -((-(x*q).numerator) // (x*q).denominator)

def composition_counts(n, outer, inner):
    """(compositions, dihedral orbits) from check_compositions.py, Table 20."""
    from check_compositions import composition_checks
    rows = [r for r in composition_checks() if (r['N'], r['outer'], r['inner']) == (n, outer, inner)]
    assert len(rows) == 1
    return rows[0]['compositions'], rows[0]['dihedral_orbits']

def constants():
    from certify_construction16 import verify, BL, BH
    verify(False)
    assert BLO <= F(BL) <= F(BH) <= BHI   # the boundary radius lies in [BLO, BHI]
    # Machin's identity and its alternating Taylor series certify pi.
    def atan_bounds(x):
        lo = sum(((-1)**j * x**(2*j+1) / (2*j+1) for j in range(20)), F(0))
        return lo, lo + x**41 / 41
    al, au = atan_bounds(F(1, 5))
    bl, bu = atan_bounds(F(1, 239))
    assert PILO < 16*al - 4*bu
    assert 16*au - 4*bl < PIHI
    assert F(TWO_PI_UP, AQ) >= 2*PIHI

def parameters():
    """The exact constants radial_integer.cpp must use."""
    constants()
    # Smallest interval of denominator 2^30 containing [.242, 1.812] (Prop. 8.4).
    start = (floor_grid(START[0], RQ), ceil_grid(START[1], RQ))
    assert start[1] < 4*2**40                # Appendix H.3: radius numerators < 4 * 2^40
    assert F(start[0], RQ) <= START[0] and START[1] <= F(start[1], RQ)
    # Acceptance: whole grid intervals inside [t - 10^-6, t + 10^-6].
    accept_lo = [ceil_grid(t - TARGET_RADIUS, RQ) for t in TARGETS]
    accept_hi = [floor_grid(t + TARGET_RADIUS, RQ) for t in TARGETS]
    for t, lo, hi in zip(TARGETS, accept_lo, accept_hi):
        assert t - TARGET_RADIUS <= F(lo, RQ) and F(hi, RQ) <= t + TARGET_RADIUS
    compositions, orbits = composition_counts(16, OUTER, INNER)
    assert (compositions, orbits) == (210, 26)          # Section 8.3
    return ('PARAMETERS N=16 RQ=%d AQ=%d TWO_PI_UP=%d START=%d,%d PATTERN=%s ACCEPT_LO=%s '
            'ACCEPT_HI=%s COMPOSITIONS=%d ORBITS=%d' % (RQ, AQ, TWO_PI_UP, start[0], start[1],
            ','.join(map(str, PATTERN)), ','.join(map(str, accept_lo)),
            ','.join(map(str, accept_hi)), compositions, orbits))

def validate(path):
    constants()
    seen = set()
    for line in path.read_text().splitlines():
        xi, yi, ni = map(int, line.split())
        assert -1 <= xi <= yi and (xi, yi) not in seen
        assert xi == -1 or xi > 0
        assert yi == -1 or yi > 0
        seen.add((xi, yi))
        xlo, xhi = (BLO, BHI) if xi == -1 else (F(xi, RQ), F(xi, RQ))
        ylo, yhi = (BLO, BHI) if yi == -1 else (F(yi, RQ), F(yi, RQ))
        num = xhi*xhi + yhi*yhi - 4
        den = 2*xlo*ylo if num >= 0 else 2*xhi*yhi
        zupper = num/den
        t = F(ni, AQ)
        assert 0 <= t <= PILO
        if ni == 0:
            continue
        if zupper <= -1:
            # The clipped angular requirement is pi.
            continue
        assert zupper < 1
        assert cos_lower(t) >= zupper, (xi, yi, ni)
    print('CERTIFIED', len(seen), 'exact rational angular lower bounds')

if __name__ == '__main__':
    if sys.argv[1:] == ['--parameters']:
        print(parameters())
    else:
        assert len(sys.argv) == 2, 'usage: radial_integer_validate.py TABLE | --parameters'
        validate(Path(sys.argv[1]))
