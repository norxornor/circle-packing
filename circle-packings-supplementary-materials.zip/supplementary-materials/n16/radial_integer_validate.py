"""Validate every angle used by radial_integer.cpp using exact rationals.

No floating-point value is used to certify a bound. The C++ proposer is
untrusted; the replay build performs only integer arithmetic.
"""

# Locate the shared arithmetic from any working directory.
from pathlib import Path as _Path
import sys as _sys
_sys.path.insert(0, str(_Path(__file__).resolve().parents[1]))
from exact_arithmetic import (
    cosine_lower_34 as cos_lower,
)
from fractions import Fraction as F
from math import isqrt
from pathlib import Path
import sys

RQ, AQ = 2**30, 2**40
TWO_PI_UP = 6908435304716
BLO, BHI = F("3.6154255948731939855392441619"), F("3.6154255948731939855392441621")
PILO, PIHI = F(3141592653589793238, 10**18), F(3141592653589793239, 10**18)

def sqrt_bounds(x):
    scale = 10**30
    n = isqrt(x.numerator * scale * scale // x.denominator)
    lo, hi = F(n, scale), F(n + 1, scale)
    assert lo * lo <= x < hi * hi
    return lo, hi

def constants():
    from pathlib import Path
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from certify_construction16 import verify, BL, BH
    verify(False)
    assert BLO <= F(BL) <= F(BH) <= BHI
    # Machin's identity and its alternating Taylor series certify pi.
    def atan_bounds(x):
        lo = sum(((-1)**j * x**(2*j+1) / (2*j+1) for j in range(20)), F(0))
        return lo, lo + x**41 / 41
    al, au = atan_bounds(F(1, 5))
    bl, bu = atan_bounds(F(1, 239))
    assert PILO < 16*al - 4*bu
    assert 16*au - 4*bl < PIHI
    assert F(TWO_PI_UP, AQ) >= 2*PIHI


def validate(path):
    constants()
    seen = set()
    for line in path.read_text().splitlines():
        xi, yi, ni = map(int, line.split())
        assert -1 <= xi <= yi and (xi, yi) not in seen
        assert xi == -1 or xi > 0
        assert yi == -1 or yi > 0
        seen.add((xi, yi))
        xlo, xhi = (BLO, BHI) if xi == -1 else (F(xi, RQ), F(xi, RQ))
        ylo, yhi = (BLO, BHI) if yi == -1 else (F(yi, RQ), F(yi, RQ))
        num = xhi*xhi + yhi*yhi - 4
        den = 2*xlo*ylo if num >= 0 else 2*xhi*yhi
        zupper = num/den
        t = F(ni, AQ)
        assert 0 <= t <= PILO
        if ni == 0:
            continue
        if zupper <= -1:
            # The clipped angular requirement is pi.
            continue
        assert zupper < 1
        assert cos_lower(t) >= zupper, (xi, yi, ni)
    print('CERTIFIED', len(seen), 'exact rational angular lower bounds')

if __name__ == '__main__':
    validate(Path(sys.argv[1] if len(sys.argv) > 1 else 'radial_integer_angles.tsv'))
