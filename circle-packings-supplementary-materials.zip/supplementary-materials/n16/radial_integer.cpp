// Exact integer replay: n=16, five inner and eleven boundary centers.
// Boundary radius lies in the certified sixteen-circle construction interval.
// Production build: g++ -O3 -std=c++17 radial_integer.cpp -o radial_integer
// Replay: ./radial_integer radial_integer_angles.tsv
// Optional bound proposal (not a proof): compile with -DPROPOSE_BOUNDS.
// Validate its output using radial_integer_validate.py before replaying.
#include "../integer_bounds.hpp"
#include <algorithm>
#include <array>
#include <cassert>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <limits>
#include <map>
#include <set>
#include <utility>
#include <vector>
#ifdef PROPOSE_BOUNDS
#include <cmath>
#endif
// RQ is the radial denominator and AQ the angular denominator.
// Radius index -1 denotes the exact construction boundary radius.
// A GapCounts entry counts outer points between consecutive inner directions.
// RadiusBox intervals are closed and contain real radii, not only grid points.
using namespace std;
using GapCounts = array < int, 5 >;
constexpr Z RQ = Z(1) << 30, AQ = Z(1) << 40;
constexpr Z TWO_PI_UP = 6908435304716LL;
constexpr Z RLO = 242 * RQ / 1000, RHI = (1812 * RQ + 999) / 1000;
constexpr Z LOCAL_LO[5] = { (163017321LL * RQ + 99999999) / 100000000, (172048702LL * RQ + 99999999) /
    100000000, (181155445LL * RQ + 99999999) / 100000000, (172048702LL * RQ + 99999999) / 100000000, (
    163017321LL * RQ + 99999999) / 100000000 };
constexpr Z LOCAL_HI[5] = { 163017521LL * RQ / 100000000, 172048902LL * RQ / 100000000, 181155645LL * RQ
    / 100000000, 172048902LL * RQ / 100000000, 163017521LL * RQ / 100000000 };
struct RadiusBox {
    array < Z, 5 > lo, hi;
};
map < pair < Z, Z >, Z > angles;
vector < int > order;
Z total_nodes = 0, total_retained = 0;
Z nodes_visited, pair_exclusions, gap_exclusions, cycle_exclusions, retained_boxes;
Z angle_lower(Z x, Z y) {
    if (y < x)
        swap(x, y);
    auto key = make_pair(x, y);
    auto it = angles.find(key);
    if (it != angles.end())
        return it->second;
#ifdef PROPOSE_BOUNDS
    // This floating-point proposal is never used by the replay-only build.
    // Every proposed angle is checked with exact rational Taylor arithmetic.
    long double X = x < 0 ? 3.6154255948731941L : (long double) x / RQ;
    long double Y = y < 0 ? 3.6154255948731941L : (long double) y / RQ;
    long double z = (X * X + Y * Y - 4) / (2 * X * Y);
    long double theta = acosl(max(- 1.L, min(1.L, z)));
    Z n = max(Z(0), (Z) floorl((theta - 1e-8L) * AQ));
    angles[key] = n;
    return n;
#else
    cerr << "missing angle at " << x << "," << y << '\n';
    fail("unvalidated angle requested");
#endif
}
Z angle_box_lower(Z l, Z h, Z m, Z n) {
    return min(min(angle_lower(l, m), angle_lower(l, n)), min(angle_lower(h, m), angle_lower(h, n)));
}
// Each rejection applies to every real radius in the closed intervals.
// Pair bounds shorten intervals; angle sums and positive cycles exclude them.
bool excluded(RadiusBox & z, const GapCounts & p) {
    for (int rep = 0; rep < 2; rep++)
        for (int i = 0; i < 5; i++)
            for (int j = i + 1; j < 5; j++) {
                if (z.hi[i] + z.hi[j] < 2 * RQ) {
                    pair_exclusions++;
                    return true;
                }
                z.lo[i] = max(z.lo[i], 2 * RQ - z.hi[j]);
                z.lo[j] = max(z.lo[j], 2 * RQ - z.hi[i]);
            }
    Z pair_angles[6][6] = { };
    for (int i = 0; i < 5; i++)
        for (int j = i + 1; j < 5; j++)
            pair_angles[i][j] = pair_angles[j][i] = angle_box_lower(z.lo[i], z.hi[i], z.lo[j], z.hi[j]);
    for (int i = 0; i < 5; i++)
        pair_angles[i][5] = pair_angles[5][i] = angle_box_lower(z.lo[i], z.hi[i], - 1, - 1);
    pair_angles[5][5] = angle_lower(- 1, - 1);
    Z sum = 0;
    for (int i = 0; i < 5; i++) {
        int j = (i + 1) % 5;
        Z chain = pair_angles[i][5] + pair_angles[j][5] + (p[i] - 1) * pair_angles[5][5];
        sum += max(pair_angles[i][j], chain);
    }
    if (sum > TWO_PI_UP) {
        gap_exclusions++;
        return true;
    }
    Z d[16][16];
    for (int i = 0; i < 16; i++) {
        d[i][i] = 0;
        for (int j = i + 1; j < 16; j++) {
            Z v = pair_angles[order[i ]][order[j ]];
            d[i][j] = v;
            d[j][i] = v - TWO_PI_UP;
        }
    }
    if (positive_cycle(d)) {
        cycle_exclusions++;
        return true;
    }
    return false;
}
// Depth-first subdivision. The two children share their midpoint and
// cover the complete parent interval. A surviving box must satisfy the
// explicit local conditions; reaching the grid limit is a failure.
void search(const GapCounts & p) {
    order.clear();
    for (int i = 0; i < 5; i++) {
        order.push_back(i);
        for (int k = 0; k < p[i]; k++)
            order.push_back(5);
    }
    assert(order.size() == 16);
    RadiusBox initial;
    initial.lo.fill(RLO);
    initial.hi.fill(RHI);
    vector < RadiusBox > stack { initial };
    nodes_visited = pair_exclusions = gap_exclusions = cycle_exclusions = retained_boxes = 0;
    while (!stack.empty()) {
        if (++ nodes_visited > 20000000)
            fail("node limit");
        RadiusBox z = stack.back();
        stack.pop_back();
        if (excluded(z, p))
            continue;
        bool within_reference_ranges = p == GapCounts { 2, 2, 2, 2, 3 };
        for (int i = 0; i < 5; i++)
            within_reference_ranges = within_reference_ranges && z.lo[i] >= LOCAL_LO[i] && z.hi[i] <=
                LOCAL_HI[i];
        if (within_reference_ranges) {
            retained_boxes++;
            continue;
        }
        int split = 0;
        Z width = 0;
        for (int i = 0; i < 5; i++)
            if (z.hi[i] - z.lo[i] > width) {
                width = z.hi[i] - z.lo[i];
                split = i;
            }
        if (width < 2)
            fail("unresolved final grid cell");
        Z mid = (z.lo[split] + z.hi[split]) / 2;
        RadiusBox other = z;
        z.hi[split] = mid;
        other.lo[split] = mid;
        stack.push_back(other);
        stack.push_back(z);
    }
    assert(nodes_visited == 2 * (pair_exclusions + gap_exclusions + cycle_exclusions + retained_boxes) -
        1);
    for (int k : p)
        cout << k;
    cout << " nodes=" << nodes_visited << " pair=" << pair_exclusions << " fast=" << gap_exclusions <<
        " full=" << cycle_exclusions << " local=" << retained_boxes << endl;
    total_nodes += nodes_visited;
    total_retained += retained_boxes;
}
// Keep one representative under rotations and reflection of the order.
GapCounts canonical_pattern(GapCounts p) {
    auto best = p;
    for (int s = 0; s < 5; s++)
        for (int r : { - 1, 1 }) {
            GapCounts q;
            for (int i = 0; i < 5; i++)
                q[i] = p[(s + r * i + 10) % 5];
            best = min(best, q);
        }
    return best;
}
int main(int argc, char * * argv) {
#ifndef PROPOSE_BOUNDS
    if (argc != 2)
        fail("supply the validated angle table");
    ifstream input(argv[1]);
    if (!input)
        fail("cannot open angle table");
    Z x, y, n;
    while (input >> x >> y >> n) {
        if (x > y || n < 0 || n > TWO_PI_UP / 2)
            fail("malformed angle record");
        if (!angles.emplace(make_pair(x, y), n).second)
            fail("duplicate angle record");
    }
    if (!input.eof())
        fail("angle table parse error");
#endif
    set < GapCounts > patterns;
    int compositions = 0;
    for (int a = 1; a <= 7; a++)
        for (int b = 1; b <= 7; b++)
            for (int c = 1; c <= 7; c++)
                for (int d = 1; d <= 7; d++) {
                    int e = 11 - a - b - c - d;
                    if (e >= 1) {
                        compositions++;
                        patterns.insert(canonical_pattern(GapCounts { a, b, c, d, e }));
                    }
                }
    assert(compositions == 210 && patterns.size() == 26);
    cout << "patterns " << patterns.size() << " compositions " << compositions << endl;
    for (auto p : patterns)
        search(p);
    cout << "TOTAL nodes=" << total_nodes << " local=" << total_retained << " angles=" << angles.size()
        << '\n';
#ifdef PROPOSE_BOUNDS
    ofstream output("radial_integer_angles.tsv");
    for (auto &[key, n] : angles)
        output << key.first << '\t' << key.second << '\t' << n << '\n';
    if (!output)
        fail("could not write angle table");
    cout << "PROPOSAL COMPLETE: validate every angle before replay.\n";
#else
    cout << "PASS: exact integer replay completed all radial boxes.\n";
#endif
}
