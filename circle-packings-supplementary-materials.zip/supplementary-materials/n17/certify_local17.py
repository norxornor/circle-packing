#!/usr/bin/env python3
"""Exact rational certificate for local isolation of the 17-circle candidate.
See the paper's local-rigidity lemma and matrix appendix. The global exclusions are checked separately.
"""
from fractions import Fraction as F
from pathlib import Path
import importlib.util
import json
if not __debug__:
    raise RuntimeError('Run without -O: assertions are part of this certificate.')
ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('candidate17',ROOT/'verify17_exact.py')
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)

def verify(verbose=True):
    _,points=c.construct(c.I(c.LO,c.HI))
    Q=c.D;m=35;d=33
    data=json.loads(Path(__file__).with_name('inverse17.json').read_text())
    VS=data['extra_scale'];v=data['extra_column'];assert VS>0 and len(v)==m
    rows=[]
    for ii,jj in sorted(c.CONTACTS):
        i,j=ii-1,jj-1
        row=[c.I(0) for _ in range(34)]
        for k in range(2):
            z=2*(points[i][k]-points[j][k]);row[2*i+k]=z;row[2*j+k]=-z
        rows.append(row[1:]+[c.I(1),c.I(F(v[len(rows)],VS))])
    for ii in sorted(c.BOUNDARY):
        i=ii-1;row=[c.I(0) for _ in range(34)]
        for k in range(2):row[2*i+k]=-2*points[i][k]
        rows.append(row[1:]+[c.I(1),c.I(F(v[len(rows)],VS))])
    assert len(rows)==m and all(len(row)==m for row in rows)
    S=data['scale'];P=data['inverse'];assert S>0 and len(P)==m
    assert all(len(row)==m and all(isinstance(x,int) for x in row) for row in P)
    maximum=0
    for i in range(m):
        total=0
        for j in range(m):
            lo=hi=0
            for k in range(m):
                a,b=rows[k][j].lo,rows[k][j].hi;z=P[i][k]
                lo+=min(z*a,z*b);hi+=max(z*a,z*b)
            target=Q*S if i==j else 0
            total+=max(abs(target-lo),abs(target-hi))
        maximum=max(maximum,total)
    rho=F(maximum,Q*S)
    pnorm=F(max(sum(abs(z) for z in row) for row in P),S)
    assert rho<F(1,10**10)
    error=rho*pnorm/(1-rho)
    assert pnorm+error<8
    stress_lower=min(F(z,S)-error for z in P[d])
    assert stress_lower>F(1,250)
    # Proposition 9.6 and Lemma 5.4: sigma*/(8 kappa) with kappa = 8, sigma* = 1/250.
    assert F(1,250)/(8*8)==F(1,16000)
    if verbose:
        print('CERTIFIED n=17 bordered Jacobian invertible, inverse infinity norm < 8')
        print('CERTIFIED normalized positive stress: every weight > 1/250')
        print('residual norm upper bound:',float(rho))
        print('inverse norm upper bound:',float(pnorm+error))
        print('minimum stress lower bound:',float(stress_lower))
        print('LOCAL THEOREM: after fixing x_0=-1, every feasible configuration')
        print('with max coordinate displacement < 1/16000 is exactly the candidate.')
    return rho,pnorm+error,stress_lower
if __name__=='__main__':verify()
