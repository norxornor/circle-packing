"""Validate all angular bounds used in radial_integer.cpp, using exact rationals,
certify the radial cap of Proposition 9.2 / (9.9), and derive from the paper
every constant that radial_integer.cpp uses (Proposition 9.4).

The floating proposer is untrusted. Every bound is verified over the exact
rational bracket [BLO, BHI] of the construction radius (9.1).

Usage:
  validate_angles.py TABLE...            validate angle tables
  validate_angles.py --parameters K      print the PARAMETERS line that
                                         radial_integer.cpp K must print
"""

# Locate the shared arithmetic from any working directory.
from pathlib import Path as _Path
import sys as _sys
_sys.path.insert(0, str(_Path(__file__).resolve().parents[1]))
from exact_arithmetic import (
    cosine_lower_34 as cos_lower,
    sine_upper_37 as sin_upper,
    sine_bounds,
)
from fractions import Fraction as F
from pathlib import Path
import sys
RQ=AQ=2**40                     # Appendix C: radial grid 2^40; (B.7) Q_theta = 2^40
TWO_PI_UP=6908435304716          # (B.7)
BLO=F('3.7920337483105791701491239532')   # (9.1)
BHI=F('3.7920337483105791701491239534')
PILO,PIHI=F('3.141592653589793238'),F('3.141592653589793239')
ETA_PRINTED=F('0.266867098322829')        # Proposition 9.2: eta > this value
ETA_UPPER=F('.266867153')                 # Table 15: eta < eta+
RCAP=F('2.368')                           # Proposition 9.2 / (9.9)
START_HI={6:RCAP,7:F('2.738')}            # Table 19: [0,2.368] for m=11, [0,2.738] for m=10
# (9.11) and (9.12): following outer counts and rational radial targets.
PATTERN=(0,1,2,2,2,2,1)
TARGETS=[F(x) for x in ('.10925499699','2.54742230599','2.06840968290','1.94669000932',
                        '1.92575180443','1.94669000932','2.06840968290')]
TARGET_RADIUS=F(1,10**7)
TARGET_DEN=10**11

def ceil_grid(x,q):return -((-(x*q).numerator)//(x*q).denominator)

def composition_counts(n,outer,inner):
    """(compositions, dihedral orbits) from check_compositions.py, Table 20."""
    from check_compositions import composition_checks
    rows=[r for r in composition_checks() if (r['N'],r['outer'],r['inner'])==(n,outer,inner)]
    assert len(rows)==1
    return rows[0]['compositions'],rows[0]['dihedral_orbits']

def constants():
    def atan_bounds(x):
        lo=sum(((-1)**j*x**(2*j+1)/(2*j+1) for j in range(20)),F(0))
        return lo,lo+x**41/41
    a,b=atan_bounds(F(1,5));c,d=atan_bounds(F(1,239))
    assert PILO<16*a-4*d and 16*b-4*c<PIHI
    assert F(TWO_PI_UP,AQ)>=2*PIHI
    # Proposition 9.2: eta > .266867098322829, and eta < eta+ from Table 15.
    assert sin_upper(ETA_PRINTED)<1/BHI
    assert sine_bounds(ETA_UPPER)[0]>1/BLO
    # (9.9) with m = 11: omega_11 = pi - 10 eta and the printed omega_11^+.
    A=F('3.141592653589793239')-10*ETA_PRINTED
    assert A==PIHI-10*ETA_PRINTED
    ca=cos_lower(A)
    assert 0<PILO-10*ETA_UPPER          # 0 < omega_11
    #   omega_11 < omega_11^+ because pi < PIHI and eta > ETA_PRINTED (checked above).
    assert A<PILO/2                     # omega_11^+ < pi/2
    cutoff=BHI-4/BHI                    # c(b) <= c(BHI): c is increasing
    assert cutoff<BLO*ca                # c < b17^- cos(omega_11^+)
    assert RCAP**2+BHI**2-2*RCAP*BHI*ca<4   # D(2.368, b17^+; omega_11^+) < 4
    print('CERTIFIED (9.9): 0 < omega_11 < omega_11^+ < pi/2, c < b- cos(omega_11^+), D(2.368, b+; omega_11^+) < 4')

def check_reversal():
    """Section 9.3: the reversed target list (t_{1-i}, q_{-i}) has q_{-i} = q_i,
    exchanges the first two targets and leaves the other five unchanged."""
    k=len(PATTERN)
    assert all(PATTERN[(-i)%k]==PATTERN[i] for i in range(k))
    reversed_targets=[TARGETS[(1-i)%k] for i in range(k)]
    assert reversed_targets[:2]==[TARGETS[1],TARGETS[0]] and reversed_targets[2:]==TARGETS[2:]

def parameters(k):
    constants();check_reversal()
    start=ceil_grid(START_HI[k],RQ)     # smallest grid interval containing [0, START_HI]
    assert start<4*2**40                    # Appendix H.3: radius numerators < 4 * 2^40
    assert START_HI[k]<=F(start,RQ)
    for t in TARGETS:assert (t*TARGET_DEN).denominator==1
    radius=TARGET_RADIUS*TARGET_DEN
    assert radius.denominator==1
    compositions,orbits=composition_counts(17,17-k,k)
    assert (compositions,orbits)=={6:(4368,392),7:(8008,600)}[k]   # Section 9.3
    return ('PARAMETERS N=17 K=%d RQ=%d AQ=%d TWO_PI_UP=%d START=0,%d PATTERN=%s TARGET_DEN=%d '
            'TARGET=%s TARGET_RADIUS=%d COMPOSITIONS=%d ORBITS=%d'%(k,RQ,AQ,TWO_PI_UP,start,
            ','.join(map(str,PATTERN)),TARGET_DEN,','.join(str(int(t*TARGET_DEN)) for t in TARGETS),
            int(radius),compositions,orbits))

def validate(path):
    seen=set()
    for line in path.read_text().splitlines():
        xi,yi,ni=map(int,line.split())
        assert -1<=xi<=yi and (xi,yi) not in seen
        seen.add((xi,yi))
        assert ni>=0
        xl,xh=(BLO,BHI) if xi==-1 else (F(xi,RQ),F(xi,RQ))
        yl,yh=(BLO,BHI) if yi==-1 else (F(yi,RQ),F(yi,RQ))
        t=F(ni,AQ)
        assert 0<=t<=PILO
        if ni==0:continue
        # Radius zero: a positive bound is valid only when the pair is infeasible.
        if xl==0 or yl==0:
            assert xh+yh<2,(xi,yi,ni)
            continue
        num=xh*xh+yh*yh-4
        den=2*xl*yl if num>=0 else 2*xh*yh
        zupper=num/den
        if zupper<=-1:continue
        assert zupper<1 and cos_lower(t)>=zupper,(xi,yi,ni)
    print('CERTIFIED',len(seen),'exact rational angular lower bounds')
if __name__=='__main__':
    if sys.argv[1:2]==['--parameters']:
        assert len(sys.argv)==3
        print(parameters(int(sys.argv[2])))
    else:
        assert len(sys.argv)>1
        constants()
        for p in sys.argv[1:]:validate(Path(p))
