#!/usr/bin/env python3
"""Rigorous existence/feasibility certificate for Reis's 17-circle candidate
(Proposition 9.1 and Section 9.5). Contact lists are compared with the paper by
label in check_reference_certificates.py.
Standard library only; integer outward-rounded interval arithmetic.
The global exclusion and local determination are checked separately.
"""
from math import isqrt
if not __debug__:
    raise RuntimeError('Run without -O: assertions are part of this certificate.')
from fractions import Fraction
from decimal import Decimal, localcontext

D=10**60
class I:
    def __init__(self,a,b=None,raw=False):
        if raw:self.lo,self.hi=a,b;return
        a=Fraction(a);b=a if b is None else Fraction(b)
        self.lo=(a.numerator*D)//a.denominator
        self.hi=-((-b.numerator*D)//b.denominator)
    @classmethod
    def bounds(cls,a,b):return cls(a,b,True)
    @staticmethod
    def co(a):return a if isinstance(a,I) else I(a)
    def __add__(self,o):
        o=I.co(o);return I.bounds(self.lo+o.lo,self.hi+o.hi)
    __radd__=__add__
    def __neg__(self):return I.bounds(-self.hi,-self.lo)
    def __sub__(self,o):return self+-I.co(o)
    def __rsub__(self,o):return I.co(o)+-self
    def __mul__(self,o):
        o=I.co(o);v=[a*b for a in (self.lo,self.hi) for b in (o.lo,o.hi)]
        return I.bounds(min(v)//D,-((-max(v))//D))
    __rmul__=__mul__
    def __truediv__(self,o):
        o=I.co(o);assert o.lo>0 or o.hi<0,'division interval contains zero'
        values=[Fraction(a*D,b) for a in (self.lo,self.hi) for b in (o.lo,o.hi)]
        low=min(values);high=max(values)
        return I.bounds(low.numerator//low.denominator,-((-high.numerator)//high.denominator))
    def __rtruediv__(self,o):return I.co(o)/self
    def sqrt(self):
        assert self.lo>=0,'negative square-root radicand'
        a=isqrt(self.lo*D);b=isqrt(self.hi*D)
        if b*b<self.hi*D:b+=1
        return I.bounds(a,b)
    def square(self):
        low=0 if self.lo<=0<=self.hi else min(self.lo*self.lo,self.hi*self.hi)
        high=max(self.lo*self.lo,self.hi*self.hi)
        return I.bounds(low//D,-((-high)//D))
    def describe(self):
        with localcontext() as ctx:
            ctx.prec=18
            return '[%s, %s]'%(Decimal(self.lo)/D,Decimal(self.hi)/D)

class AD:
    """First derivative enclosure, based on the same rational intervals."""
    def __init__(self,v,d):self.v,self.d=v,d
    @staticmethod
    def const(a):return AD(I(a),I(0))
    @staticmethod
    def co(a):return a if isinstance(a,AD) else AD.const(a)
    def __add__(self,o):
        o=AD.co(o);return AD(self.v+o.v,self.d+o.d)
    __radd__=__add__
    def __neg__(self):return AD(-self.v,-self.d)
    def __sub__(self,o):return self+-AD.co(o)
    def __rsub__(self,o):return AD.co(o)+-self
    def __mul__(self,o):
        o=AD.co(o);return AD(self.v*o.v,self.d*o.v+self.v*o.d)
    __rmul__=__mul__
    def __truediv__(self,o):
        o=AD.co(o);return AD(self.v/o.v,(self.d*o.v-self.v*o.d)/o.v.square())
    def __rtruediv__(self,o):return AD.co(o)/self
    def square(self):return AD(self.v.square(),2*self.v*self.d)
    def sqrt(self):
        v=self.v.sqrt();return AD(v,self.d/(2*v))

def add(p,q):return tuple(a+b for a,b in zip(p,q))
def sub(p,q):return tuple(a-b for a,b in zip(p,q))
def mul(a,p):return tuple(a*x for x in p)
def turn(p):return (-p[1],p[0])
def norm2(p):return sum(x.square() for x in p)
def reflect(p):return (-p[0],p[1])

def construct(B):
    C0=I if isinstance(B,I) else AD.const
    t=(B.square()-1).sqrt();rt3=C0(3).sqrt()
    c=1-2/B.square();s=2*t/B.square()
    A=(C0(1),-t)
    C=(3-4/B.square(),-t+4*t/B.square())
    F=(C0(0),-t+rt3)
    E=add(C,(-C0(1),rt3))
    G=(C0(0),-t+8*t/B.square()+rt3)
    e2=norm2(E);alpha=(B.square()+e2-4)/(2*e2)
    beta=(B.square()/e2-alpha.square()).sqrt()
    H=add(mul(alpha,E),mul(beta,turn(E)))
    J0=add(mul(c,H),mul(s,turn(H)))
    d=sub(J0,G);d2=norm2(d)
    v=(4/d2-Fraction(1,4)).sqrt()
    J=add(mul(C0(Fraction(1,2)),add(J0,G)),mul(v,turn(d)))
    K=(C0(0),J[1]+(4-J[0].square()).sqrt())
    L=add(mul(C0(Fraction(1,2)),add(J,K)),mul(rt3/2,turn(sub(J,K))))
    P=[reflect(A),A,reflect(C),C,F,reflect(E),E,reflect(H),H,G,
       reflect(J0),J0,reflect(J),J,K,reflect(L),L]
    return norm2(L)-B.square(),P

CONTACTS={(1,2),(1,3),(2,4),(1,5),(2,5),(3,6),(5,6),(4,7),(5,7),
          (6,8),(7,9),(6,10),(7,10),(8,11),(9,12),(10,13),(11,13),
          (10,14),(12,14),(13,15),(14,15),(13,16),(15,16),(14,17),(15,17)}
BOUNDARY={1,2,3,4,8,9,11,12,16,17}
LO='3.7920337483105791701491239532'
HI='3.7920337483105791701491239534'

def main():
    flo,_=construct(I(LO));fhi,_=construct(I(HI))
    print('f(B_lo):',flo.describe());print('f(B_hi):',fhi.describe())
    assert (flo.hi<0 and fhi.lo>0) or (flo.lo>0 and fhi.hi<0)
    df,_=construct(AD(I(LO,HI),I(1)))
    assert df.d.hi<0
    print('f prime on interval:',df.d.describe())
    f,P=construct(I(LO,HI))
    noncontact_slacks=[]
    for i in range(17):
        for j in range(i+1,17):
            d2=norm2(sub(P[i],P[j]))
            if (i+1,j+1) in CONTACTS:
                # Sanity check only. Exact contact identities are proved in the paper.
                assert d2.lo<=4*D<=d2.hi
            else:
                assert d2.lo>4*D,(i+1,j+1,d2.describe())
                noncontact_slacks.append(d2.lo-4*D)
    inner_slacks=[]
    for i,p in enumerate(P,1):
        slack=I(LO,HI).square()-norm2(p)
        if i not in BOUNDARY:
            assert slack.lo>0,(i,slack.describe())
            inner_slacks.append(slack.lo)
    cutoff = I(LO, HI) - 4/I(LO, HI)
    inner = set(range(1, 18)) - BOUNDARY
    for j in inner:
        assert norm2(P[j-1]).hi < cutoff.square().lo
    for i in BOUNDARY:
        assert any(tuple(sorted((i, j))) in CONTACTS for j in inner)
    print('PASS original-position checks: all 10 outer centres have inner contacts')
    assert len(CONTACTS)==25 and len(noncontact_slacks)==111
    assert Fraction(min(noncontact_slacks),D)>Fraction('0.1412526818')
    assert Fraction(min(inner_slacks),D)>Fraction('7.8901595432')
    print('Strict noncontact pairs:',len(noncontact_slacks))
    print('Minimum certified noncontact squared-distance slack:',I.bounds(min(noncontact_slacks),min(noncontact_slacks)).describe())
    print('Interior points:',len(inner_slacks))
    print('Minimum certified interior squared-radius slack:',I.bounds(min(inner_slacks),min(inner_slacks)).describe())
    print('By IVT and the exact contact identities, a feasible packing exists with')
    print('  '+str(Fraction(LO)+1)+' < R < '+str(Fraction(HI)+1))
    print('Construction and original-position checks passed; see verify.py for the full proof checks.')
if __name__=='__main__':main()
