// Exact integer replay; floating proposals require separate exact validation.
#include "../integer_bounds.hpp"
#include <algorithm>
#include <array>
#include <cassert>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <limits>
#include <map>
#include <string>
#include <set>
#include <vector>
#ifdef PROPOSE_BOUNDS
#include <cmath>
#endif
// RQ is the radial denominator and AQ the angular denominator.
// Radius index -1 denotes the exact construction boundary radius.
// A GapCounts entry counts outer points between consecutive inner directions.
// RadiusBox intervals are closed and contain real radii, not only grid points.
using namespace std;
using GapCounts = vector < int >;
constexpr int N = 17, KMAX = 7;
constexpr Z RQ = Z(1) << 40, AQ = Z(1) << 40, TWO_PI_UP = 6908435304716LL;
int K, M;
Z start_hi();
const Z TARGET[KMAX] = { 10925499699LL, 254742230599LL, 206840968290LL, 194669000932LL, 192575180443LL,
    194669000932LL, 206840968290LL };
constexpr Z TQ = 100000000000LL, TM = 10000;
const GapCounts TARGET_PATTERN = { 0, 1, 2, 2, 2, 2, 1 };
int compositions_expected() { return K == 6 ? 4368 : 8008; }
int orbits_expected() { return K == 6 ? 392 : 600; }
struct RadiusBox {
    array < Z, KMAX > lo, hi;
};
map < pair < Z, Z >, Z > angles;
vector < int > order;
Z nodes_visited, pair_exclusions, gap_exclusions, cycle_exclusions, retained_boxes, total_nodes = 0,
    total_retained = 0;
Z angle_lower(Z x, Z y) {
    if (y < x)
        swap(x, y);
    auto key = make_pair(x, y);
    auto it = angles.find(key);
    if (it != angles.end())
        return it->second;
#ifdef PROPOSE_BOUNDS
    long double X = x < 0 ? 3.792033748310580L : (long double) x / RQ;
    long double Y = y < 0 ? 3.792033748310580L : (long double) y / RQ;
    long double theta = 0;
    if (fabsl(X - Y) >= 2)
        theta = 0;
    else if (X + Y <= 2)
        theta = acosl(- 1.L);
    else theta = acosl(max(- 1.L, min(1.L, (X * X + Y * Y - 4) / (2 * X * Y))));
    Z n = max(Z(0), Z(floorl((theta - 1e-12L) * AQ)));
    angles[key] = n;
    return n;
#else
    cerr << "missing " << x << "," << y << endl;
    fail("unvalidated angle");
#endif
}
Z angle_box_lower(Z a, Z b, Z c, Z d) {
    return min({ angle_lower(a, c), angle_lower(a, d), angle_lower(b, c), angle_lower(b, d) });
}
// Each rejection applies to every real radius in the closed intervals.
// Pair bounds shorten intervals; angle sums and positive cycles exclude them.
bool excluded(RadiusBox & z, const GapCounts & p) {
    for (int rep = 0; rep < 2; rep++)
        for (int i = 0; i < K; i++)
            for (int j = i + 1; j < K; j++) {
                if (z.hi[i] + z.hi[j] < 2 * RQ) {
                    pair_exclusions++;
                    return true;
                }
                z.lo[i] = max(z.lo[i], 2 * RQ - z.hi[j]);
                z.lo[j] = max(z.lo[j], 2 * RQ - z.hi[i]);
            }
    Z pair_angles[KMAX + 1][KMAX + 1] = { };
    for (int i = 0; i < K; i++)
        for (int j = i + 1; j < K; j++)
            pair_angles[i][j] = pair_angles[j][i] = angle_box_lower(z.lo[i], z.hi[i], z.lo[j], z.hi[j]);
    for (int i = 0; i < K; i++)
        pair_angles[i][K] = pair_angles[K][i] = angle_box_lower(z.lo[i], z.hi[i], - 1, - 1);
    pair_angles[K][K] = angle_lower(- 1, - 1);
    Z sum = 0;
    for (int i = 0; i < K; i++) {
        int j = (i + 1) % K;
        Z chain = p[i] ? pair_angles[i][K] + pair_angles[j][K] + (p[i] - 1) * pair_angles[K][K] : 0;
        sum += max(pair_angles[i][j], chain);
    }
    if (sum > TWO_PI_UP) {
        gap_exclusions++;
        return true;
    }
    Z d[N][N];
    for (int i = 0; i < N; i++) {
        d[i][i] = 0;
        for (int j = i + 1; j < N; j++) {
            Z v = pair_angles[order[i ]][order[j ]];
            d[i][j] = v;
            d[j][i] = v - TWO_PI_UP;
        }
    }
    if (positive_cycle(d)) {
        cycle_exclusions++;
        return true;
    }
    return false;
}
// Acceptance only places every represented arrangement in one of the
// paper's stated neighbourhoods. Local rigidity is checked separately.
bool within_reference_ranges(const RadiusBox & z, const GapCounts & p) {
    if (K != 7 || p != TARGET_PATTERN)
        return false;
    for (int reflection = 0; reflection < 2; reflection++) {
        bool match = true;
        for (int i = 0; i < K; i++) {
            Z target = TARGET[reflection ? (1 - i + K) % K : i];
            if ((__int128) z.lo[i] * TQ < (__int128)(target - TM) * RQ || (__int128) z.hi[i] * TQ > (
                __int128)(target + TM) * RQ)
                match = false;
        }
        if (match)
            return true;
    }
    return false;
}
// Depth-first subdivision. The two children share their midpoint and
// cover the complete parent interval. A surviving box must satisfy the
// explicit local conditions; reaching the grid limit is a failure.
void search(const GapCounts & p) {
    order.clear();
    for (int i = 0; i < K; i++) {
        order.push_back(i);
        for (int k = 0; k < p[i]; k++)
            order.push_back(K);
    }
    assert(order.size() == N);
    RadiusBox initial;
    initial.lo.fill(0);
    initial.hi.fill(start_hi());
    vector < RadiusBox > stack { initial };
    nodes_visited = pair_exclusions = gap_exclusions = cycle_exclusions = retained_boxes = 0;
    while (!stack.empty()) {
        if (++ nodes_visited > 50000000)
            fail("node limit");
        RadiusBox z = stack.back();
        stack.pop_back();
        if (excluded(z, p))
            continue;
        if (within_reference_ranges(z, p)) {
            retained_boxes++;
            continue;
        }
        int split = 0;
        Z width = 0;
        for (int i = 0; i < K; i++)
            if (z.hi[i] - z.lo[i] > width) {
                width = z.hi[i] - z.lo[i];
                split = i;
            }
        if (width < 2)
            fail("unresolved final grid cell");
        Z mid = (z.lo[split] + z.hi[split]) / 2;
        RadiusBox other = z;
        z.hi[split] = mid;
        other.lo[split] = mid;
        stack.push_back(other);
        stack.push_back(z);
    }
    assert(nodes_visited == 2 * (pair_exclusions + gap_exclusions + cycle_exclusions + retained_boxes) -
        1);
    for (int k : p)
        cout << k << ",";
    cout << " nodes=" << nodes_visited << " pair=" << pair_exclusions << " fast=" << gap_exclusions <<
        " full=" << cycle_exclusions << " local=" << retained_boxes << endl;
    total_nodes += nodes_visited;
    total_retained += retained_boxes;
}
// Every constant used by the search, checked against the paper by
// validate_angles.py --parameters K and the verification driver.
Z start_hi() {
    return ((K == 6 ? 2368 : 2738) * RQ + 999) / 1000;
}
void print_parameters() {
    cout << "PARAMETERS N=17 K=" << K << " RQ=" << RQ << " AQ=" << AQ << " TWO_PI_UP=" << TWO_PI_UP
         << " START=0," << start_hi() << " PATTERN=";
    for (int i = 0; i < KMAX; i++) cout << (i ? "," : "") << TARGET_PATTERN[i];
    cout << " TARGET_DEN=" << TQ << " TARGET=";
    for (int i = 0; i < KMAX; i++) cout << (i ? "," : "") << TARGET[i];
    cout << " TARGET_RADIUS=" << TM << " COMPOSITIONS=" << compositions_expected()
         << " ORBITS=" << orbits_expected() << endl;
}
// Keep one representative under rotations and reflection of the order.
GapCounts canonical_pattern(GapCounts p) {
    auto best = p;
    for (int s = 0; s < K; s++)
        for (int r : { - 1, 1 }) {
            GapCounts q(K);
            for (int i = 0; i < K; i++)
                q[i] = p[(s + r * i + 2 * K) % K];
            best = min(best, q);
        }
    return best;
}
Z composition_count = 0;
void gen(GapCounts p, int sum, set < GapCounts > & out) {
    if (p.size() == K - 1) {
        ++composition_count;
        p.push_back(M - sum);
        out.insert(canonical_pattern(p));
        return;
    }
    for (int a = 0; a <= M - sum; a++) {
        p.push_back(a);
        gen(p, sum + a, out);
        p.pop_back();
    }
}
int main(int argc, char * * argv) {
    K = argc > 1 ? atoi(argv[1]) : 6;
    M = N - K;
    assert(K == 6 || K == 7);
    if (argc == 3 && string(argv[2]) == "--parameters") {
        print_parameters();
        return 0;
    }
    print_parameters();
#ifndef PROPOSE_BOUNDS
    if (argc != 3)
        fail("supply K and validated angle table");
    ifstream input(argv[2]);
    if (!input)
        fail("cannot open angle table");
    Z x, y, n;
    while (input >> x >> y >> n) {
        if (x > y || x < - 1 || n < 0 || n > TWO_PI_UP / 2)
            fail("bad record");
        if (!angles.emplace(make_pair(x, y), n).second)
            fail("duplicate record");
    }
    if (!input.eof())
        fail("parse error");
#endif
    set < GapCounts > patterns;
    gen({}, 0, patterns);
    assert(composition_count == compositions_expected());
    assert(patterns.size() == size_t(orbits_expected()));
    cout << "K=" << K << " M=" << M << " patterns=" << patterns.size() << endl;
    for (auto p : patterns)
        search(p);
    cout << "TOTAL nodes=" << total_nodes << " local=" << total_retained << " angles=" << angles.size()
        << endl;
#ifdef PROPOSE_BOUNDS
    ofstream output("radial17_angles_" + to_string(K) + ".tsv");
    for (auto &[key, n] : angles)
        output << key.first << '\t' << key.second << '\t' << n << '\n';
    if (!output)
        fail("write failed");
    cout << "PROPOSAL COMPLETE; exact validation required" << endl;
#else
    cout << "PASS exact integer replay" << endl;
#endif
}
