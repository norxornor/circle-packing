"""Exact radial-box -> Cartesian-neighborhood certificate for n=17.
After rotation aligns the matched boundary point with the reference center SA,
every coordinate displacement is strictly less than 1/16000.
The radical construction and the angle corner lemma are prerequisites.
"""

# Locate the shared arithmetic from any working directory.
from pathlib import Path as _Path
import sys as _sys
_sys.path.insert(0, str(_Path(__file__).resolve().parents[1]))
from exact_arithmetic import (
    cosine_lower_34 as cos_lower,
)
if not __debug__:
    raise RuntimeError('Run without -O: assertions are part of this certificate.')
from fractions import Fraction as F
from math import acos,floor
from functools import lru_cache
from verify17_exact import I,D as SCALE,LO,HI,construct,norm2

AQ=2**40
PILO,PIHI=F(3141592653589793238,10**18),F(3141592653589793239,10**18)
TWO_PI_UP=6908435304716

def constants():
    def atan(x):
        lower=sum(((-1)**j*x**(2*j+1)/(2*j+1) for j in range(20)),F(0))
        return lower,lower+x**41/41
    al,au=atan(F(1,5));bl,bu=atan(F(1,239))
    assert PILO<16*al-4*bu and 16*au-4*bl<PIHI
    assert F(TWO_PI_UP,AQ)>=2*PIHI


nominal=list(map(F,['.10925499699','2.54742230599','2.0684096829','1.94669000932',
                   '1.92575180443','1.94669000932','2.0684096829']))
EPS=F(1,10**7)
# The radial intervals used here are exactly the targets (9.12) of the search.
from validate_angles import TARGETS, TARGET_RADIUS
assert nominal==TARGETS and EPS==TARGET_RADIUS
ranges=[(x-EPS,x+EPS) for x in nominal]+[(F(LO),F(HI))]
# Indices7 refer to the common outer radius. Labels refer to the order in verify17_exact.
order=[0,1,7,2,7,7,3,7,7,4,7,7,5,7,7,6,7]
labels=[9,14,15,12,10,7,5,2,0,4,1,3,6,8,11,13,16]
# Names of the construction points in their coordinate order (Table 25).
NAMES=['SA','A','SC','C','F','SE','E','SH','H','G','SM','M','SJ','J','K','SL','L']
ORDER_9_13=['G','K','SL','SJ','SM','SH','SE','SC','SA','F','A','C','E','H','M','J','L']
assert [NAMES[l] for l in labels]==ORDER_9_13
assert [NAMES[l] for l,c in zip(labels,order) if c!=7]==['G','K','SJ','SE','F','E','J']

def chain_bound(chain,bound):
    """Appendix D: add the pair bounds along a chain of names in the order (9.13),
    subtracting Pi+ for each step that returns to an earlier entry."""
    position={name:i for i,name in enumerate(ORDER_9_13)}
    total=0;wraps=[]
    for a,b in zip(chain,chain[1:]):
        total+=bound(a,b)
        if position[b]<position[a]:
            total-=TWO_PI_UP;wraps.append((a,b))
    return total,wraps

@lru_cache(None)
def lower(x,y):
    xl,xh=(F(LO),F(HI)) if x is None else (x,x)
    yl,yh=(F(LO),F(HI)) if y is None else (y,y)
    num=xh*xh+yh*yh-4
    den=2*(xl*yl if num>=0 else xh*yh)
    z=num/den
    if z>=1:return 0
    if z<=-1:return floor(PILO*AQ)
    n=max(0,floor(acos(float(z))*AQ)-2)
    while cos_lower(F(n,AQ))<z:n-=1
    assert 0<=F(n,AQ)<=PILO and cos_lower(F(n,AQ))>=z
    return n

def main():
    constants()
    _,P=construct(I(LO,HI))
    for i,label in enumerate([9,14,12,5,4,6,13]):
        radius=norm2(P[label]).sqrt()
        assert ranges[i][0]<=F(radius.lo,SCALE)<=F(radius.hi,SCALE)<=ranges[i][1]
    # Verify the exact construction has the stated cyclic order. Work in
    # coordinates whose positive horizontal axis is original point1's ray.
    refpos=labels.index(0)
    cyclic=labels[refpos:]+labels[:refpos]
    anchor=P[0]
    def cross(a,b):return a[0]*b[1]-a[1]*b[0]
    def dot(a,b):return a[0]*b[0]+a[1]*b[1]
    halves=[]
    for label in cyclic:
        X=dot(P[label],anchor);Y=cross(anchor,P[label])
        if label==0:
            assert X.lo>0
            half=0  # Exact identity cross(anchor,anchor)=0.
        elif Y.lo>0:half=0
        elif Y.hi<0:half=1
        else:raise AssertionError(('unresolved candidate half-plane',label))
        halves.append(half)
    assert halves==sorted(halves)
    for i,a in enumerate(cyclic):
        for j in range(i+1,len(cyclic)):
            b=cyclic[j]
            if halves[i]!=halves[j]:continue
            if {a,b}=={9,14}:
                # G and K are exactly on the positive vertical ray.
                assert P[a][0].lo==P[a][0].hi==0
                assert P[b][0].lo==P[b][0].hi==0
                assert P[a][1].lo>0 and P[b][1].lo>0
            else:assert cross(P[a],P[b]).lo>0,('candidate order',a,b)
    print('Exact candidate cyclic order certified, including core/top tie.')
    g=[[0]*8 for _ in range(8)]
    for i in range(8):
        for j in range(8):
            a=[None] if i==7 else ranges[i]
            b=[None] if j==7 else ranges[j]
            g[i][j]=min(lower(x,y) for x in a for y in b)
    # Appendix D.2, Table 22: the printed pair bounds are valid for these radial intervals.
    CLASS={'G':0,'K':1,'SJ':2,'SE':3,'F':4,'E':5,'J':6}
    def cls(name):return CLASS.get(name,7)
    l1,l2,l3,l4,l5,l6=586846955351,313137629044,2260807738297,960343861311,400480862097,0
    table22={frozenset([7]):l1,frozenset([5,7]):l2,frozenset([3,7]):l2,frozenset([5,0]):l3,
             frozenset([1,6]):l4,frozenset([1,2]):l4,frozenset([6,7]):l5,frozenset([2,7]):l5,
             frozenset([0,1]):l6}
    def ell(a,b):
        value=table22[frozenset([cls(a),cls(b)])]
        assert value<=g[cls(a)][cls(b)]
        return value
    # Chain SA, A, C, E, G returns to an earlier entry only at its last step.
    paper_lower,wraps=chain_bound(['SA','A','C','E','G'],ell)
    assert wraps==[('E','G')] and paper_lower==2*l1+l2+l3-TWO_PI_UP==-3160796026673
    # Chain G, K, SJ, SM, SH, SE, SC, SA follows the list; its first step uses theta_K - theta_G >= 0.
    paper_reverse,wraps=chain_bound(['G','K','SJ','SM','SH','SE','SC','SA'],ell)
    assert wraps==[] and paper_reverse==l6+l4+l5+2*l2+2*l1==3160793892198
    width_G=-paper_reverse-paper_lower
    assert width_G==2134475
    # Printed comparisons of Appendix D.2 and Proposition 9.5.
    assert F(HI)<F('3.792033749')
    assert 2*EPS+F('3.792033749')*F(width_G,AQ)<F('7.562e-6')<F(1,16000)
    D=[[0]*17 for _ in range(17)]
    for i in range(17):
        for j in range(i+1,17):
            t=g[order[i]][order[j]]
            D[i][j]=t;D[j][i]=t-TWO_PI_UP
    for k in range(17):
        for i in range(17):
            for j in range(17):D[i][j]=max(D[i][j],D[i][k]+D[k][j])
    assert all(D[i][i]==0 for i in range(17))
    ref=labels.index(0);maximum=F(0)
    core=labels.index(9)
    assert D[ref][core] >= paper_lower and D[core][ref] >= paper_reverse
    print('Worked angle chains for G verified in exact arithmetic.')
    for j,label in enumerate(labels):
        width=F(-D[j][ref]-D[ref][j],AQ)
        assert width>=0
        dr=2*EPS if order[j]!=7 else F(0)
        upper=dr+F(HI)*width
        assert 0<=upper<F(1,16000),(label,upper)
        maximum=max(maximum,upper)
        print('point',label+1,'relative-angle numerators:',D[ref][j],-D[j][ref],
              'width numerator:',-D[j][ref]-D[ref][j],'denominator:',AQ)
        print('point',label+1,'angle-width <=',float(width),'position-distance <=',float(upper))
    assert maximum<F('0.000007562')
    print('PASS: after rotational alignment, every coordinate error <1/16000')
    print('Maximum exact error bound:',maximum)
if __name__=='__main__':main()
