"""Enumerate the paper's compositions and check their dihedral orbit counts."""
import itertools
import math
if not __debug__: raise RuntimeError('Assertions must be enabled.')

def composition_checks():
    results = []
    cases = [(15, 10, 5, 1), (16, 11, 5, 1), (17, 11, 6, 0),
             (17, 10, 7, 0), (18, 11, 7, 0), (18, 10, 8, 0),
             (20, 12, 8, 0)]
    for n, m, k, minimum in cases:
        total = m - k * minimum
        representatives = set()
        count = 0
        fixed = [0] * (2 * k)
        for bars in itertools.combinations(range(total + k - 1), k - 1):
            stops = (-1,) + bars + (total + k - 1,)
            vector = tuple(stops[i + 1] - stops[i] - 1 + minimum
                           for i in range(k))
            images = [vector[i:] + vector[:i] for i in range(k)]
            reverse = vector[::-1]
            images += [reverse[i:] + reverse[:i] for i in range(k)]
            representatives.add(min(images))
            count += 1
            for j, candidate in enumerate(images):
                fixed[j] += vector == candidate
        assert count == math.comb(total + k - 1, k - 1)
        assert sum(fixed) % (2 * k) == 0
        assert len(representatives) == sum(fixed) // (2 * k)
        results.append(dict(N=n, outer=m, inner=k, positive=bool(minimum),
                            compositions=count, dihedral_orbits=len(representatives),
                            burnside_fixed_counts=fixed))
    return results


if __name__ == '__main__':
    expected=[(126,16),(210,26),(4368,392),(8008,600),(12376,912),(19448,1282),(50388,3260)]
    for result,want in zip(composition_checks(),expected):
        assert (result['compositions'],result['dihedral_orbits'])==want
        print('N=',result['N'],'m=',result['outer'],'compositions=',want[0],'orbits=',want[1])
    print('ALL COMPOSITION COUNTS PASSED')
