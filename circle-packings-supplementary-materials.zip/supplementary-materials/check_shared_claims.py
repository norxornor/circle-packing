#!/usr/bin/env python3
"""Exact checks of computational statements that are not tied to one case:

  * Table 1: every R_N rounded to the nearest 10^-9;
  * Section 4.5 worked example: 1.2 + 1.1 = 2.3, 2.3 + 4.0 = 6.3 > 6.284 > 2 pi;
  * Section 5.5 worked example: the inverse of the 3 x 3 matrix, its stress row
    (1/3, 1/3, 1/3) and the absolute row sums 4/3;
  * Appendix B.2: the alternating-tail condition for every degree used
    (asserted when exact_arithmetic is imported);
  * Appendix B.4: tan(2a) = 5/12, tan(4a) = 120/119, tan(4a - b) = 1 and
    0 < 4a - b < 4/5 < pi/2 for a = arctan(1/5), b = arctan(1/239); (B.6) with
    forty terms; (B.7) Q_theta = 2^40 and Pi+ > 2 pi;
  * Appendix H.3: 4 * 2^40 * 10^15 < 2^92 and the construction grids
    10^80 (N = 16, 18) and 10^60 (N = 17, 20);
  * Section 12.1: c(2s) = 2(s - 1/s), and for b = 1 + sqrt5, c(b) = 2.
"""
from fractions import Fraction as F
from math import isqrt
from pathlib import Path
import importlib.util, sys
if not __debug__: raise RuntimeError('Assertions must be enabled.')
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
import exact_arithmetic                                   # asserts the Appendix B.2 tail conditions

def load(name, relative):
    path = ROOT / relative
    sys.path.insert(0, str(path.parent))
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    return module

def sqrt_bounds(x, scale=10**40):
    n = isqrt(x.numerator*scale*scale // x.denominator)
    lo, hi = F(n, scale), F(n + 1, scale)
    assert lo*lo <= x < hi*hi
    return lo, hi

def atan_series(x, terms):
    lo = sum(((-1)**j * x**(2*j+1) / F(2*j+1) for j in range(terms)), F(0))
    return lo, lo + x**(2*terms+1) / (2*terms+1)          # (B.2) with n_terms even

def appendix_b():
    def tan_sum(x, y): return (x + y) / (1 - x*y)
    t2 = tan_sum(F(1, 5), F(1, 5)); assert t2 == F(5, 12)
    t4 = tan_sum(t2, t2); assert t4 == F(120, 119)
    assert tan_sum(t4, -F(1, 239)) == 1
    alo, ahi = atan_series(F(1, 5), 40); blo, bhi = atan_series(F(1, 239), 40)
    assert 0 < 4*alo - bhi and 4*ahi < F(4, 5)            # 0 < 4a - b < 4a < 4/5
    pilo, pihi = 16*alo - 4*bhi, 16*ahi - 4*blo
    assert F(4, 5) < pilo/2                               # 4/5 < pi/2
    assert F('3.141592653589793238') < pilo < pihi < F('3.141592653589793239')   # (B.6)
    Q_theta, Pi_plus = 2**40, F(6908435304716, 2**40)
    assert Q_theta == 1099511627776 and Pi_plus > 2*F('3.141592653589793239')      # (B.7)
    print('Appendix B.4: Machin identity steps, 0 < 4a-b < 4/5 < pi/2, (B.6), (B.7): PASS')
    return pilo, pihi

def section_4_5(pihi):
    assert F('1.2') + F('1.1') == F('2.3') and F('2.3') + F('4.0') == F('6.3') > F('6.284') > 2*pihi
    print('Section 4.5 example: 6.3 > 6.284 > 2 pi: PASS')

def section_5_5():
    H = [[F(1), F(0), F(1)], [F(0), F(1), F(1)], [F(-1), F(-1), F(1)]]
    # Gauss-Jordan inverse in exact arithmetic.
    n = 3; M = [row[:] + [F(int(i == j)) for j in range(n)] for i, row in enumerate(H)]
    for col in range(n):
        pivot = next(r for r in range(col, n) if M[r][col] != 0); M[col], M[pivot] = M[pivot], M[col]
        M[col] = [x / M[col][col] for x in M[col]]
        for r in range(n):
            if r != col: M[r] = [a - M[r][col]*b for a, b in zip(M[r], M[col])]
    inverse = [row[n:] for row in M]
    assert inverse[2] == [F(1, 3)]*3                                    # s_aux row: the stress
    assert inverse[0] == [F(2, 3), F(-1, 3), F(-1, 3)] and inverse[1] == [F(-1, 3), F(2, 3), F(-1, 3)]
    assert all(sum(abs(x) for x in inverse[i]) == F(4, 3) for i in (0, 1))
    A = [row[:2] for row in H]
    assert [sum(inverse[2][a]*A[a][j] for a in range(3)) for j in range(2)] == [0, 0] and sum(inverse[2]) == 1
    print('Section 5.5 example: stress (1/3,1/3,1/3), row sums 4/3: PASS')

def table_1():
    c16 = load('t1_16', 'n16/certify_construction16.py')
    c17 = load('t1_17', 'n17/verify17_exact.py')
    c20 = load('t1_20', 'n20/verify20_exact.py')
    s5 = sqrt_bounds(F(5))
    t = (sqrt_bounds(1 + 2/s5[1])[0], sqrt_bounds(1 + 2/s5[0])[1])
    b15 = (sqrt_bounds(6 + 2/s5[1] + 4*t[0])[0], sqrt_bounds(6 + 2/s5[0] + 4*t[1])[1])   # (7.5)
    b18 = (sqrt_bounds(F(2))[0] + sqrt_bounds(F(6))[0], sqrt_bounds(F(2))[1] + sqrt_bounds(F(6))[1])
    enclosures = {15: b15, 16: (F(c16.BL), F(c16.BH)), 17: (F(c17.LO), F(c17.HI)), 18: b18,
                  20: (F(c20.LO), F(c20.HI))}
    printed = {15: '4.521356965', 16: '4.615425595', 17: '4.792033748', 18: '4.863703305', 20: '5.122320737'}
    half = F(1, 2*10**9)
    for n, (lo, hi) in enclosures.items():
        r = F(printed[n])
        assert r - half < 1 + lo and 1 + hi < r + half, n          # nearest multiple of 10^-9
    print('Table 1: every R_N rounds to the printed value: PASS')

def appendix_h():
    assert 4*2**40*10**15 < 2**92
    print('Appendix H.3: 4 * 2^40 * 10^15 < 2^92: PASS')

def construction_grids():
    """Appendix H.3: denominators of the construction interval grids."""
    grids = {16: load('h3_16', 'n16/certify_construction16.py').Q, 18: load('h3_18', 'n18/exact18.py').Q,
             17: load('h3_17', 'n17/verify17_exact.py').D, 20: load('h3_20', 'n20/verify20_exact.py').D}
    assert grids == {16: 10**80, 18: 10**80, 17: 10**60, 20: 10**60}
    print('Appendix H.3: construction grids 10^80 (N=16,18), 10^60 (N=17,20): PASS')

def section_12():
    # c(2s) = 2s - 4/(2s) and 2(s - 1/s): after multiplying by s both are
    # polynomials of degree at most 2, so equality at three points proves the identity.
    c = lambda b: b - 4/b
    for s_ in (F(1), F(2), F(7, 3)):
        assert c(2*s_)*s_ == 2*(s_ - 1/s_)*s_
    # b = 1 + sqrt5 in Q(sqrt5), as pairs (x, y) = x + y sqrt5: c(b) = 2 <=> b^2 - 2b - 4 = 0.
    def mul(u, v): return (u[0]*v[0] + 5*u[1]*v[1], u[0]*v[1] + u[1]*v[0])
    b = (F(1), F(1)); b2 = mul(b, b)
    assert (b2[0] - 2*b[0] - 4, b2[1] - 2*b[1]) == (0, 0) and b[0] + b[1] > 0
    print('Section 12.1: c(2s) = 2(s - 1/s), c(1 + sqrt5) = 2: PASS')

if __name__ == '__main__':
    pilo, pihi = appendix_b()
    section_4_5(pihi)
    section_5_5()
    table_1()
    appendix_h()
    construction_grids()
    section_12()
    print('ALL SHARED CLAIMS PASSED')
