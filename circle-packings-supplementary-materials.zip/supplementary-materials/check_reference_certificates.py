"""Reconstruct reference coordinates and residual certificates from the paper.

Coordinates are rebuilt from the paper, with rational endpoint arithmetic.
No primary interval, construction, or matrix routine is used.
The eighteen-circle point order is read only to identify matrix columns.
Exact contact identities are proved in the paper; intervals containing zero
provide consistency checks on these identities, not proofs of equality.
"""
from fractions import Fraction as F
from math import isqrt
from pathlib import Path
import json

if not __debug__: raise RuntimeError('Assertions must be enabled.')

ROOT = Path(__file__).resolve().parent
PREC = 10**100

class V:
    def __init__(self, a, b=None):
        if isinstance(a, V):
            self.a, self.b = a.a, a.b
            return
        a, b = F(a), F(a if b is None else b)
        assert a <= b
        self.a = F((a * PREC).__floor__(), PREC)
        self.b = F((b * PREC).__ceil__(), PREC)
    def __add__(x,y):
        y=V(y); return V(x.a+y.a,x.b+y.b)
    __radd__=__add__
    def __neg__(x): return V(-x.b,-x.a)
    def __sub__(x,y): return x+-V(y)
    def __rsub__(x,y): return V(y)+-x
    def __mul__(x,y):
        y=V(y); v=[a*b for a in (x.a,x.b) for b in (y.a,y.b)]
        return V(min(v),max(v))
    __rmul__=__mul__
    def __truediv__(x,y):
        y=V(y); assert y.a*y.b>0
        return x*V(1/y.b,1/y.a)
    def __rtruediv__(x,y): return V(y)/x
    def sq(x):
        return V(0 if x.a<=0<=x.b else min(x.a*x.a,x.b*x.b),max(x.a*x.a,x.b*x.b))
    def sqrt(x):
        assert x.a>=0
        z=[isqrt((a*PREC*PREC).__floor__()) for a in (x.a,x.b)]
        return V(F(z[0],PREC),F(z[1]+(F(z[1]**2,PREC**2)<x.b),PREC))
    def zero(x): return x.a<=0<=x.b
    def absmax(x): return max(abs(x.a),abs(x.b))

def add(p,q): return tuple(x+y for x,y in zip(p,q))
def sub(p,q): return tuple(x-y for x,y in zip(p,q))
def mul(a,p): return tuple(a*x for x in p)
def turn(p): return -p[1],p[0]
def refl(p): return -p[0],p[1]
def norm(p): return sum(x.sq() for x in p)
def distance(p,q): return norm(sub(p,q))
def meet(p,q,sign=1):
    return add(mul(F(1,2),add(p,q)),mul(sign*(4/distance(p,q)-F(1,4)).sqrt(),turn(sub(q,p))))
def rotate(p,b):
    return add(mul(1-2/b.sq(),p),mul(2*(b.sq()-1).sqrt()/b.sq(),turn(p)))

ENDPOINTS={16:('3.61542559487319398553924416199196524760827792283368976231959231763302032464297878',
               '3.61542559487319398553924416199196524760827792283368976231959231778348360154823159'),
           17:('3.7920337483105791701491239532','3.7920337483105791701491239534'),
           20:('4.1223207369915283214476857921','4.1223207369915283214476857923')}

def construction(n,b):
    if n==16:
        q=[(V(0),-b)]
        for j in range(5): q.append(rotate(q[-1],b))
        a=(V(1),q[1][1]+(4-(q[1][0]-1).sq()).sqrt())
        z=(V(0),q[5][1]-(4-q[5][0].sq()).sqrt())
        m=meet(a,z,-1)
        p=[q[0],refl(q[1]),q[1],refl(q[2]),q[2],refl(a),a,refl(q[3]),q[3],refl(m),m,z,refl(q[4]),q[4],refl(q[5]),q[5]]
        return distance(m,q[3])-4,p
    a=(V(1),-(b.sq()-1).sqrt())
    c=rotate(a,b)
    if n==17:
        f=add(mul(F(1,2),add(a,refl(a))),(V(0),V(3).sqrt()))
        e=add(c,(V(-1),V(3).sqrt()))
        g=(V(0),2*e[1]-f[1])
        alpha=(b.sq()+norm(e)-4)/(2*norm(e))
        h=add(mul(alpha,e),mul((b.sq()/norm(e)-alpha.sq()).sqrt(),turn(e)))
        m=rotate(h,b)
        j=meet(g,m)
        k=(V(0),j[1]+(4-j[0].sq()).sqrt())
        ell=add(mul(F(1,2),add(j,k)),mul(V(3).sqrt()/2,turn(sub(j,k))))
        return norm(ell)-b.sq(),[refl(a),a,refl(c),c,f,refl(e),e,refl(h),h,g,refl(m),m,refl(j),j,k,refl(ell),ell]
    h=rotate(c,b);m=rotate(h,b);u=rotate(m,b);ell=rotate(u,b)
    f=add(a,(V(0),V(2)));e=meet(f,h);j=meet(e,u)
    k=(V(0),j[1]+(4-j[0].sq()).sqrt())
    return distance(ell,k)-4,[refl(a),a,refl(c),c,refl(f),f,refl(h),h,refl(e),e,(V(0),V(0)),refl(m),m,refl(j),j,refl(u),u,k,refl(ell),ell]

def feasible(n):
    lo,hi=ENDPOINTS[n]
    v0,_=construction(n,V(lo));v1,_=construction(n,V(hi))
    assert v0.b<0<v1.a or v1.b<0<v0.a
    b=V(lo,hi);f,p=construction(n,b);assert f.zero()
    contacts=[];boundary=[];slacks=[];inner=[]
    for i,pt in enumerate(p):
        d=norm(pt)-b.sq()
        if d.zero():boundary.append(i)
        else:
            assert d.b<0
            inner.append(i)
        for j in range(i):
            d=distance(pt,p[j])-4
            if d.zero():contacts.append((j,i))
            else:
                assert d.a>0,(n,i,j,d.a)
                slacks.append(d.a)
    expected={16:(21,11,F('.15861')),17:(25,10,F('.1412526818')),20:(26,12,F('.2346221317'))}[n]
    assert (len(contacts),len(boundary))==expected[:2]
    assert min(slacks)>expected[2]
    c=b-4/b
    for i in inner:assert norm(p[i]).b<c.sq().a
    # Original-position recovery inequalities, reconstructed from point labels.
    if n==16:
        for outer,other,upper in [(0,6,'2.4924'),(4,6,'1.6250'),(13,10,'1.0159')]:
            assert distance(mul(c/b,p[outer]),p[other]).b<F(upper)
    if n==20:
        for outer,other,upper in [(3,5,'1.3556'),(12,9,'1.5971')]:
            assert distance(mul(c/b,p[outer]),p[other]).b<F(upper)
        assert all(norm(pt).a>F('2.17')**2 for i,pt in enumerate(p) if i!=10)
    print('INDEPENDENT GEOMETRY',n,'root signs, domains, containment,',len(contacts),'contacts,',len(slacks),'strict noncontacts, recovery: PASS')
    return p,sorted(contacts),boundary

def matrices(points,contacts,boundary,data,kappa,stress):
    n=len(points);d=2*n-1;m=len(contacts)+len(boundary)
    # Build H directly from the stated scalar linear forms, by coefficient extraction.
    rows=[]
    for pair in contacts:
        i,j=pair
        row=[V(0) for _ in range(2*n)]
        for k in (0,1):
            row[2*i+k]=2*(points[i][k]-points[j][k])
            row[2*j+k]=-row[2*i+k]
        rows.append(row[1:])
    for i in boundary:
        row=[V(0) for _ in range(2*n)]
        for k in (0,1):row[2*i+k]=-2*points[i][k]
        rows.append(row[1:])
    extra=data.get('extra_columns',[[z] for z in data.get('extra_column',[])])
    es=data.get('extra_scale',1)
    for i,row in enumerate(rows): row.extend([V(1)]+[V(F(v,es)) for v in (extra[i] if extra else [])])
    assert len(rows)==m and all(len(row)==m for row in rows)
    inverse=[[F(z,data['scale']) for z in row] for row in data['inverse']]
    assert len(inverse)==m and all(len(row)==m for row in inverse)
    # Transpose H for a separately ordered rational dot-product calculation.
    columns=list(zip(*rows));rho=F(0)
    for i,row in enumerate(inverse):
        total=F(0)
        for j,col in enumerate(columns):
            low=sum(min(v*x.a,v*x.b) for v,x in zip(row,col))
            high=sum(max(v*x.a,v*x.b) for v,x in zip(row,col))
            total+=max(abs(F(i==j)-low),abs(F(i==j)-high))
        rho=max(rho,total)
    assert rho<F(1,10**10)
    normp=max(sum(abs(x) for x in row) for row in inverse)
    error=normp*rho/(1-rho)
    assert normp+error<kappa
    assert min(inverse[d])-error>stress
    return m

def references18():
    # Paper Table 10.1: directions expressed as integral multiples of pi/12.
    specification=[([1,7,13,17,21],[4,10],[4,10]),
                   ([3,9,13,17,23],[6,20],[6,20]),
                   ([5,9,13,17,21],[2],[2]),
                   ([3,9,13,17,21],[6],[6]),
                   ([3,7,13,17,21],[10],[10]),
                   ([1,5,9,13,17,21],[],[2,4])]
    # The code order is recovered from supplied labels only after constructing the set.
    import importlib.util
    spec=importlib.util.spec_from_file_location('production18',ROOT/'n18/exact18.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    r2=V(2).sqrt();r3=V(3).sqrt();r6=V(6).sqrt();b=r2+r6;c=2*r2
    # Use quadrant reduction and tabulated 0,15,30,45,60,75 degree values, not 24 rotations.
    trig=[(V(1),V(0)),((r6+r2)/4,(r6-r2)/4),(r3/2,V(F(1,2))),
          (r2/2,r2/2),(V(F(1,2)),r3/2),((r6-r2)/4,(r6+r2)/4)]
    def direction(t):
        quadrant,t=divmod(t%24,6);p=trig[t]
        for _ in range(quadrant):p=turn(p)
        return p
    keys=['m10_a','m10_b','m11_lim3','m11_lim6','m11_lim8','m11_core']
    for j,((twos,cutoffs,missing),key) in enumerate(zip(specification,keys)):
        paper={('0',0)}|{('2',t) for t in twos}|{('C',t) for t in cutoffs}|{('B',t) for t in range(0,24,2) if t not in missing}
        code=[(r,(deg//15)%24) for r,deg in module.SPECS[key]]
        assert set(code)==paper and len(code)==len(paper),(key,set(code)^paper)
        radii={'0':V(0),'2':V(2),'C':c,'B':b}
        p=[mul(radii[r],direction(t)) for r,t in code]
        contacts=[];boundary=[]
        for i in range(len(p)):
            z=norm(p[i])-b.sq()
            if code[i][0]=='B':assert z.zero();boundary.append(i)
            else:assert z.b<0
            for k in range(i):
                z=distance(p[i],p[k])-4
                if z.zero():contacts.append((k,i))
                else:assert z.a>0
        data=json.loads((ROOT/'n18'/('inverse18.json' if j==5 else 'inverse_'+key+'.json')).read_text())
        m=matrices(p,sorted(contacts),boundary,data,4 if j==5 else 3,F(1,70 if j==5 else 64 if j<2 else 100))
        print('INDEPENDENT REFERENCE',j+1,'coordinates, contacts,',m,'matrix rows: PASS')

if __name__=='__main__':
    for n in (16,17,20):
        p,contacts,boundary=feasible(n)
        if n==20:
            retained=[i for i in range(20) if i!=10];index={old:new for new,old in enumerate(retained)}
            p=[p[i] for i in retained];contacts=[(index[i],index[j]) for i,j in contacts];boundary=[index[i] for i in boundary]
        m=matrices(p,contacts,boundary,json.loads((ROOT/f'n{n}'/f'inverse{n}.json').read_text()),{16:5,17:8,20:7}[n],F(1,150 if n==20 else 250))
        print('INDEPENDENT MATRIX',n,m,'rows: PASS')
    references18()
