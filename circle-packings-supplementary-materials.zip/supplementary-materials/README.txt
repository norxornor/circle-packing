Supplementary materials for
Equal circles in a circle: optimal radii for 15, 16, 17, 18 and 20 circles

VERIFYING THE COMPUTATIONS

Run from this directory:

    python3 -E -B verify.py

Requirements: Python 3 and g++ or clang++ with C++17 and signed 128-bit
integer support. The mathematical checks use only the Python standard
library and require no network access. Keep assertions enabled: do not
use Python -O or compile with NDEBUG.

The driver compiles the integer searches, validates every supplied angle
bound before use, derives from the paper every constant used by each
compiled search and requires the program to report exactly those constants,
resolves all radial boxes, checks constructions and local-rigidity bounds,
and checks the printed numerical tables. It also enumerates the cyclic orders
separately and reconstructs the reference coordinates and matrix bounds using
a second rational interval calculation.

A stage passes only if its program exits normally and prints every required
line as a complete line. A completed run has 65 stages and ends with
ALL PAPER CHECKS PASSED. The transcript and the completion record are written
to a separate directory, verification-run/ by default (use --output DIR to
choose another). The driver refuses an output directory that already
contains a transcript or result file; choose a new directory with --output
for each later run. An interrupted run remains incomplete. Any failed bound,
missing table entry, unresolved box, arithmetic overflow, differing constant
or incorrect completion count causes failure. After changing a program or its
inputs, rerun the driver.

CONTENTS

Shared programs and data are here; the case subdirectories are n15, n16,
n17, n18 and n20. Each case directory contains its construction and
exclusion checks, angle tables and rational matrix arrays as applicable.
The submission archive's recorded-verification/ directory contains the
completed run and its environment information.
Appendix H of the paper maps every computational proposition to its files
and gives pseudocode. Appendix C records the exact subdivision counts.
verification-guide.md maps every computational statement of the paper to the check
that verifies it.

exact_arithmetic.py         Rational trigonometric and square-root bounds.
integer_bounds.hpp         Checked integer addition and directed closure.
constants.py               Tables 14-17: shared geometric data, preliminary
                           count bounds and the coverage of every count.
check_shared_claims.py     Table 1, Appendix B.4, worked examples of
                           Sections 4.5 and 5.5, Appendix H.3, Section 12.1.
certificate_summary.py     Outward-rounded root and matrix summaries.
certificate_summary.json   Expected exact printed summaries.
check_compositions.py      Compositions, dihedral orbits and fixed-list counts.
check_consistency.py       Printed count/position rows and interval primitives.
check_reference_certificates.py
                           Separate reconstruction of reference coordinates
                           and matrix residual bounds from the paper; Tables
                           25 and 27 and the contact lists, by label.
verify.py                  Complete verification driver.

The six eighteen-circle reference sets Q1,...,Q6 have these data names:

    Q1  m10_a       Q2  m10_b       Q3  m11_lim3
    Q4  m11_lim6    Q5  m11_lim8    Q6  m11_core

The seventeen-center set Q6 uses inverse18.json; the other five inverse
files use their data names. Matrix arrays are rational proposals checked
against the actual interval coefficients. They are not assumed inverses.
The construction sections prove the exact contact identities. Intervals
containing zero are used only as consistency checks on those identities.
n18/check_references18.py derives every reference set from Table 5 and checks
the exact identities of Sections 10.1-10.3 and the optimal family (1.2).

The PROPOSE_BOUNDS compilation mode proposes angle tables.
The verification driver never enables it. The supplied rational tables
are validated afresh during every complete run. Every compiled search also
accepts --parameters, which prints the constants it uses and exits.

ADDITIONAL IMPLEMENTATION CHECKS

Optional tests cover acceptance rules, failure paths and containment signs:

    python3 -E -B test_matching.py
    python3 -E -B test_invalid_inputs.py
    python3 -E -B test_containment_sign.py

The first compares C++ matching decisions with a separate cyclic-word
specification, including reflections, omissions and interval endpoints.
The second deliberately supplies invalid data, altered program constants and
disabled assertions. These first two tests require g++ and use temporary
files outside the supplementary directory, leaving all supplied inputs
unchanged.

The containment-sign test checks that an unresolved interval sign cannot
certify containment, including a point just outside the container. It also
checks all nineteen centers of the eighteen-circle construction with O added.
This test uses only Python and creates no temporary files.
