Supplementary materials for
Equal circles in a circle: optimal radii for 15, 16, 17, 18 and 20 circles

VERIFYING THE COMPUTATIONS

Run from this directory:

    python3 -E -B verify.py

Requirements: Python 3 and g++ or clang++ with C++17 and signed 128-bit
integer support. The mathematical checks use only the Python standard
library and require no network access. Keep assertions enabled: do not
use Python -O or compile with NDEBUG.

The driver compiles the integer searches, validates every supplied angle
bound before use, resolves all radial boxes, checks constructions and
local-rigidity bounds, and checks the printed numerical tables. It also
enumerates the cyclic orders separately and reconstructs the reference
coordinates and matrix bounds using a second rational interval calculation.

A completed run has 47 stages and ends with ALL PAPER CHECKS PASSED.
The exact output is in verification-output.txt. The completion status,
software versions and elapsed times are in verification-results.json.
An interrupted run remains incomplete. Any failed bound, missing table
entry, unresolved box, arithmetic overflow or incorrect completion count
causes failure. After changing a program or its inputs, rerun the driver.

CONTENTS

Shared programs and data are here; the only subdirectories are n15, n16,
n17, n18 and n20. Each case directory contains its construction and
exclusion checks, angle tables and rational matrix arrays as applicable.
Appendix H of the paper maps every computational proposition to its files
and gives pseudocode. Appendix C records the exact subdivision counts.

exact_arithmetic.py         Rational trigonometric and square-root bounds.
integer_bounds.hpp         Checked integer addition and directed closure.
constants.py               Shared geometric and preliminary count bounds.
certificate_summary.py     Outward-rounded root and matrix summaries.
certificate_summary.json   Expected exact printed summaries.
check_compositions.py      Compositions, dihedral orbits and fixed-list counts.
check_consistency.py       Printed count/position rows and interval primitives.
check_reference_certificates.py
                           Separate reconstruction of reference coordinates
                           and matrix residual bounds from the paper.
verify.py                  Complete verification driver.

The six eighteen-circle reference sets Q1,...,Q6 have these data names:

    Q1  m10_a       Q2  m10_b       Q3  m11_lim3
    Q4  m11_lim6    Q5  m11_lim8    Q6  m11_core

The seventeenth center set Q6 uses inverse18.json; the other five inverse
files use their data names. Matrix arrays are rational proposals checked
against the actual interval coefficients. They are not assumed inverses.
The construction sections prove the exact contact identities. Intervals
containing zero are used only as consistency checks on those identities.

The historical PROPOSE_BOUNDS compilation mode proposes angle tables.
The verification driver never enables it. The supplied rational tables
are validated afresh during every complete run.

ADDITIONAL IMPLEMENTATION CHECKS

Two optional tests reproduce the acceptance-rule and failure-path checks:

    python3 -E -B test_matching.py
    python3 -E -B test_invalid_inputs.py

The first compares C++ matching decisions with a separate cyclic-word
specification, including reflections, omissions and interval endpoints.
The second deliberately supplies invalid data and disabled assertions.
Both use temporary files outside the supplementary directory and leave
all supplied inputs unchanged. They require g++.
