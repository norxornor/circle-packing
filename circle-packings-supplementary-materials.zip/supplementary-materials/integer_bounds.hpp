// Exact integer operations for the circular-order exclusions.
// See the paper's appendix on finite exclusion by rational intervals.
#pragma once
#include <algorithm>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <limits>
#ifdef NDEBUG
#error "Assertions are proof checks; do not compile with NDEBUG."
#endif
using Z = int64_t;

[[noreturn]] inline void fail(const char *message) {
    std::cerr << "FAIL: " << message << '\n';
    std::exit(1);
}

inline Z add(Z x, Z y) {
    // Form the sum in a wider type before testing the 64-bit range.
    __int128 sum = (__int128)x + y;
    if (sum < std::numeric_limits<Z>::min() ||
        sum > std::numeric_limits<Z>::max()) {
        fail("integer overflow in angle addition");
    }
    return Z(sum);
}

template <std::size_t N>
bool positive_cycle(Z (&distance)[N][N]) {
    // distance[i][j] bounds theta_j - theta_i from below. Every
    // update adds valid inequalities. A positive diagonal would
    // imply 0 > 0 and therefore excludes the whole radius box.
    for (std::size_t k = 0; k < N; ++k) {
        for (std::size_t i = 0; i < N; ++i) {
            for (std::size_t j = 0; j < N; ++j) {
                distance[i][j] = std::max(distance[i][j],
                    add(distance[i][k], distance[k][j]));
            }
        }
        for (std::size_t i = 0; i < N; ++i) {
            if (distance[i][i] > 0) return true;
        }
    }
    return false;
}
