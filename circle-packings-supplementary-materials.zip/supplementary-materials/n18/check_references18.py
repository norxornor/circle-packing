#!/usr/bin/env python3
"""Exact checks of Sections 10.1-10.3, 10.8 and Table 26 (eighteen circles).

All arithmetic is exact in Q(sqrt2, sqrt3); strict comparisons use rational
interval enclosures of the field elements. Directions are integers k meaning
k*pi/12. Checked:
  * (10.1)-(10.3): b18 = sqrt2+sqrt6 = 4cos(pi/12) = csc(pi/12); the dodecagon,
    hexagon and mixed contacts of P18; P18 feasible; P18 with O added feasible;
  * Section 10.2: eta(b18) = pi/12 and c(b18) = 2 sqrt2 exactly;
  * Section 10.3: g(b,b) = pi/6, h(2) = pi/12, h(c) = pi/6, g(2,2) = pi/3;
    every row of Table 5 produces its reference set by (10.5); the angle sum
    (10.6) closes for rows Q1-Q5 and the six gaps of Q6 are pi/3; the worked Q3
    example; the omitted boundary directions; the worked field example;
  * Table 26: the coordinate order of exact18.SPECS (used by every matrix);
  * Section 10.7: in Q6 the boundary center at direction 0 touches the radius-2
    center at direction pi/12;
  * Theorem 1.1 / Section 10.8: the set (1.2) equals Q6 plus b18 e(theta); it is
    feasible for every theta in [pi/6, pi/3]; the members theta = pi/6 and
    theta = pi/4 have largest boundary gaps pi/3 and pi/4.
"""
from fractions import Fraction as F
from pathlib import Path
import sys
if not __debug__:
    raise RuntimeError('Run without -O: assertions are part of this certificate.')
sys.path.insert(0, str(Path(__file__).resolve().parent))
import exact18 as x18
from exact18 import K, B, C, SQ2, SQ3, SQ6, ANG, SPECS, TABLE5

def e(k): return ANG[k % 24]
def point(radius, k): return (radius*e(k)[0], radius*e(k)[1])
def dist2(p, q): return (p[0]-q[0]).sq() + (p[1]-q[1]).sq()
def positive(z): return z.interval().l > 0
def nonpositive(z):
    """Certify z <= 0; an interval of unresolved sign is not a certificate."""
    return z.zero() or z.interval().h <= 0
def at_least_4(z):
    """z >= 4 exactly: either z = 4 in the field or a strict interval bound."""
    d = z - 4
    return d.zero() or d.interval().l > 0
RADIUS = {'0': K(0), '2': K(2), 'C': C, 'B': B}
COS15, SIN15 = e(1)

def identities():
    # (10.1): b18 = sqrt2+sqrt6 = 4cos(pi/12) = csc(pi/12).
    assert (4*COS15 - B).zero() and (B*SIN15 - 1).zero()
    # Section 10.2: eta = arcsin(1/b) = pi/12, and c(b) = b - 4/b = 2 sqrt2.
    assert (SIN15*B - 1).zero()
    assert (B*C - B.sq() + 4).zero() and (C - 2*SQ2).zero()
    # Section 10.3 contact angles, comparing cosines of angles in [0, pi].
    cos30, cos60 = e(2)[0], e(4)[0]
    assert ((B.sq() - 2) - B.sq()*cos30).zero()            # g(b,b): 1-2/b^2 = cos(pi/6)
    assert ((4 + B.sq() - 4) - 4*B*COS15).zero()             # h(2): (r^2+b^2-4)/(2rb) = cos(pi/12)
    assert ((C.sq() + B.sq() - 4) - 2*C*B*cos30).zero()      # h(c) = pi/6
    assert ((4 + 4 - 4) - 8*cos60).zero()                    # g(2,2) = pi/3
    # (10.2): mixed squared distance at angular separation pi/12.
    assert (B.sq() + 4 - 4*B*COS15 - 4).zero()
    print('Exact identities (10.1), (10.2), eta = pi/12, c = 2 sqrt2 and the four contact angles: PASS')

def ring18():
    """P18 = {b e(j pi/6)} u {2 e(pi/12 + j pi/3)}; P18 and P18 u {O} are feasible."""
    p18 = [point(B, 2*j) for j in range(12)] + [point(K(2), 1 + 4*j) for j in range(6)]
    spec = sorted((r, (a//15) % 24) for r, a in SPECS['ring18'])
    assert spec == sorted([('B', 2*j) for j in range(12)] + [('2', 1 + 4*j) for j in range(6)])
    for points, name in ((p18, 'P18'), (p18 + [(K(0), K(0))], 'P18 with O')):
        for i in range(len(points)):
            assert nonpositive((points[i][0].sq() + points[i][1].sq()) - B.sq())
            for j in range(i):
                assert at_least_4(dist2(points[i], points[j])), (name, i, j)
    print('P18 is feasible and adding O gives a feasible nineteen-center set: PASS')

def table5_directions(name):
    """(10.5) in units of pi/12: h(2) = 1, h(c) = 2, outer contact step 2, g(2,2) = 4."""
    first, radii, counts = TABLE5[name]
    h = {'2': 1, 'C': 2}
    theta, interior, boundary, gaps = first, [], [], []
    for i, (r, q) in enumerate(zip(radii, counts)):
        nxt = radii[(i + 1) % len(radii)]
        interior.append((r, theta % 24))
        if q == 0:
            assert r == nxt == '2'
            gap = 4
        else:
            boundary += [(theta + h[r] + 2*j) % 24 for j in range(q)]
            gap = h[r] + 2*(q - 1) + h[nxt]
        gaps.append(gap)
        theta += gap
    assert theta == first + 24, name                           # one full turn
    return interior, boundary, gaps

def references():
    # Table 26: radius-2, radius-c and radius-b indices after centers 0 and 1, in order.
    TABLE26 = {'m10_a':   ([13, 17, 21, 1, 7], [4, 10], [12, 14, 16, 20, 22, 0, 2, 6, 8]),
               'm10_b':   ([13, 17, 23, 3, 9], [20, 6], [12, 14, 16, 22, 0, 2, 4, 8, 10]),
               'm11_lim3':([13, 17, 21, 5, 9], [2], [12, 14, 16, 20, 22, 0, 4, 6, 8, 10]),
               'm11_lim6':([13, 17, 21, 3, 9], [6], [12, 14, 16, 20, 22, 0, 2, 4, 8, 10]),
               'm11_lim8':([13, 17, 21, 3, 7], [10], [12, 14, 16, 20, 22, 0, 2, 4, 6, 8]),
               'm11_core':([1, 5, 9, 13, 17, 21], [], [0, 6, 8, 10, 12, 14, 16, 20, 22])}
    OMITTED = {'m10_a': {4, 10}, 'm10_b': {20, 6}, 'm11_lim3': {2}, 'm11_lim6': {6},
               'm11_lim8': {10}, 'm11_core': {2, 4}}                  # Section 10.3
    for name, (twos, cs, bs) in TABLE26.items():
        interior, boundary, gaps = table5_directions(name)
        n_c = sum(1 for r, _ in interior if r == 'C')
        m = len(boundary)                                             # includes (0,-b), direction 18
        if name != 'm11_core':
            assert sum(gaps) == 2*(m + n_c) == 24                     # (10.6)
        else:
            assert gaps == [4]*6                                      # six gaps of pi/3
        # Table 5 and Table 26 describe the same set of centers.
        assert sorted(k for r, k in interior if r == '2') == sorted(twos)
        assert sorted(k for r, k in interior if r == 'C') == sorted(cs)
        assert sorted(boundary) == sorted(bs + [18])
        assert set(range(0, 24, 2)) - set(boundary) == OMITTED[name]
        # exact18.SPECS lists centers 0 = (0,-b), 1 = O, then Table 26 rows in order.
        spec = [(r, (a//15) % 24) for r, a in SPECS[name]]
        assert spec == [('B', 18), ('0', 0)] + [('2', k) for k in twos] + \
                       [('C', k) for k in cs] + [('B', k) for k in bs], name
    # The worked example: Q3 interior directions and gaps.
    interior, boundary, gaps = table5_directions('m11_lim3')
    assert [k for _, k in interior] == [2, 5, 9, 13, 17, 21]         # pi/6, 5pi/12, ..., 7pi/4
    assert gaps == [3, 4, 4, 4, 4, 5]                                # pi/4, pi/3 x4, 5pi/12
    assert sorted(boundary) == [k for k in range(0, 24, 2) if k != 2]
    # Worked field example: first interior center of Q3 and its first boundary neighbor.
    p, q = point(C, 2), point(B, 4)
    assert (p[0] - SQ6).zero() and (p[1] - SQ2).zero()
    assert (q[0] - (SQ2 + SQ6)/2).zero() and (q[1] - (SQ6 + 3*SQ2)/2).zero()
    assert (dist2(p, q) - 4).zero()
    # Section 10.7: in Q6, direction 0 (boundary) touches direction pi/12 (radius 2).
    assert (dist2(point(B, 0), point(K(2), 1)) - 4).zero()
    # Table 7 (Section 10.4): deleting the zero target merges its adjacent counts 1 and 1
    # into 2; the remaining targets and counts are those of Q3, up to a cyclic shift.
    radii, counts = ['c', '2', '2', '0', '2', '2', '2'], [1, 2, 1, 1, 2, 2, 2]
    i = radii.index('0')
    merged_radii = radii[:i] + radii[i+1:]
    merged_counts = counts[:i-1] + [counts[i-1] + counts[i]] + counts[i+1:]
    assert counts[i-1] == counts[i] == 1 and merged_counts[i-1] == 2
    _, q3_radii, q3_counts = TABLE5['m11_lim3']
    q3 = ([r.lower() for r in q3_radii], list(q3_counts))
    assert any((merged_radii[k:] + merged_radii[:k], merged_counts[k:] + merged_counts[:k]) == q3
               for k in range(len(merged_radii)))
    print('Table 5 rows produce the six references by (10.5); (10.6); Q3 example; omitted directions; Table 26 order: PASS')
    print('Table 7 example: merged counts give the targets and counts of Q3: PASS')

def family():
    """Theorem 1.1 (1.2) and Section 10.8."""
    core = [(r, (a//15) % 24) for r, a in SPECS['m11_core']]
    paper = {('0', 0)} | {('2', 1 + 4*j) for j in range(6)} | \
            {('B', 2*j) for j in (0, 3, 4, 5, 6, 7, 8, 9, 10, 11)}
    assert set(core) == paper and len(core) == len(paper) == 17
    # Feasibility for every theta in [2, 4] (units of pi/12). For a center at
    # direction k, the least angular separation from the interval is attained
    # at the nearer endpoint (0 inside), and D(b, r; angle) increases on [0, pi].
    for r, k in core:
        sep = 0 if k in (2, 3, 4) else min((2 - k) % 24, (k - 4) % 24)
        assert 0 <= sep <= 12
        cos_sep = e(sep)[0]
        d = B.sq() + RADIUS[r].sq() - 2*B*RADIUS[r]*cos_sep
        assert at_least_4(d), (r, k, sep)
    # Noncongruence: largest gap between boundary directions.
    boundary = sorted(k for r, k in core if r == 'B')
    def largest_gap(extra):
        dirs = sorted(boundary + [extra])
        return max((dirs[(i + 1) % len(dirs)] - dirs[i]) % 24 for i in range(len(dirs)))
    assert largest_gap(2) == 4 and largest_gap(3) == 3              # pi/3 and pi/4
    print('Family (1.2): equals Q6 plus b e(theta), feasible for all theta in [pi/6, pi/3]; gaps pi/3 vs pi/4: PASS')

if __name__ == '__main__':
    identities()
    ring18()
    references()
    family()
    print('ALL EIGHTEEN-CIRCLE REFERENCE CHECKS PASSED')
