#!/usr/bin/env python3
"""Exact local isolation of both n=18 closed-box m=10 limiting candidates.

Each candidate is given in exact18.py. After fixing x_0=0,
every feasible configuration at the same B whose maximum coordinate
displacement is less than 1/1536 equals that candidate exactly.
This supplies the linear hypotheses of the paper's local-rigidity lemma
for Q1 and Q2 (and, when selected, Q3, Q4, Q5). The main proof combines
these local bounds with exhaustive radius and order restrictions.
"""
from fractions import Fraction as F
from pathlib import Path
import json
import sys
if not __debug__:
    raise RuntimeError('Run without -O: assertions are part of this certificate.')
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
import exact18 as c

def verify(name, verbose=True):
    B, points, contacts, boundary = c.get_candidate(name)
    n, d = 18, 35
    m = len(contacts)+len(boundary)
    is_m10 = name in ('m10_a', 'm10_b')
    expected = (34, 10) if is_m10 else (32, 11)
    assert len(points) == n and (len(contacts),len(boundary)) == expected
    assert is_m10 or name in ('m11_lim3', 'm11_lim6', 'm11_lim8')
    extra = m-d-1
    stress_den = 64 if is_m10 else 100
    data = json.loads(Path(__file__).with_name('inverse_'+name+'.json').read_text())
    VS, v = data['extra_scale'], data['extra_columns']
    assert isinstance(VS, int) and VS > 0
    assert len(v) == m and all(len(row) == extra and all(isinstance(z, int) for z in row) for row in v)
    rows = []
    for i, j in sorted(contacts):
        row = [c.I(0) for _ in range(2*n)]
        for k in range(2):
            z = 2*(points[i][k]-points[j][k])
            row[2*i+k], row[2*j+k] = z, -z
        rows.append(row[1:]+[c.I(1)]+[c.I(F(z, VS)) for z in v[len(rows)]])
    for i in sorted(boundary):
        row = [c.I(0) for _ in range(2*n)]
        for k in range(2):
            row[2*i+k] = -2*points[i][k]
        rows.append(row[1:]+[c.I(1)]+[c.I(F(z, VS)) for z in v[len(rows)]])
    assert len(rows) == m and all(len(row) == m for row in rows)
    PS, P = data['scale'], data['inverse']
    assert isinstance(PS, int) and PS > 0
    assert len(P) == m and all(len(row) == m and all(isinstance(z, int) for z in row) for row in P)
    max_row_sum = 0
    for i in range(m):
        row_sum = 0
        for j in range(m):
            lo = hi = 0
            for k in range(m):
                x, y, z = rows[k][j].l, rows[k][j].h, P[i][k]
                lo += min(z*x, z*y)
                hi += max(z*x, z*y)
            target = c.Q*PS if i == j else 0
            row_sum += max(abs(target-lo), abs(target-hi))
        max_row_sum = max(max_row_sum, row_sum)
    rho = F(max_row_sum, c.Q*PS)
    pnorm = F(max(sum(abs(z) for z in row) for row in P), PS)
    assert rho < F(1, 10**10)
    error = rho*pnorm/(1-rho)
    inverse_norm = pnorm+error
    stress_min = min(F(z, PS)-error for z in P[d])
    assert inverse_norm < 3
    assert stress_min > F(1, stress_den)
    # 8 bounds each contact quadratic error; 64 bounds reciprocal weights.
    # ||u|| <= 3 * 8 * 64 * ||u||^2 = 1536 ||u||^2.
    threshold_den = 3*8*stress_den
    if verbose:
        print(name, 'PASS: inverse infinity norm <3; each normalized stress weight >1/'+str(stress_den))
        print('  Residual upper bound:', float(rho))
        print('  Inverse norm upper bound:', float(inverse_norm))
        print('  Minimum stress lower bound:', float(stress_min))
        print('  Local isolation: x_0=0, max coordinate displacement <1/'+str(threshold_den)+'.')
    return rho, inverse_norm, stress_min

if __name__ == '__main__':
    for candidate in sys.argv[1:] or ('m10_a', 'm10_b'):
        verify(candidate)
