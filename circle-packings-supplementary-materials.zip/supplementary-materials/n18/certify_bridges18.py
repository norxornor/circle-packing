#!/usr/bin/env python3
"""Exact derivative and combinatorial checks for n=18 radial-to-Cartesian bridges.
The theorem and its assumptions are stated in the paper's position-bound lemma for eighteen circles.
"""
from exact18 import I,K,Q,B,C,SPECS,exact_points,dist2,get_candidate
from fractions import Fraction as F
import json
from pathlib import Path
EPS=F(1,10**6)


def abs_upper(z):return max(abs(z.l),abs(z.h))
def h_derivative(b,r):
    co=(r.sq()+b.sq()-4)/(2*r*b)
    si=(1-co.sq()).sqrt()
    return (b.sq()-r.sq()-4)/(2*b*r.sq()*si)
def g_derivative_r(r,s):
    co=(r.sq()+s.sq()-4)/(2*r*s)
    si=(1-co.sq()).sqrt()
    return -(r.sq()-s.sq()+4)/(2*r.sq()*s*si)

def verify(verbose=True):
    b=B.interval(); c=C.interval(); r2=I(2-EPS,2+EPS);rc=c+I(-EPS,EPS)
    assert r2.l>(b-2).h and rc.h<b.l
    # The rational target box used by the global integer checker is inside C+-eps.
    assert I('2.828426124746191').l>(c-EPS).h
    assert I('2.828428124746190').h<(c+EPS).l
    dh2=h_derivative(b,r2); dhc=h_derivative(b,rc)
    assert abs_upper(dh2)<F('.867')*Q and abs_upper(dhc)<F('.095')*Q
    dg=g_derivative_r(r2,r2); assert abs_upper(dg)<F('.289')*Q
    # Check the coarser worked estimate printed for h' near radius 2.
    radius_lo,radius_hi=F('1.999999'),F('2.000001')
    boundary_lo,boundary_hi=F('3.863703'),F('3.863704')
    delta_lo=4*radius_lo**2*boundary_lo**2-(radius_hi**2+boundary_hi**2-4)**2
    assert delta_lo>F('15.99')>F('3.998')**2
    assert (boundary_hi**2-radius_lo**2-4)/(radius_lo*F('3.998'))<F('.867')
    # Coarser rational rows printed in the derivative appendix.
    for rl,rh,sl,sh,disc,root,num,bound in [
        ('1.999999','2.000001','3.863703','3.863704','15.99','3.998','6.928213','.867'),
        ('2.828426124746190','2.828428124746191','3.863703','3.863704','119.424','10.928','2.928215','.095'),
        ('1.999999','2.000001','1.999999','2.000001','47.9998','6.928','4.000008','.289')]:
        rl,rh,sl,sh,disc,root,num,bound=map(F,(rl,rh,sl,sh,disc,root,num,bound))
        assert rl>0 and sl>0 and max(abs(rl-sh),abs(rh-sl))<2<rl+sl
        assert rl*rl+sl*sl-4>0
        assert 4*rl*rl*sl*sl-(rh*rh+sh*sh-4)**2>disc>root*root
        assert max(abs(rl*rl-sh*sh+4),abs(rh*rh-sl*sl+4))<=num
        assert num/(rl*root)<bound
    assert F('2.828427124746190')**2<8<F('2.828427124746191')**2
    results={}
    for name,mult in [('m10_a',56),('m10_b',56),('m11_lim3',48),('m11_lim6',48),('m11_lim8',48),('m11_core',44)]:
        p=exact_points(name);spec=SPECS[name]
        order=sorted((i for i,(r,a) in enumerate(spec) if r!='0'),key=lambda i:spec[i][1]%360)
        mixed=ii=oo=0
        for j,i in enumerate(order):
            k=order[(j+1)%len(order)]
            target_gap=(spec[k][1]-spec[i][1])%360
            assert 0<target_gap<=180,(name,'orientedgap',i,k,target_gap)
            assert (dist2(p[i],p[k])-4).zero(),(name,'nontightgap',i,k)
            types=spec[i][0],spec[k][0]
            if types==('B','B'):oo+=1
            elif 'B' in types:mixed+=1
            else:
                assert types==('2','2');ii+=1
        error_count=mixed+ii
        assert (1+b*error_count).h<mult*Q
        if name.startswith('m10'):
            local=F(1,1536)
            assert mult*EPS<local
        elif name=='m11_core':
            local=F(1,2240)
            assert mult*EPS<local
        else:
            local=F(1,2400)
            assert mult*EPS<local
        results[name]=dict(noncentral_order=order,outer_outer_edges=oo,mixed_edges=mixed,inner_inner_edges=ii,
                           angular_error_multiplier=error_count,coordinate_error_multiplier=mult,
                           eps=str(EPS),local_radius=str(local) if local else None)
        if verbose:print(name,'PASS: angular error <',error_count,'eps; coordinate error <',mult,'eps')
    if verbose:
        print('Derivative bounds .867, .095, .289 and the worked rational estimate verified.')
        print('|h prime| < 1 on both radius boxes; |partial g/partial r| < 1/2 near(2,2).')
        print('All cases assume the correct cyclic order, all listed outer radii equal B,')
        print('each noncentral inner radius within eps of its listed value, and core radius <= eps.')
    return results

if __name__=='__main__':
    data=verify()
    Path(__file__).with_name('bridge_bounds18.json').write_text(json.dumps(data,indent=2))
