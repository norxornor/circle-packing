#!/usr/bin/env python3
"""Exact derivative and combinatorial checks for Proposition 10.6, Lemma 10.7,
Table 10 and Appendix F (Table 24).

The radial windows are those accepted by the search of Proposition 10.4
(validate_angles.py); the constants (kappa, sigma*) are those of Table 8.
"""
from exact18 import I,K,Q,B,C,SPECS,exact_points,dist2,get_candidate
from fractions import Fraction as F
from validate_angles import EPS as SEARCH_EPS, WINDOW_C
EPS=F(1,10**6)                                   # (10.7)
assert EPS==SEARCH_EPS


def abs_upper(z):return max(abs(z.l),abs(z.h))
def h_derivative(b,r):
    co=(r.sq()+b.sq()-4)/(2*r*b)
    si=(1-co.sq()).sqrt()
    return (b.sq()-r.sq()-4)/(2*b*r.sq()*si)
def g_derivative_r(r,s):
    co=(r.sq()+s.sq()-4)/(2*r*s)
    si=(1-co.sq()).sqrt()
    return -(r.sq()-s.sq()+4)/(2*r.sq()*s*si)

def verify(verbose=True):
    b=B.interval(); c=C.interval(); r2=I(2-EPS,2+EPS);rc=c+I(-EPS,EPS)
    # Appendix F: 3.863703 < b18 < 3.863704 and 2.828427124746190 < c < 2.828427124746191.
    assert I('3.863703').h<b.l and b.h<I('3.863704').l
    assert F('2.828427124746190')**2<8<F('2.828427124746191')**2
    # The windows accepted by the search lie in these domains (Proposition 10.4).
    assert I(WINDOW_C[0]).l>=rc.l and I(WINDOW_C[1]).h<=rc.h
    # Proposition 10.6 domains: positive radii and strict triangle inequalities |r-s| < 2 < r+s.
    for r,s_ in ((r2,b),(rc,b),(r2,r2)):
        assert r.l>0 and s_.l>0
        assert (r-s_).h<2*Q and (s_-r).h<2*Q and (r+s_).l>2*Q
    assert r2.l>(b-2).h and rc.h<b.l
    dh2=h_derivative(b,r2); dhc=h_derivative(b,rc)
    assert abs_upper(dh2)<F('.867')*Q and abs_upper(dhc)<F('.095')*Q
    dg=g_derivative_r(r2,r2); assert abs_upper(dg)<F('.289')*Q
    # Check the coarser worked estimate printed for h' near radius 2.
    radius_lo,radius_hi=F('1.999999'),F('2.000001')
    boundary_lo,boundary_hi=F('3.863703'),F('3.863704')
    delta_lo=4*radius_lo**2*boundary_lo**2-(radius_hi**2+boundary_hi**2-4)**2
    assert delta_lo>F('15.99')>F('3.998')**2
    assert (boundary_hi**2-radius_lo**2-4)/(radius_lo*F('3.998'))<F('.867')
    # Coarser rational rows printed in the derivative appendix.
    for rl,rh,sl,sh,disc,root,num,bound in [
        ('1.999999','2.000001','3.863703','3.863704','15.99','3.998','6.928213','.867'),
        ('2.828426124746190','2.828428124746191','3.863703','3.863704','119.424','10.928','2.928215','.095'),
        ('1.999999','2.000001','1.999999','2.000001','47.9998','6.928','4.000008','.289')]:
        rl,rh,sl,sh,disc,root,num,bound=map(F,(rl,rh,sl,sh,disc,root,num,bound))
        assert rl>0 and sl>0 and max(abs(rl-sh),abs(rh-sl))<2<rl+sl
        assert rl*rl+sl*sl-4>0
        assert 4*rl*rl*sl*sl-(rh*rh+sh*sh-4)**2>disc>root*root
        assert max(abs(rl*rl-sh*sh+4),abs(rh*rh-sl*sl+4))<=num
        assert num/(rl*root)<bound
    assert F('2.828427124746190')**2<8<F('2.828427124746191')**2
    results={}
    # Table 10: n_loss, the printed value 1+3.864 n_loss and its strict bound (units of 10^-6);
    # Table 8 thresholds sigma*/(8 kappa).
    TABLE10={'m10_a':(14,'55.096',56),'m10_b':(14,'55.096',56),'m11_lim3':(12,'47.368',48),
             'm11_lim6':(12,'47.368',48),'m11_lim8':(12,'47.368',48),'m11_core':(11,'43.504',44)}
    TABLE8={'m10_a':(3,F(1,64)),'m10_b':(3,F(1,64)),'m11_lim3':(3,F(1,100)),'m11_lim6':(3,F(1,100)),
            'm11_lim8':(3,F(1,100)),'m11_core':(4,F(1,70))}
    assert b.h<I('3.864').l
    for name,mult in [('m10_a',56),('m10_b',56),('m11_lim3',48),('m11_lim6',48),('m11_lim8',48),('m11_core',44)]:
        p=exact_points(name);spec=SPECS[name]
        order=sorted((i for i,(r,a) in enumerate(spec) if r!='0'),key=lambda i:spec[i][1]%360)
        mixed=ii=oo=0
        for j,i in enumerate(order):
            k=order[(j+1)%len(order)]
            target_gap=(spec[k][1]-spec[i][1])%360
            assert 0<target_gap<=180,(name,'orientedgap',i,k,target_gap)
            assert (dist2(p[i],p[k])-4).zero(),(name,'nontightgap',i,k)
            types=spec[i][0],spec[k][0]
            if types==('B','B'):oo+=1
            elif 'B' in types:mixed+=1
            else:
                assert types==('2','2');ii+=1
        error_count=mixed+ii
        n_loss,printed,bound=TABLE10[name]
        assert error_count==n_loss and mult==bound
        assert 1+F('3.864')*n_loss==F(printed)<bound
        assert (1+b*error_count).h<mult*Q
        kappa,sigma=TABLE8[name]
        assert mult*EPS<sigma/(8*kappa)                  # Section 10.7
        local=sigma/(8*kappa)
        assert local=={'m10_a':F(1,1536),'m10_b':F(1,1536),'m11_core':F(1,2240)}.get(name,F(1,2400))
        results[name]=dict(noncentral_order=order,outer_outer_edges=oo,mixed_edges=mixed,inner_inner_edges=ii,
                           angular_error_multiplier=error_count,coordinate_error_multiplier=mult,
                           eps=str(EPS),local_radius=str(local) if local else None)
        if verbose:print(name,'PASS: angular error <',error_count,'eps; coordinate error <',mult,'eps')
    if verbose:
        print('Derivative bounds .867, .095, .289 and the worked rational estimate verified.')
        print('|h prime| < 1 on both radius boxes; |partial g/partial r| < 1/2 near(2,2).')
        print('All cases assume the correct cyclic order, all listed outer radii equal B,')
        print('each noncentral inner radius within eps of its listed value, and core radius <= eps.')
    return results

if __name__=='__main__':
    verify()
