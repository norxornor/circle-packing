"""Exact seventeen-point reference Q6 for the eighteen-circle proof.
Uses exact18.py, data name m11_core. Point 0=(0,-B); fix its x-coordinate.
The extra outer point is omitted and may occupy the 30..60 degree sector.
"""
from pathlib import Path
import importlib.util
spec=importlib.util.spec_from_file_location('exact18',Path(__file__).resolve().parent/'exact18.py')
a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
I,D=a.I,a.Q

def construct():return a.get_candidate('m11_core')
