#!/usr/bin/env python3
"""Exact Q(sqrt(2),sqrt(3)) n=18 candidates and a supporting seventeen-point set.
Checks the reference coordinates and pair distances used in the paper's
eighteen-circle proof. Uses only the Python standard library.
"""
from fractions import Fraction as F
from math import isqrt
if not __debug__:
    raise RuntimeError('Run without -O: assertions are part of this certificate.')
Q=10**80

class I:
    __slots__=('l','h')
    def __init__(self,a,b=None,raw=False):
        if raw:self.l,self.h=a,b;return
        if isinstance(a,I):self.l,self.h=a.l,a.h;return
        a=F(a);b=a if b is None else F(b)
        self.l=a.numerator*Q//a.denominator
        self.h=-((-b.numerator*Q)//b.denominator)
    def __add__(a,b):
        b=I(b);return I(a.l+b.l,a.h+b.h,raw=True)
    __radd__=__add__
    def __neg__(a):return I(-a.h,-a.l,raw=True)
    def __sub__(a,b):return a+-I(b)
    def __rsub__(a,b):return I(b)+-a
    def __mul__(a,b):
        b=I(b);v=[a.l*b.l,a.l*b.h,a.h*b.l,a.h*b.h]
        return I(min(v)//Q,-((-max(v))//Q),raw=True)
    __rmul__=__mul__
    def __truediv__(a,b):
        b=I(b);assert b.l*b.h>0
        v=[F(x*Q,y) for x in (a.l,a.h) for y in (b.l,b.h)]
        lo,hi=min(v),max(v)
        return I(lo.numerator//lo.denominator,-((-hi.numerator)//hi.denominator),raw=True)
    def __rtruediv__(a,b):return I(b)/a
    def sq(a):
        lo=0 if a.l<=0<=a.h else min(a.l*a.l,a.h*a.h)
        hi=max(a.l*a.l,a.h*a.h)
        return I(lo//Q,-((-hi)//Q),raw=True)
    def sqrt(a):
        assert a.l>=0
        lo,hi=isqrt(a.l*Q),isqrt(a.h*Q)
        if hi*hi<a.h*Q:hi+=1
        return I(lo,hi,raw=True)

class K:
    """a0+a1 sqrt2+a2 sqrt3+a3 sqrt6, with rational coefficients."""
    __slots__=('a',)
    def __init__(self,a=0):
        self.a=a.a if isinstance(a,K) else tuple(map(F,a)) if isinstance(a,(list,tuple)) else (F(a),F(0),F(0),F(0))
        assert len(self.a)==4
    def __add__(a,b):b=K(b);return K(tuple(x+y for x,y in zip(a.a,b.a)))
    __radd__=__add__
    def __neg__(a):return K(tuple(-x for x in a.a))
    def __sub__(a,b):return a+-K(b)
    def __rsub__(a,b):return K(b)+-a
    def __mul__(a,b):
        b=K(b);z=[F(0)]*4
        for i in range(4):
            for j in range(4):
                # bit0 is sqrt2; bit1 is sqrt3; repeated factors square.
                z[i^j]+=a.a[i]*b.a[j]*(2 if i&j&1 else 1)*(3 if i&j&2 else 1)
        return K(z)
    __rmul__=__mul__
    def __truediv__(a,b):
        b=F(b);assert b
        return K(tuple(x/b for x in a.a))
    def sq(a):return a*a
    def zero(a):return all(x==0 for x in a.a)
    def interval(a):
        basis=[I(1),I(2).sqrt(),I(3).sqrt(),I(6).sqrt()]
        return sum((I(c)*r for c,r in zip(a.a,basis)),I(0))
    def __repr__(a):return str(a.a)
SQ2=K((0,1,0,0));SQ3=K((0,0,1,0));SQ6=K((0,0,0,1))
B=SQ2+SQ6;C=2*SQ2
COS15=(SQ6+SQ2)/4;SIN15=(SQ6-SQ2)/4
ANG=[(K(1),K(0))]
for _ in range(23):
    x,y=ANG[-1];ANG.append((COS15*x-SIN15*y,SIN15*x+COS15*y))
assert (COS15.sq()+SIN15.sq()-1).zero()

# Table 5, transcribed: first direction (in units of pi/12), noncentral interior
# radii ('2' or 'C' = 2 sqrt 2) and following outer counts. Data names as in Appendix H.
TABLE5={
 'm10_a':   (4, 'C2C2222', (1,1,1,2,2,2,1)),   # Q1, first direction pi/3
 'm10_b':   (20,'C22C222', (1,2,1,1,2,2,1)),   # Q2, 5pi/3
 'm11_lim3':(2, 'C22222',  (1,2,2,2,2,2)),     # Q3, pi/6
 'm11_lim6':(6, 'C22222',  (1,2,2,2,3,1)),     # Q4, pi/2
 'm11_lim8':(10,'C22222',  (1,2,2,3,2,1)),     # Q5, 5pi/6
 'm11_core':(1, '222222',  (0,2,2,2,2,2)),     # Q6, pi/12
}
# The specifications below list every center by radius type and direction in
# degrees, in the matrix coordinate order of Appendix G (Table 26). They are
# derived from Table 5 and compared with it in check_references18.py.
SPECS={
 'm11_lim3':[('B',270),('0',0)]+[('2',a) for a in [195,255,315,75,135]]+[('C',30)]+[('B',a) for a in [180,210,240,300,330,0,60,90,120,150]],
 'm11_lim6':[('B',270),('0',0)]+[('2',a) for a in [195,255,315,45,135]]+[('C',90)]+[('B',a) for a in [180,210,240,300,330,0,30,60,120,150]],
 'm11_lim8':[('B',270),('0',0)]+[('2',a) for a in [195,255,315,45,105]]+[('C',150)]+[('B',a) for a in [180,210,240,300,330,0,30,60,90,120]],
 'm10_a': [('B',270),('0',0)]+[('2',a) for a in [195,255,315,15,105]]+[('C',60),('C',150)]+[('B',a) for a in [180,210,240,300,330,0,30,90,120]],
 'm10_b': [('B',270),('0',0)]+[('2',a) for a in [195,255,345,45,135]]+[('C',300),('C',90)]+[('B',a) for a in [180,210,240,330,0,30,60,120,150]],
 'm11_core':[('B',270),('0',0)]+[('2',a) for a in [15,75,135,195,255,315]]+[('B',a) for a in [0,90,120,150,180,210,240,300,330]],
 'ring18':[('B',270)]+[('2',a) for a in [15,75,135,195,255,315]]+[('B',a) for a in [0,30,60,90,120,150,180,210,240,300,330]],
}

def norm2(p):return p[0].sq()+p[1].sq()
def dist2(p,q):return norm2((p[0]-q[0],p[1]-q[1]))
def exact_points(name):
    radii={'0':K(0),'2':K(2),'C':C,'B':B}
    return [tuple(radii[r]*z for z in ANG[(a//15)%24]) for r,a in SPECS[name]]

def get_candidate(name):
    """Return (B interval, list[(I x,I y)], contacts set, boundary set), zero based.
    Every set's first point is exactly (0,-B); the rotation gauge is x_0=0.
    """
    p=exact_points(name);contacts=set();boundary=set()
    for i in range(len(p)):
        rad=norm2(p[i])-B.sq()
        if rad.zero():boundary.add(i)
        else:assert rad.interval().h<0,(name,'radius',i)
        for j in range(i):
            d=dist2(p[i],p[j])-4
            if d.zero():contacts.add((j,i))
            else:assert d.interval().l>0,(name,'pair',j,i)
    assert p[0][0].zero() and (p[0][1]+B).zero()
    return B.interval(),[(x.interval(),y.interval()) for x,y in p],contacts,boundary

def verify(verbose=True):
    result={}
    for name in SPECS:
        rad,p,e,b=get_candidate(name)
        expected={'m11_lim3':(18,32,11),'m11_lim6':(18,32,11),'m11_lim8':(18,32,11),'m10_a':(18,34,10),'m10_b':(18,34,10),'m11_core':(17,31,10),'ring18':(18,30,12)}[name]
        got=len(p),len(e),len(b)
        assert got==expected,(name,got,expected)
        result[name]=(p,e,b)
        if verbose:print(name,'PASS: points',len(p),'pair contacts',len(e),'boundary',len(b),'all other inequalities strict')
    return result
if __name__=='__main__':verify()
