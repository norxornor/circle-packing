#!/usr/bin/env python3
"""Exact local isolation for the three n=18 m=11 cutoff limiting points."""
from certify_m10 import verify
for name in ('m11_lim3', 'm11_lim6', 'm11_lim8'):
    verify(name)
