"""Validate all angular bounds used in radial_integer.cpp, using exact rationals,
and derive from the paper every constant that radial_integer.cpp uses
(Proposition 10.4).

The floating proposer is untrusted; every proposed lower bound is checked here
over the exact rational bracket [BLO, BHI] of b18 = sqrt2 + sqrt6.

Usage:
  validate_angles.py TABLE...            validate angle tables
  validate_angles.py --parameters K      print the PARAMETERS line that
                                         radial_integer.cpp K must print
"""

# Locate the shared arithmetic from any working directory.
from pathlib import Path as _Path
import sys as _sys
_sys.path.insert(0, str(_Path(__file__).resolve().parents[1]))
from exact_arithmetic import (
    cosine_lower_34 as cos_lower,
)
from fractions import Fraction as F
from pathlib import Path
import importlib.util
import sys
RQ=AQ=2**40                     # Appendix C: radial grid 2^40; (B.7) Q_theta = 2^40
TWO_PI_UP=6908435304716          # (B.7)
BLO=F('3.8637033051562731469989727988')
BHI=F('3.8637033051562731469989727990')
PILO,PIHI=F('3.141592653589793238'),F('3.141592653589793239')
EPS=F(1,10**6)                                   # (10.7)
START_HI=F('2.828427124746191')                  # Proposition 10.4 starting range [0, 2.828427124746191]
WINDOW_C=(F('2.828426124746191'),F('2.828428124746190'))   # Proposition 10.4 acceptance interval for c
WINDOW_DEN=10**15

def ceil_grid(x,q):return -((-(x*q).numerator)//(x*q).denominator)

def exact18():
    spec=importlib.util.spec_from_file_location('exact18',Path(__file__).resolve().parent/'exact18.py')
    c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c);return c

def composition_counts(n,outer,inner):
    """(compositions, dihedral orbits) from check_compositions.py, Table 20."""
    from check_compositions import composition_checks
    rows=[r for r in composition_checks() if (r['N'],r['outer'],r['inner'])==(n,outer,inner)]
    assert len(rows)==1
    return rows[0]['compositions'],rows[0]['dihedral_orbits']

def constants():
    def atan_bounds(x):
        lo=sum(((-1)**j*x**(2*j+1)/(2*j+1) for j in range(20)),F(0))
        return lo,lo+x**41/41
    a,b=atan_bounds(F(1,5));c,d=atan_bounds(F(1,239))
    assert PILO<16*a-4*d and 16*b-4*c<PIHI
    assert F(TWO_PI_UP,AQ)>=2*PIHI
    c=exact18()
    bb=c.B.interval(); cc=c.C.interval()
    assert BLO<=F(bb.l,c.Q) and F(bb.h,c.Q)<=BHI       # b18 in [BLO, BHI]
    assert (c.B*c.C-c.B.sq()+4).zero()                  # c(b18) = b18 - 4/b18 = 2 sqrt2 exactly
    # [0, 2.828427124746191] contains [0, c]: compare squares with c^2 = 8.
    assert START_HI**2>8
    # The acceptance interval for target c lies in [c - eps, c + eps].
    assert WINDOW_C[0]>F(cc.h,c.Q)-EPS and WINDOW_C[1]<F(cc.l,c.Q)+EPS
    print('CERTIFIED exact construction radius, cutoff, starting range, inward local windows and pi bounds')

def templates(k):
    """Section 10.4: for m = 11 the targets Q6 (first count changed from 0 to 1),
    Q3, Q4, Q5; for m = 10 the targets Q1, Q2, all read from Table 5."""
    t5=exact18().TABLE5
    names={7:['m11_core','m11_lim3','m11_lim6','m11_lim8'],8:['m10_a','m10_b']}[k]
    rows=[]
    for name in names:
        _,radii,counts=t5[name]
        counts=list(counts)
        if name=='m11_core':
            assert counts[0]==0;counts[0]=1
        assert len(radii)==len(counts)==k-1
        rows.append(','.join('c' if r=='C' else '2' for r in radii)+'/'+','.join(map(str,counts)))
    return ';'.join(rows)

def parameters(k):
    assert k in (7,8)
    constants()
    start=ceil_grid(START_HI,RQ)
    assert start<4*2**40                    # Appendix H.3: radius numerators < 4 * 2^40
    assert START_HI<=F(start,RQ)
    w2=((2-EPS)*WINDOW_DEN,(2+EPS)*WINDOW_DEN)
    wc=(WINDOW_C[0]*WINDOW_DEN,WINDOW_C[1]*WINDOW_DEN)
    assert all(x.denominator==1 for x in w2+wc)
    core=1/EPS
    assert core.denominator==1
    compositions,orbits=composition_counts(18,18-k,k)
    assert (compositions,orbits)=={7:(12376,912),8:(19448,1282)}[k]   # Proposition 10.4
    return ('PARAMETERS N=18 K=%d RQ=%d AQ=%d TWO_PI_UP=%d START=0,%d CORE_MAX=1/%d WINDOW_DEN=%d '
            'WINDOW_2=%d,%d WINDOW_C=%d,%d TEMPLATES=%s COMPOSITIONS=%d ORBITS=%d'%(k,RQ,AQ,TWO_PI_UP,
            start,int(core),WINDOW_DEN,int(w2[0]),int(w2[1]),int(wc[0]),int(wc[1]),templates(k),
            compositions,orbits))

def validate(path):
    seen=set()
    for line in path.read_text().splitlines():
        xi,yi,ni=map(int,line.split())
        assert -1<=xi<=yi and (xi,yi) not in seen
        seen.add((xi,yi))
        assert ni>=0
        xl,xh=(BLO,BHI) if xi==-1 else (F(xi,RQ),F(xi,RQ))
        yl,yh=(BLO,BHI) if yi==-1 else (F(yi,RQ),F(yi,RQ))
        t=F(ni,AQ)
        assert 0<=t<=PILO
        if ni==0:continue
        # Radius zero: a positive bound is valid only when the pair is infeasible.
        if xl==0 or yl==0:
            assert xh+yh<2,(xi,yi,ni)
            continue
        num=xh*xh+yh*yh-4
        den=2*xl*yl if num>=0 else 2*xh*yh
        zupper=num/den
        if zupper<=-1:continue
        assert zupper<1 and cos_lower(t)>=zupper,(xi,yi,ni)
    print('CERTIFIED',len(seen),'exact rational angular lower bounds')
if __name__=='__main__':
    if sys.argv[1:2]==['--parameters']:
        assert len(sys.argv)==3
        print(parameters(int(sys.argv[2])))
    else:
        assert len(sys.argv)>1
        constants()
        for p in sys.argv[1:]:validate(Path(p))
