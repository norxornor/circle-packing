"""Validate all angular bounds used in radial_integer.cpp, using exact rationals.
The floating proposer is untrusted; every proposed lower bound is checked here.
This validator independently verifies every bound over the exact rational
bracket for the construction radius. Configurations are normalized at
the exact construction radius throughout.
"""

# Locate the shared arithmetic from any working directory.
from pathlib import Path as _Path
import sys as _sys
_sys.path.insert(0, str(_Path(__file__).resolve().parents[1]))
from exact_arithmetic import (
    cosine_lower_34 as cos_lower,
    sine_upper_37 as sin_upper,
)
from fractions import Fraction as F
from pathlib import Path
import sys
RQ=AQ=2**40
TWO_PI_UP=6908435304716
BLO=F('3.8637033051562731469989727988')
BHI=F('3.8637033051562731469989727990')
PILO,PIHI=F('3.141592653589793238'),F('3.141592653589793239')



def constants():
    def atan_bounds(x):
        lo=sum(((-1)**j*x**(2*j+1)/(2*j+1) for j in range(20)),F(0))
        return lo,lo+x**41/41
    a,b=atan_bounds(F(1,5));c,d=atan_bounds(F(1,239))
    assert PILO<16*a-4*d and 16*b-4*c<PIHI
    assert F(TWO_PI_UP,AQ)>=2*PIHI
    import importlib.util
    spec=importlib.util.spec_from_file_location('exact18',Path(__file__).resolve().parent/'exact18.py')
    c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
    bb=c.B.interval(); cc=c.C.interval()
    assert BLO<=F(bb.l,c.Q) and F(bb.h,c.Q)<=BHI
    assert (c.B*c.C-c.B.sq()+4).zero()
    assert F(cc.h,c.Q)<F('2.828427124746191')
    assert F('2.828426124746191')>F(cc.h,c.Q)-F(1,10**6)
    assert F('2.828428124746190')<F(cc.l,c.Q)+F(1,10**6)
    print('CERTIFIED exact construction radius, cutoff, inward local windows and pi bounds')

def validate(path):
    constants();seen=set()
    for line in path.read_text().splitlines():
        xi,yi,ni=map(int,line.split())
        assert -1<=xi<=yi and (xi,yi) not in seen
        seen.add((xi,yi))
        assert ni>=0
        xl,xh=(BLO,BHI) if xi==-1 else (F(xi,RQ),F(xi,RQ))
        yl,yh=(BLO,BHI) if yi==-1 else (F(yi,RQ),F(yi,RQ))
        t=F(ni,AQ)
        assert 0<=t<=PILO
        if ni==0:continue
        # Radius zero is a deliberately defined clipped-angle case.
        if xl==0 or yl==0:
            assert xh+yh<2,(xi,yi,ni)
            continue
        num=xh*xh+yh*yh-4
        den=2*xl*yl if num>=0 else 2*xh*yh
        zupper=num/den
        if zupper<=-1:continue
        assert zupper<1 and cos_lower(t)>=zupper,(xi,yi,ni)
    print('CERTIFIED',len(seen),'exact rational angular lower bounds')
if __name__=='__main__':
    for p in sys.argv[1:]:validate(Path(p))
