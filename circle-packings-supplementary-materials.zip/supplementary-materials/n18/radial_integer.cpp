// Exact integer replay; floating proposals require separate exact validation.
#include "../integer_bounds.hpp"
#include <algorithm>
#include <array>
#include <cassert>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <limits>
#include <map>
#include <string>
#include <set>
#include <vector>
#ifdef PROPOSE_BOUNDS
#include <cmath>
#endif
// RQ is the radial denominator and AQ the angular denominator.
// Radius index -1 denotes the exact construction boundary radius.
// A GapCounts entry counts outer points between consecutive inner directions.
// RadiusBox intervals are closed and contain real radii, not only grid points.
using namespace std;
using GapCounts = vector < int >;
constexpr int N = 18, KMAX = 8;
constexpr Z RQ = Z(1) << 40, AQ = Z(1) << 40, TWO_PI_UP = 6908435304716LL;
int K, M;
Z start_hi();
constexpr Z TQ = 1000000000000000LL;
// Rational windows wholly inside target +/- 10^-6.
const Z TARGET_LO[2] = { 1999999000000000LL, 2828426124746191LL };
const Z TARGET_HI[2] = { 2000001000000000LL, 2828428124746190LL };
// The center matched to O must have radius at most 1/CORE_DEN.
constexpr Z CORE_DEN = 1000000;
int compositions_expected() { return K == 7 ? 12376 : 19448; }
int orbits_expected() { return K == 7 ? 912 : 1282; }
struct RadiusBox {
    array < Z, KMAX > lo, hi;
};
map < pair < Z, Z >, Z > angles;
vector < int > order;
Z nodes_visited, pair_exclusions, gap_exclusions, cycle_exclusions, retained_boxes, total_nodes = 0,
    total_retained = 0;
Z angle_lower(Z x, Z y) {
    if (y < x)
        swap(x, y);
    auto key = make_pair(x, y);
    auto it = angles.find(key);
    if (it != angles.end())
        return it->second;
#ifdef PROPOSE_BOUNDS
    long double X = x < 0 ? (sqrtl(2.L) + sqrtl(6.L)) : (long double) x / RQ;
    long double Y = y < 0 ? (sqrtl(2.L) + sqrtl(6.L)) : (long double) y / RQ;
    long double theta = 0;
    if (fabsl(X - Y) >= 2)
        theta = 0;
    else if (X + Y <= 2)
        theta = acosl(- 1.L);
    else theta = acosl(max(- 1.L, min(1.L, (X * X + Y * Y - 4) / (2 * X * Y))));
    Z n = max(Z(0), Z(floorl((theta - 1e-12L) * AQ)));
    angles[key] = n;
    return n;
#else
    cerr << "missing " << x << "," << y << endl;
    fail("unvalidated angle");
#endif
}
Z angle_box_lower(Z a, Z b, Z c, Z d) {
    return min({ angle_lower(a, c), angle_lower(a, d), angle_lower(b, c), angle_lower(b, d) });
}
// Each rejection applies to every real radius in the closed intervals.
// Pair bounds shorten intervals; angle sums and positive cycles exclude them.
bool excluded(RadiusBox & z, const GapCounts & p) {
    for (int rep = 0; rep < 2; rep++)
        for (int i = 0; i < K; i++)
            for (int j = i + 1; j < K; j++) {
                if (z.hi[i] + z.hi[j] < 2 * RQ) {
                    pair_exclusions++;
                    return true;
                }
                z.lo[i] = max(z.lo[i], 2 * RQ - z.hi[j]);
                z.lo[j] = max(z.lo[j], 2 * RQ - z.hi[i]);
            }
    Z pair_angles[KMAX + 1][KMAX + 1] = { };
    for (int i = 0; i < K; i++)
        for (int j = i + 1; j < K; j++)
            pair_angles[i][j] = pair_angles[j][i] = angle_box_lower(z.lo[i], z.hi[i], z.lo[j], z.hi[j]);
    for (int i = 0; i < K; i++)
        pair_angles[i][K] = pair_angles[K][i] = angle_box_lower(z.lo[i], z.hi[i], - 1, - 1);
    pair_angles[K][K] = angle_lower(- 1, - 1);
    Z sum = 0;
    for (int i = 0; i < K; i++) {
        int j = (i + 1) % K;
        Z chain = p[i] ? pair_angles[i][K] + pair_angles[j][K] + (p[i] - 1) * pair_angles[K][K] : 0;
        sum += max(pair_angles[i][j], chain);
    }
    if (sum > TWO_PI_UP) {
        gap_exclusions++;
        return true;
    }
    Z d[N][N];
    for (int i = 0; i < N; i++) {
        d[i][i] = 0;
        for (int j = i + 1; j < N; j++) {
            Z v = pair_angles[order[i ]][order[j ]];
            d[i][j] = v;
            d[j][i] = v - TWO_PI_UP;
        }
    }
    if (positive_cycle(d)) {
        cycle_exclusions++;
        return true;
    }
    return false;
}
// tr records target radius types: 0 means 2, 1 means 2*sqrt(2).
// tg records outer counts after deleting the near-origin inner direction.
// K=7 rows correspond to Q6, Q3, Q4, Q5; K=8 rows to Q1, Q2 (Table 5).
void templates(vector < vector < int >> & tr, vector < vector < int >> & tg) {
    if (K == 7) {
        tr = { { 0, 0, 0, 0, 0, 0 }, { 1, 0, 0, 0, 0, 0 }, { 1, 0, 0, 0, 0, 0 }, { 1, 0, 0, 0, 0, 0 } };
        tg = { { 1, 2, 2, 2, 2, 2 }, { 1, 2, 2, 2, 2, 2 }, { 1, 2, 2, 2, 3, 1 }, { 1, 2, 2, 3, 2, 1 } };
    } else {
        tr = { { 1, 0, 1, 0, 0, 0, 0 }, { 1, 0, 0, 1, 0, 0, 0 } };
        tg = { { 1, 1, 1, 2, 2, 2, 1 }, { 1, 2, 1, 1, 2, 2, 1 } };
    }
}
// Acceptance only places every represented arrangement in one of the
// paper's stated neighbourhoods. Local rigidity is checked separately.
bool within_reference_ranges(const RadiusBox & z, const GapCounts & p) {
    vector < vector < int >> tr, tg;
    templates(tr, tg);
    // The removed point must have radius at most 10^-6. It is still
    // included in every exclusion test before this acceptance step.
    for (int core = 0; core < K; core++) {
        if ((__int128) z.hi[core] * CORE_DEN > RQ)
            continue;
        vector < int > ids;
        for (int i = 0; i < K; i++)
            if (i != core)
                ids.push_back(i);
        int kr = K - 1;
        vector < int > q;
        for (int j = 0; j < kr; j++) {
            int a = ids[j], b = ids[(j + 1) % kr], gap = 0;
            for (int u = a; u != b; u = (u + 1) % K)
                gap += p[u];
            q.push_back(gap);
        }
        for (int kind = 0; kind < (int) tr.size(); kind++)
            for (int start = 0; start < kr; start++)
                for (int rev : { - 1, 1 }) {
                    bool good = true;
                    for (int j = 0; j < kr; j++) {
                        int t = (start + rev * j + 2 * kr) % kr, gt = (t + (rev == 1 ? 0 : kr - 1)) % kr
                            , v = tr[kind][t];
                        if (q[j] != tg[kind][gt] || (__int128) z.lo[ids[j ]] * TQ < (__int128) TARGET_LO
                            [v] * RQ || (__int128) z.hi[ids[j ]] * TQ > (__int128) TARGET_HI[v] * RQ)
                            good = false;
                    }
                    if (good)
                        return true;
                }
    }
    return false;
}
// Depth-first subdivision. The two children share their midpoint and
// cover the complete parent interval. A surviving box must satisfy the
// explicit local conditions; reaching the grid limit is a failure.
void search(const GapCounts & p) {
    order.clear();
    for (int i = 0; i < K; i++) {
        order.push_back(i);
        for (int k = 0; k < p[i]; k++)
            order.push_back(K);
    }
    assert(order.size() == N);
    RadiusBox initial;
    initial.lo.fill(0);
    initial.hi.fill(start_hi());
    vector < RadiusBox > stack { initial };
    nodes_visited = pair_exclusions = gap_exclusions = cycle_exclusions = retained_boxes = 0;
    while (!stack.empty()) {
        if (++ nodes_visited > 50000000)
            fail("node limit");
        RadiusBox z = stack.back();
        stack.pop_back();
        if (excluded(z, p))
            continue;
        if (within_reference_ranges(z, p)) {
            retained_boxes++;
            continue;
        }
        int split = 0;
        Z width = 0;
        for (int i = 0; i < K; i++)
            if (z.hi[i] - z.lo[i] > width) {
                width = z.hi[i] - z.lo[i];
                split = i;
            }
        if (width < 2)
            fail("unresolved final grid cell");
        Z mid = (z.lo[split] + z.hi[split]) / 2;
        RadiusBox other = z;
        z.hi[split] = mid;
        other.lo[split] = mid;
        stack.push_back(other);
        stack.push_back(z);
    }
    assert(nodes_visited == 2 * (pair_exclusions + gap_exclusions + cycle_exclusions + retained_boxes) -
        1);
    for (int k : p)
        cout << k << ",";
    cout << " nodes=" << nodes_visited << " pair=" << pair_exclusions << " fast=" << gap_exclusions <<
        " full=" << cycle_exclusions << " local=" << retained_boxes << endl;
    total_nodes += nodes_visited;
    total_retained += retained_boxes;
}
// Every constant used by the search, checked against the paper by
// validate_angles.py --parameters K and the verification driver.
Z start_hi() {
    return Z(((__int128) 2828427124746191LL * RQ + TQ - 1) / TQ);
}
void print_parameters() {
    vector < vector < int >> tr, tg;
    templates(tr, tg);
    cout << "PARAMETERS N=18 K=" << K << " RQ=" << RQ << " AQ=" << AQ << " TWO_PI_UP=" << TWO_PI_UP
         << " START=0," << start_hi() << " CORE_MAX=1/" << CORE_DEN << " WINDOW_DEN=" << TQ
         << " WINDOW_2=" << TARGET_LO[0] << "," << TARGET_HI[0]
         << " WINDOW_C=" << TARGET_LO[1] << "," << TARGET_HI[1] << " TEMPLATES=";
    for (size_t k = 0; k < tr.size(); k++) {
        cout << (k ? ";" : "");
        for (size_t i = 0; i < tr[k].size(); i++) cout << (i ? "," : "") << (tr[k][i] ? "c" : "2");
        cout << "/";
        for (size_t i = 0; i < tg[k].size(); i++) cout << (i ? "," : "") << tg[k][i];
    }
    cout << " COMPOSITIONS=" << compositions_expected() << " ORBITS=" << orbits_expected() << endl;
}
// Keep one representative under rotations and reflection of the order.
GapCounts canonical_pattern(GapCounts p) {
    auto best = p;
    for (int s = 0; s < K; s++)
        for (int r : { - 1, 1 }) {
            GapCounts q(K);
            for (int i = 0; i < K; i++)
                q[i] = p[(s + r * i + 2 * K) % K];
            best = min(best, q);
        }
    return best;
}
Z composition_count = 0;
void gen(GapCounts p, int sum, set < GapCounts > & out) {
    if (p.size() == K - 1) {
        ++composition_count;
        p.push_back(M - sum);
        out.insert(canonical_pattern(p));
        return;
    }
    for (int a = 0; a <= M - sum; a++) {
        p.push_back(a);
        gen(p, sum + a, out);
        p.pop_back();
    }
}
int main(int argc, char * * argv) {
    if (argc < 2)
        fail("supply inner count 7 or 8");
    K = atoi(argv[1]);
    if (K != 7 && K != 8)
        fail("bad inner count");
    M = N - K;
    if (argc == 3 && string(argv[2]) == "--parameters") {
        print_parameters();
        return 0;
    }
    print_parameters();
#ifdef PROPOSE_BOUNDS
    ifstream input("radial18_angles_" + to_string(K) + ".tsv");
#else
    if (argc != 3)
        fail("supply validated angle table");
    ifstream input(argv[2]);
    if (!input)
        fail("cannot open angle table");
#endif
    Z x, y, n;
    while (input >> x >> y >> n) {
        if (x > y || x < - 1 || n < 0 || n > TWO_PI_UP / 2)
            fail("bad record");
        if (!angles.emplace(make_pair(x, y), n).second)
            fail("duplicate record");
    }
    if (input.is_open() && !input.eof())
        fail("parse error");
    set < GapCounts > patterns;
    gen({}, 0, patterns);
    assert(composition_count == compositions_expected());
    assert(patterns.size() == size_t(orbits_expected()));
    cout << "K=" << K << " M=" << M << " patterns=" << patterns.size() << endl;
    for (auto p : patterns)
        search(p);
    cout << "TOTAL nodes=" << total_nodes << " local=" << total_retained << " angles=" << angles.size()
        << endl;
#ifdef PROPOSE_BOUNDS
    ofstream output("radial18_angles_" + to_string(K) + ".tsv");
    for (auto &[key, n] : angles)
        output << key.first << '\t' << key.second << '\t' << n << '\n';
    if (!output)
        fail("write failed");
    cout << "PROPOSAL COMPLETE; exact validation required" << endl;
#else
    cout << "PASS exact integer replay" << endl;
#endif
}
