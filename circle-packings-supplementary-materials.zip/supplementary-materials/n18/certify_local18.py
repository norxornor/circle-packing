#!/usr/bin/env python3
"""Exact small-change check for the seventeen-point reference Q6.
Labels are defined in scaffold18.py. Only the seventeen retained points enter this local certificate.
"""
if not __debug__:raise RuntimeError('Run without -O.')
from fractions import Fraction as F
from pathlib import Path
import json
from scaffold18 import I,D,construct

def verify(verbose=True):
    B,points,contacts,boundary=construct();m=41;d=33;gauge=0
    data=json.loads(Path(__file__).with_name('inverse18.json').read_text())
    assert data['gauge']==gauge
    VS=data['extra_scale'];V=data['extra_columns'];assert VS>0 and len(V)==m
    assert all(len(row)==7 for row in V)
    rows=[]
    def append(row):
        i=len(rows);row=row[:gauge]+row[gauge+1:]
        rows.append(row+[I(1)]+[I(F(v,VS)) for v in V[i]])
    for i,j in sorted(contacts):
        row=[I(0) for _ in range(34)]
        for k in range(2):
            z=2*(points[i][k]-points[j][k]);row[2*i+k]=z;row[2*j+k]=-z
        append(row)
    for i in sorted(boundary):
        row=[I(0) for _ in range(34)]
        for k in range(2):row[2*i+k]=-2*points[i][k]
        append(row)
    assert len(rows)==m and all(len(row)==m for row in rows)
    S=data['scale'];P=data['inverse'];assert S>0 and len(P)==m
    assert all(len(row)==m and all(isinstance(x,int) for x in row) for row in P)
    maximum=0
    for i in range(m):
        total=0
        for j in range(m):
            lo=hi=0
            for k in range(m):
                a,b=rows[k][j].l,rows[k][j].h;v=P[i][k]
                lo+=min(v*a,v*b);hi+=max(v*a,v*b)
            target=D*S if i==j else 0
            total+=max(abs(target-lo),abs(target-hi))
        maximum=max(maximum,total)
    rho=F(maximum,D*S);pnorm=F(max(sum(abs(v) for v in row) for row in P),S)
    assert rho<F(1,10**10)
    error=rho*pnorm/(1-rho)
    assert pnorm+error<4
    minimum=min(F(v,S)-error for v in P[d]);assert minimum>F(1,70)
    if verbose:
        print('CERTIFIED n18 eleven-outerfamily17-pointscaffold: inverse norm<4,stress>1/70')
        print('residual upper:',float(rho),'inverse upper:',float(pnorm+error),'stress lower:',float(minimum))
        print('LOCALTHEOREM: gaugepoint0x=0; all17scaffoldcoordinateerrors<1/2240')
        print('forcesentirescaffoldexact. Arbitrary18thpointnotinvolved.')
    return rho,pnorm+error,minimum
if __name__=='__main__':verify()
