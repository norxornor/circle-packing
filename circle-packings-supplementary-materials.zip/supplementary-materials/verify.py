#!/usr/bin/env python3
"""Verify every computational claim in the paper; Python standard library only.

This driver calls the individual arithmetic checkers directly. It compiles
each replay locally, validates its angle tables first, requires each compiled
program to use exactly the constants derived from the paper by its validator,
checks completion counts, and writes an ordered report plus a complete
transcript to a separate output directory.

Usage: python3 -E -B verify.py [--output DIR]     (default DIR: verification-run)

A stage passes only if its program exits with status 0 and prints every
required line as a complete line of its output.
"""
from pathlib import Path
import json, shutil, subprocess, sys, tempfile, time, platform, os
if not __debug__:
    raise RuntimeError('Run without -O: assertions are proof checks.')
ROOT = Path(__file__).resolve().parent
CXX = shutil.which('g++') or shutil.which('clang++')
if CXX is None:
    raise RuntimeError('A C++17 compiler supporting __int128 is required.')
CHECKS = ROOT
PY = sys.executable

def output_directory():
    args = sys.argv[1:]
    if args and args[0] == '--output' and len(args) == 2:
        out = Path(args[1]).resolve()
    elif not args:
        out = ROOT / 'verification-run'
    else:
        raise SystemExit('usage: verify.py [--output DIR]')
    if out == ROOT:
        raise SystemExit('The output directory must not be the supplementary directory itself.')
    for name in ('verification-output.txt', 'verification-results.json'):
        path = out / name
        if path.exists() or path.is_symlink():
            raise SystemExit('Refusing to overwrite an existing verification record: '
                             + str(path) + '. Use --output with a new directory.')
    out.mkdir(parents=True, exist_ok=True)
    return out

REPORT = output_directory()
LOG = REPORT / 'verification-output.txt'

def write_record(record):
    """Replace the record atomically; a partial write cannot look complete."""
    with tempfile.NamedTemporaryFile(mode='w', dir=REPORT, prefix='results-',
                                     suffix='.tmp', delete=False) as stream:
        temporary = Path(stream.name)
        json.dump(record, stream, indent=2)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, REPORT / 'verification-results.json')

def energy(k, boxes, length, angle):
    return "CERTIFIED %d energy {'boxes': %d, 'pair': 0, 'energy': %d, 'angle': %d}" % (k, boxes, length, angle)

def main():
    start = time.monotonic()
    records = []
    write_record({'complete': False, 'all_passed': False, 'checks': records,
                  'running_stage': None, 'environment': {}})
    cpu_model = platform.processor() or 'not reported'
    cpuinfo = Path('/proc/cpuinfo')
    if cpuinfo.exists():
        for line in cpuinfo.read_text().splitlines():
            if line.startswith('model name'):
                cpu_model = line.split(':', 1)[1].strip()
                break
    environment = {'python': platform.python_version(), 'compiler': subprocess.check_output([CXX, '--version'], text=True).splitlines()[0], 'platform': platform.platform(), 'processor': cpu_model, 'logical_cpus': os.cpu_count(), 'stages_run_sequentially': True}
    with LOG.open('x') as log, tempfile.TemporaryDirectory(prefix='circle-packings-') as td:
        build = Path(td)

        def run(claim, description, args, cwd, required=()):
            write_record({'complete': False, 'all_passed': False,
                          'checks': records, 'running_stage': claim,
                          'environment': environment})
            print(claim + ': ' + description, flush=True)
            t = time.monotonic()
            log.write('\n=== ' + claim + ': ' + description + ' ===\n')
            log.flush()
            env = dict(os.environ)
            env.pop('PYTHONPATH', None)
            env.pop('PYTHONOPTIMIZE', None)
            env['PYTHONDONTWRITEBYTECODE'] = '1'
            r = subprocess.run(args, cwd=cwd, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
            log.write(r.stdout)
            log.flush()
            lines = set(r.stdout.splitlines())
            missing = [x for x in required if x not in lines]
            okay = r.returncode == 0 and not missing
            records.append({'claim': claim, 'description': description, 'passed': okay, 'seconds': round(time.monotonic() - t, 3)})
            write_record({'complete': False, 'all_passed': False,
                          'checks': records, 'running_stage': None,
                          'environment': environment})
            if not okay:
                print(r.stdout, flush=True)
                print('MISSING REQUIRED LINES:', missing, flush=True)
                raise RuntimeError('Failed or incomplete check: ' + claim)
            print('PASS', flush=True)
            return r.stdout

        def py(claim, n, file, args=(), required=()):
            d = CHECKS / f'n{n}' if n else CHECKS
            return run(claim, file, [PY, '-E', '-B', str(d / file), *args], d, required)

        def parameters_line(stdout):
            line = stdout.splitlines()[-1]
            assert line.startswith('PARAMETERS ')
            return line

        def compile_run(claim, n, file, validator, runs):
            """runs: (suffix, validator --parameters args, program args, required lines)."""
            d = CHECKS / f'n{n}'
            exe = build / f'{claim}-replay'
            run(claim + '.compile', file, [CXX, '-O3', '-std=c++17', str(d / file), '-o', str(exe)], d)
            for suffix, vargs, args, required in runs:
                expected = parameters_line(py(claim + suffix + '.params', n, validator, ['--parameters', *vargs]))
                run(claim + suffix + '.paramcheck', 'compiled constants equal the paper-derived constants',
                    [str(exe), *args[:-1], '--parameters'], d, [expected])
                run(claim + suffix, 'exhaustive integer replay', [str(exe), *args], d, [expected, *required])

        py('ORDERS', 0, 'check_compositions.py', required=[
            'N= 15 m= 10 compositions= 126 orbits= 16', 'N= 16 m= 11 compositions= 210 orbits= 26',
            'N= 17 m= 11 compositions= 4368 orbits= 392', 'N= 17 m= 10 compositions= 8008 orbits= 600',
            'N= 18 m= 11 compositions= 12376 orbits= 912', 'N= 18 m= 10 compositions= 19448 orbits= 1282',
            'N= 20 m= 12 compositions= 50388 orbits= 3260', 'ALL COMPOSITION COUNTS PASSED'])
        py('C0', 0, 'constants.py', required=['C0 ALL CONSTANTS PASSED'])
        py('SHARED', 0, 'check_shared_claims.py', required=['ALL SHARED CLAIMS PASSED'])
        # Fifteen circles
        py('G15', 15, 'pentagon_certificate.py', required=['PASS: identities, Proposition 7.2 constants, Table 2 and feasibility of P15.'])
        py('E15', 15, 'inner_energy_certificate.py', required=[energy(6, 1819, 394, 516), energy(7, 1149, 242, 333), energy(8, 81, 5, 36)])
        py('R15.bounds', 15, 'radial_integer_validate.py', ['radial_integer_angles.tsv'], ['CERTIFIED 1307 exact rational angular lower bounds'])
        compile_run('R15', 15, 'radial_integer.cpp', 'radial_integer_validate.py', [('', [], ['radial_integer_angles.tsv'],
            ['TOTAL nodes=63846 local=175 angles=1307', 'PASS: exact integer replay completed all radial boxes.'])])
        py('L15', 15, 'additive_estimates.py', required=['PASS proportional radius estimates; strict local coefficient >1/6'])
        # Sixteen circles
        py('C16', 16, 'certify_construction16.py', required=['n=16 feasible construction: PASS', 'PASS original-position checks: all 11 outer centres fixed'])
        py('E16', 16, 'energy16.py', required=[energy(6, 1463, 352, 380), energy(7, 2599, 556, 744), energy(8, 817, 114, 295)])
        py('G16', 16, 'certify_geometry16.py', required=['n=16 geometric reduction bounds: PASS'])
        py('G16.printed', 16, 'check_printed_bounds.py', required=['PRINTED BOUNDS PASSED'])
        py('R16.bounds', 16, 'radial_integer_validate.py', ['radial_integer_angles.tsv'], ['CERTIFIED 4805 exact rational angular lower bounds'])
        compile_run('R16', 16, 'radial_integer.cpp', 'radial_integer_validate.py', [('', [], ['radial_integer_angles.tsv'],
            ['patterns 26 compositions 210', 'TOTAL nodes=44580 local=190 angles=4805', 'PASS: exact integer replay completed all radial boxes.'])])
        py('P16', 16, 'coordinate_nearness.py', required=['PASS: after rotational alignment, every coordinate error <1/10000'])
        py('L16', 16, 'certify_local16.py', required=['CERTIFIED n=16 bordered Jacobian invertible, inverse infinity norm < 5', 'CERTIFIED normalized positive stress: every weight > 1/250'])
        # Seventeen circles
        py('C17', 17, 'verify17_exact.py', required=['By IVT and the exact contact identities, a feasible packing exists with', 'PASS original-position checks: all 10 outer centres have inner contacts'])
        py('E17', 17, 'energy17.py', required=[energy(8, 100475, 23391, 26847), energy(9, 4585, 481, 1812), energy(10, 1267, 22, 612), energy(11, 777, 0, 389)])
        py('R17.bounds', 17, 'validate_angles.py', ['radial17_angles_6.tsv', 'radial17_angles_7.tsv'], [
            'CERTIFIED (9.9): 0 < omega_11 < omega_11^+ < pi/2, c < b- cos(omega_11^+), D(2.368, b+; omega_11^+) < 4',
            'CERTIFIED 2353 exact rational angular lower bounds', 'CERTIFIED 159816 exact rational angular lower bounds'])
        compile_run('R17', 17, 'radial_integer.cpp', 'validate_angles.py', [
            ('.11', ['6'], ['6', 'radial17_angles_6.tsv'], ['K=6 M=11 patterns=392', 'TOTAL nodes=107250 local=0 angles=2353', 'PASS exact integer replay']),
            ('.10', ['7'], ['7', 'radial17_angles_7.tsv'], ['K=7 M=10 patterns=600', 'TOTAL nodes=15297824 local=8423 angles=159816', 'PASS exact integer replay'])])
        py('P17', 17, 'coordinate_nearness17.py', required=['Worked angle chains for G verified in exact arithmetic.', 'PASS: after rotational alignment, every coordinate error <1/16000'])
        py('L17', 17, 'certify_local17.py', required=['CERTIFIED n=17 bordered Jacobian invertible, inverse infinity norm < 8', 'CERTIFIED normalized positive stress: every weight > 1/250'])
        # Eighteen circles
        py('C18', 18, 'exact18.py', required=[
            'm11_lim3 PASS: points 18 pair contacts 32 boundary 11 all other inequalities strict',
            'm11_lim6 PASS: points 18 pair contacts 32 boundary 11 all other inequalities strict',
            'm11_lim8 PASS: points 18 pair contacts 32 boundary 11 all other inequalities strict',
            'm10_a PASS: points 18 pair contacts 34 boundary 10 all other inequalities strict',
            'm10_b PASS: points 18 pair contacts 34 boundary 10 all other inequalities strict',
            'm11_core PASS: points 17 pair contacts 31 boundary 10 all other inequalities strict',
            'ring18 PASS: points 18 pair contacts 30 boundary 12 all other inequalities strict'])
        py('T18', 18, 'check_references18.py', required=['ALL EIGHTEEN-CIRCLE REFERENCE CHECKS PASSED'])
        py('E18', 18, 'energy18.py', required=[energy(9, 12733, 1726, 4641), energy(10, 6281, 463, 2678), energy(11, 2273, 31, 1106), energy(12, 1035, 0, 518)])
        py('R18.bounds', 18, 'validate_angles.py', ['radial18_angles_7.tsv', 'radial18_angles_8.tsv'], [
            'CERTIFIED exact construction radius, cutoff, starting range, inward local windows and pi bounds',
            'CERTIFIED 6340 exact rational angular lower bounds', 'CERTIFIED 3290 exact rational angular lower bounds'])
        compile_run('R18', 18, 'radial_integer.cpp', 'validate_angles.py', [
            ('.11', ['7'], ['7', 'radial18_angles_7.tsv'], ['K=7 M=11 patterns=912', 'TOTAL nodes=589172 local=524 angles=6340', 'PASS exact integer replay']),
            ('.10', ['8'], ['8', 'radial18_angles_8.tsv'], ['K=8 M=10 patterns=1282', 'TOTAL nodes=1299422 local=100 angles=3290', 'PASS exact integer replay'])])
        py('P18', 18, 'certify_bridges18.py', required=[
            'm10_a PASS: angular error < 14 eps; coordinate error < 56 eps', 'm10_b PASS: angular error < 14 eps; coordinate error < 56 eps',
            'm11_lim3 PASS: angular error < 12 eps; coordinate error < 48 eps', 'm11_lim6 PASS: angular error < 12 eps; coordinate error < 48 eps',
            'm11_lim8 PASS: angular error < 12 eps; coordinate error < 48 eps', 'm11_core PASS: angular error < 11 eps; coordinate error < 44 eps',
            'Derivative bounds .867, .095, .289 and the worked rational estimate verified.'])
        py('L18.10', 18, 'certify_m10.py', required=['m10_a PASS: inverse infinity norm <3; each normalized stress weight >1/64', 'm10_b PASS: inverse infinity norm <3; each normalized stress weight >1/64'])
        py('L18.limits', 18, 'certify_m11_limits.py', required=['m11_lim3 PASS: inverse infinity norm <3; each normalized stress weight >1/100',
            'm11_lim6 PASS: inverse infinity norm <3; each normalized stress weight >1/100', 'm11_lim8 PASS: inverse infinity norm <3; each normalized stress weight >1/100'])
        py('L18.W', 18, 'certify_local18.py', required=['CERTIFIED n18 Q6 (seventeen centers): inverse norm < 4, stress > 1/70'])
        # Twenty circles
        py('C20', 20, 'verify20_exact.py', required=['By IVT and exact contact identities, feasible packing exists with', 'PASS original-position checks: all 12 retained outer centres fixed'])
        py('E20.bounds', 20, 'energy_integer_validate.py', ['energy20_angles.tsv'], ['PASS: 752 exact angle bounds validated'])
        compile_run('E20', 20, 'energy_integer.cpp', 'energy_integer_validate.py', [('', [], ['energy20_angles.tsv'], [
            'CERTIFIED k=9 nodes=396147 energy=82039 angular=116035 empty_radial=0', 'CERTIFIED k=10 nodes=320407 energy=51626 angular=108578 empty_radial=0',
            'CERTIFIED k=11 nodes=217719 energy=26231 angular=82629 empty_radial=0', 'CERTIFIED k=12 nodes=109203 energy=9425 angular=45177 empty_radial=0',
            'CERTIFIED k=13 nodes=16371 energy=270 angular=7916 empty_radial=0', 'CERTIFIED k=14 nodes=3799 energy=0 angular=1900 empty_radial=0',
            'PASS integer energy replay'])])
        py('R20.bounds', 20, 'validate_angles.py', ['radial20_angles.tsv'], [
            'CERTIFIED (11.7): 0 < omega_12 < omega_12^+ < pi/2, c < b- cos(omega_12^+), D(2.806, b+; omega_12^+) < 4',
            'CERTIFIED 26878 exact rational angular lower bounds'])
        compile_run('R20', 20, 'radial_integer.cpp', 'validate_angles.py', [('', ['8'], ['radial20_angles.tsv'],
            ['K=8 M=12 patterns=3260', 'TOTAL nodes=5822866 local=5406 angles=26878', 'PASS exact integer replay'])])
        py('P20', 20, 'coordinate_nearness20.py', required=['Worked angle chains for F verified in exact arithmetic.', 'PASS: after rotational alignment, every supported coordinate error <1/8400'])
        py('L20', 20, 'certify_local20.py', required=['CERTIFIED inverse infinity norm <7, normalized positive stress >1/150'])
        # Shared cross-checks
        py('REFERENCE', 0, 'check_reference_certificates.py', required=[
            *[f'TABLE 25 AND CONTACT LISTS {n} agree with the primary program by label: PASS' for n in (16, 17, 20)],
            'INDEPENDENT MATRIX 16 32 rows: PASS', 'INDEPENDENT MATRIX 17 35 rows: PASS', 'INDEPENDENT MATRIX 20 38 rows: PASS',
            *[f'INDEPENDENT REFERENCE {j} coordinates, contacts, {m} matrix rows: PASS' for j, m in zip(range(1, 7), (44, 44, 43, 43, 43, 41))]])
        py('CONSISTENCY', 0, 'check_consistency.py', [str(LOG)], required=[
            'All 20 inner-count table rows agree exactly with the replay.',
            *[f'All position-table rows and strict rigidity margins: {n} PASS' for n in (16, 17, 20)],
            *[f'Rational interval primitive sign, domain and rounding checks: {n} PASS' for n in (16, 17, 18, 20, 15, 'reference')],
            'Arithmetic operation comparisons: 38400'])
        py('SUMMARY', 0, 'certificate_summary.py', required=['PASS exact printed certificate summaries'])
    result = {'complete': True, 'all_passed': True, 'elapsed_seconds': round(time.monotonic() - start, 3), 'checks': records, 'environment': environment}
    write_record(result)
    print('\nALL PAPER CHECKS PASSED. Every enumerated case was resolved.', flush=True)
    print('Transcript and record written to', REPORT, flush=True)
if __name__ == '__main__':
    main()
