#!/usr/bin/env python3
"""Verify every computational claim in paper.tex; Python standard library only.

This driver calls the individual arithmetic checkers directly. It compiles
each replay locally, validates its angle tables first, checks completion
counts, and writes an ordered report plus a complete transcript.
"""
from pathlib import Path
import json, shutil, subprocess, sys, tempfile, time, platform, os
if not __debug__:
    raise RuntimeError('Run without -O: assertions are proof checks.')
ROOT = Path(__file__).resolve().parent
CXX = shutil.which('g++') or shutil.which('clang++')
if CXX is None:
    raise RuntimeError('A C++17 compiler supporting __int128 is required.')
CHECKS = ROOT
REPORT = ROOT
PY = sys.executable

def write_record(record):
    """Replace the record atomically; a partial write cannot look complete."""
    with tempfile.NamedTemporaryFile(mode='w', dir=REPORT, prefix='results-',
                                     suffix='.tmp', delete=False) as stream:
        temporary = Path(stream.name)
        json.dump(record, stream, indent=2)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, REPORT / 'verification-results.json')

def main():
    start = time.monotonic()
    records = []
    write_record({'complete': False, 'all_passed': False, 'checks': records,
                  'running_stage': None, 'environment': {}})
    cpu_model = platform.processor() or 'not reported'
    cpuinfo = Path('/proc/cpuinfo')
    if cpuinfo.exists():
        for line in cpuinfo.read_text().splitlines():
            if line.startswith('model name'):
                cpu_model = line.split(':', 1)[1].strip()
                break
    environment = {'python': platform.python_version(), 'compiler': subprocess.check_output([CXX, '--version'], text=True).splitlines()[0], 'platform': platform.platform(), 'processor': cpu_model, 'logical_cpus': os.cpu_count(), 'stages_run_sequentially': True}
    with (REPORT / 'verification-output.txt').open('w') as log, tempfile.TemporaryDirectory(prefix='circle-packings-') as td:
        build = Path(td)

        def run(claim, description, args, cwd, required=()):
            write_record({'complete': False, 'all_passed': False,
                          'checks': records, 'running_stage': claim,
                          'environment': environment})
            print(claim + ': ' + description, flush=True)
            t = time.monotonic()
            log.write('\n=== ' + claim + ': ' + description + ' ===\n')
            log.flush()
            env = dict(__import__('os').environ)
            env.pop('PYTHONPATH', None)
            env.pop('PYTHONOPTIMIZE', None)
            env['PYTHONDONTWRITEBYTECODE'] = '1'
            r = subprocess.run(args, cwd=cwd, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
            log.write(r.stdout)
            log.flush()
            okay = r.returncode == 0 and all((x in r.stdout for x in required))
            records.append({'claim': claim, 'description': description, 'passed': okay, 'seconds': round(time.monotonic() - t, 3)})
            write_record({'complete': False, 'all_passed': False,
                          'checks': records, 'running_stage': None,
                          'environment': environment})
            if not okay:
                print(r.stdout, flush=True)
                raise RuntimeError('Failed or incomplete check: ' + claim)
            print('PASS', flush=True)

        def py(claim, n, file, args=(), required=()):
            d = CHECKS / f'n{n}' if n else CHECKS
            run(claim, file, [PY, '-E', '-B', str(d / file), *args], d, required)

        def compile_run(claim, n, file, runs):
            d = CHECKS / f'n{n}'
            exe = build / f'{claim}-replay'
            run(claim + '.compile', file, [CXX, '-O3', '-std=c++17', str(d / file), '-o', str(exe)], d)
            for suffix, args, required in runs:
                run(claim + suffix, 'exhaustive integer replay', [str(exe), *args], d, required)
        py('ORDERS', 0, 'check_compositions.py', required=['ALL COMPOSITION COUNTS PASSED'])
        py('C0', 0, 'constants.py', required=['C0 ALL CONSTANTS PASSED'])
        py('G15', 15, 'pentagon_certificate.py', required=['PASS'])
        py('E15', 15, 'inner_energy_certificate.py', ['6', '7', '8'], ['CERTIFIED 6 energy', 'CERTIFIED 7 energy', 'CERTIFIED 8 energy'])
        py('R15.bounds', 15, 'radial_integer_validate.py', ['radial_integer_angles.tsv'], ['1307'])
        compile_run('R15', 15, 'radial_integer.cpp', [('', ['radial_integer_angles.tsv'], ['TOTAL nodes=63846 local=175 angles=1307'])])
        py('L15', 15, 'additive_estimates.py', required=['PASS proportional radius estimates'])
        py('C16', 16, 'certify_construction16.py', required=['n=16 feasible construction: PASS', 'PASS original-position checks: all 11'])
        py('E16', 16, 'energy16.py', required=['CERTIFIED 8 energy'])
        py('G16', 16, 'certify_geometry16.py', required=['PASS'])
        py('G16.printed', 16, 'check_printed_bounds.py', required=['PRINTED BOUNDS PASSED'])
        py('R16.bounds', 16, 'radial_integer_validate.py', ['radial_integer_angles.tsv'], ['CERTIFIED 4805'])
        compile_run('R16', 16, 'radial_integer.cpp', [('', ['radial_integer_angles.tsv'], ['TOTAL nodes=44580 local=190 angles=4805'])])
        py('P16', 16, 'coordinate_nearness.py', required=['every coordinate error <1/10000'])
        py('L16', 16, 'certify_local16.py', required=['every weight > 1/250'])
        py('C17', 17, 'verify17_exact.py', required=['By IVT and the exact contact identities, a feasible packing exists', 'PASS original-position checks: all 10'])
        py('E17', 17, 'energy17.py', required=['CERTIFIED 11 energy'])
        py('R17.bounds', 17, 'validate_angles.py', ['radial17_angles_6.tsv', 'radial17_angles_7.tsv'], ['CERTIFIED 2353', 'CERTIFIED 159816'])
        compile_run('R17', 17, 'radial_integer.cpp', [('.11', ['6', 'radial17_angles_6.tsv'], ['TOTAL nodes=107250 local=0 angles=2353']), ('.10', ['7', 'radial17_angles_7.tsv'], ['TOTAL nodes=15297824 local=8423 angles=159816'])])
        py('P17', 17, 'coordinate_nearness17.py', required=['every coordinate error <1/16000'])
        py('L17', 17, 'certify_local17.py', required=['every weight > 1/250'])
        py('C18', 18, 'exact18.py', required=['ring18 PASS', 'm11_core PASS'])
        py('E18', 18, 'energy18.py', required=['CERTIFIED 12 energy'])
        py('R18.bounds', 18, 'validate_angles.py', ['radial18_angles_7.tsv', 'radial18_angles_8.tsv'], ['CERTIFIED 6340', 'CERTIFIED 3290'])
        compile_run('R18', 18, 'radial_integer.cpp', [('.11', ['7', 'radial18_angles_7.tsv'], ['TOTAL nodes=589172 local=524 angles=6340']), ('.10', ['8', 'radial18_angles_8.tsv'], ['TOTAL nodes=1299422 local=100 angles=3290'])])
        py('P18', 18, 'certify_bridges18.py', required=['m11_core PASS'])
        py('L18.10', 18, 'certify_m10.py', required=['m10_a', 'm10_b'])
        py('L18.limits', 18, 'certify_m11_limits.py', required=['m11_lim3', 'm11_lim6', 'm11_lim8'])
        py('L18.W', 18, 'certify_local18.py', required=['stress>1/70'])
        py('C20', 20, 'verify20_exact.py', required=['By IVT and exact contact identities', 'PASS original-position checks: all 12'])
        py('E20.bounds', 20, 'energy_integer_validate.py', required=['752 exact angle bounds validated'])
        compile_run('E20', 20, 'energy_integer.cpp', [('', ['energy20_angles.tsv'], ['PASS integer energy replay'])])
        py('R20.bounds', 20, 'validate_angles.py', ['radial20_angles.tsv'], ['CERTIFIED 26878'])
        compile_run('R20', 20, 'radial_integer.cpp', [('', ['radial20_angles.tsv'], ['TOTAL nodes=5822866 local=5406 angles=26878'])])
        py('P20', 20, 'coordinate_nearness20.py', required=['every supported coordinate error <1/8400'])
        py('L20', 20, 'certify_local20.py', required=['positive stress >1/150'])
        py('REFERENCE', 0, 'check_reference_certificates.py', required=['INDEPENDENT REFERENCE 6', 'INDEPENDENT MATRIX 20'])
        py('CONSISTENCY', 0, 'check_consistency.py', required=['Arithmetic operation comparisons: 25600'])
        py('SUMMARY', 0, 'certificate_summary.py', required=['PASS exact printed certificate summaries'])
    result = {'complete': True, 'all_passed': True, 'elapsed_seconds': round(time.monotonic() - start, 3), 'checks': records, 'environment': environment}
    write_record(result)
    print('\nALL PAPER CHECKS PASSED. Every enumerated case was resolved.', flush=True)
if __name__ == '__main__':
    main()
