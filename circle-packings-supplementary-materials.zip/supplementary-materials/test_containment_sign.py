"""Regression checks for the exact-field containment predicate used for N=18.

Run with python3 -E -B test_containment_sign.py. No files are created or removed.
"""
from fractions import Fraction as F
from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parent / 'n18'))
from check_references18 import B, K, SQ2, nonpositive, point


class ContainmentSignTests(unittest.TestCase):
    def test_exact_zero_after_radical_cancellation(self):
        self.assertTrue(nonpositive(SQ2.sq() - 2))

    def test_strict_negative(self):
        self.assertTrue(nonpositive(K(-1)))

    def test_positive_below_interval_grid_is_rejected(self):
        delta = K(F(1, 10**100))
        self.assertGreater(delta.a[0], 0)
        self.assertEqual((delta.interval().l, delta.interval().h), (0, 1))
        self.assertFalse(nonpositive(delta))

    def test_nonpositive_upper_endpoint_is_sufficient(self):
        delta = K(-F(1, 10**100))
        self.assertEqual(delta.interval().h, 0)
        self.assertTrue(nonpositive(delta))

    def test_positive_slack_of_point_outside_container_is_rejected(self):
        # The point (b+epsilon, 0) is outside the radius-b disk, even when
        # interval rounding cannot resolve the sign of its squared slack.
        radius = B + K(F(1, 10**100))
        delta = radius.sq() - B.sq()
        self.assertLessEqual(delta.interval().l, 0)
        self.assertGreater(delta.interval().h, 0)
        self.assertFalse(nonpositive(delta))

    def test_all_nineteen_actual_centers_are_contained(self):
        points = [point(B, 2*j) for j in range(12)]
        points += [point(K(2), 1 + 4*j) for j in range(6)]
        points += [(K(0), K(0))]
        for index, (x, y) in enumerate(points):
            with self.subTest(index=index):
                self.assertTrue(nonpositive(x.sq() + y.sq() - B.sq()))


if __name__ == '__main__':
    unittest.main()
