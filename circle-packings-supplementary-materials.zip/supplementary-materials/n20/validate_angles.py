"""Validate all angular bounds used in radial_integer.cpp, using exact rationals.
The floating proposer uses an upper surrogate for the boundary radius.
This validator independently verifies every bound over the exact rational
bracket for the construction radius. Configurations are normalized at
the exact construction radius throughout.
"""

# Locate the shared arithmetic from any working directory.
from pathlib import Path as _Path
import sys as _sys
_sys.path.insert(0, str(_Path(__file__).resolve().parents[1]))
from exact_arithmetic import (
    cosine_lower_34 as cos_lower,
    sine_upper_37 as sin_upper,
)
from fractions import Fraction as F
from pathlib import Path
import sys
RQ=AQ=2**40
TWO_PI_UP=6908435304716
BLO=F('4.1223207369915283214476857921')
BHI=F('4.1223207369915283214476857923')
PILO,PIHI=F('3.141592653589793238'),F('3.141592653589793239')



def constants():
    def atan_bounds(x):
        lo=sum(((-1)**j*x**(2*j+1)/(2*j+1) for j in range(20)),F(0))
        return lo,lo+x**41/41
    a,b=atan_bounds(F(1,5));c,d=atan_bounds(F(1,239))
    assert PILO<16*a-4*d and 16*b-4*c<PIHI
    assert F(TWO_PI_UP,AQ)>=2*PIHI
    # Outer points can be at most twelve: eta > this rational lower bound.
    eta_lo=F('0.245026263334771')
    assert sin_upper(eta_lo)<1/BHI
    assert 13*eta_lo>PIHI
    assert BLO>F('3.152')
    cutoff=BHI-4/BHI
    assert cutoff<F('3.152')
    # At m=12 the largest gap between successive outer directions is
    # at most 2A, where A=pi-11eta. Every inner direction is within A
    # of an outer direction. Show all r in [u,cutoff] would be too close.
    A=PIHI-11*eta_lo;u=F('2.806');ca=cos_lower(A)
    assert 0<A<PIHI/2
    assert BHI*sin_upper(A)<2
    assert cutoff<BLO*ca
    assert u*u+BHI*BHI-2*u*BHI*ca<4
    print('CERTIFIED rational constants and twelve-boundary radius bound r<2.806')

def validate(path):
    constants();seen=set()
    for line in path.read_text().splitlines():
        xi,yi,ni=map(int,line.split())
        assert -1<=xi<=yi and (xi,yi) not in seen
        seen.add((xi,yi))
        assert ni>=0
        xl,xh=(BLO,BHI) if xi==-1 else (F(xi,RQ),F(xi,RQ))
        yl,yh=(BLO,BHI) if yi==-1 else (F(yi,RQ),F(yi,RQ))
        t=F(ni,AQ)
        assert 0<=t<=PILO
        if ni==0:continue
        # Radius zero is a deliberately defined clipped-angle case.
        if xl==0 or yl==0:
            assert xh+yh<2,(xi,yi,ni)
            continue
        num=xh*xh+yh*yh-4
        den=2*xl*yl if num>=0 else 2*xh*yh
        zupper=num/den
        if zupper<=-1:continue
        assert zupper<1 and cos_lower(t)>=zupper,(xi,yi,ni)
    print('CERTIFIED',len(seen),'exact rational angular lower bounds')
if __name__=='__main__':
    for p in sys.argv[1:]:validate(Path(p))
