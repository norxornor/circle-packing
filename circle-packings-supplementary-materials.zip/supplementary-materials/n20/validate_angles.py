"""Validate all angular bounds used in radial_integer.cpp, using exact rationals,
certify the radial cap of Proposition 11.2 / (11.7), and derive from the paper
every constant that radial_integer.cpp uses (Proposition 11.4).

The floating proposer is untrusted. Every bound is verified over the exact
rational bracket [BLO, BHI] of the construction radius (11.1).

Usage:
  validate_angles.py TABLE...            validate angle tables
  validate_angles.py --parameters 8      print the PARAMETERS line that
                                         radial_integer.cpp must print
"""

# Locate the shared arithmetic from any working directory.
from pathlib import Path as _Path
import sys as _sys
_sys.path.insert(0, str(_Path(__file__).resolve().parents[1]))
from exact_arithmetic import (
    cosine_lower_34 as cos_lower,
    sine_upper_37 as sin_upper,
    sine_bounds,
)
from fractions import Fraction as F
from pathlib import Path
import sys
RQ=AQ=2**40                     # Appendix C: radial grid 2^40; (B.7) Q_theta = 2^40
TWO_PI_UP=6908435304716          # (B.7)
BLO=F('4.1223207369915283214476857921')   # (11.1)
BHI=F('4.1223207369915283214476857923')
PILO,PIHI=F('3.141592653589793238'),F('3.141592653589793239')
ETA_PRINTED=F('0.245026263334771')        # Proposition 11.2: eta > this value
ETA_UPPER=F('.245026263395')              # Table 15: eta < eta+
RCAP=F('2.806')                           # Proposition 11.2 / (11.7) and (11.8)
# Proposition 11.4 and Table 11: retained inner centres (J, K, SJ, SE, SF, F, E).
GAPS=(1,1,2,2,2,2,2)
RADII={'J':'2.171529956399','K':'2.805316132579','E':'2.193139842425','F':'2.235344370918'}
ORDER=('J','K','SJ','SE','SF','F','E')
TARGETS=[F(RADII[name.lstrip('S')]) for name in ORDER]
TARGET_RADIUS=F(1,10**5)
TARGET_DEN=10**12

def ceil_grid(x,q):return -((-(x*q).numerator)//(x*q).denominator)

def composition_counts(n,outer,inner):
    """(compositions, dihedral orbits) from check_compositions.py, Table 20."""
    from check_compositions import composition_checks
    rows=[r for r in composition_checks() if (r['N'],r['outer'],r['inner'])==(n,outer,inner)]
    assert len(rows)==1
    return rows[0]['compositions'],rows[0]['dihedral_orbits']

def constants():
    def atan_bounds(x):
        lo=sum(((-1)**j*x**(2*j+1)/(2*j+1) for j in range(20)),F(0))
        return lo,lo+x**41/41
    a,b=atan_bounds(F(1,5));c,d=atan_bounds(F(1,239))
    assert PILO<16*a-4*d and 16*b-4*c<PIHI
    assert F(TWO_PI_UP,AQ)>=2*PIHI
    # Proposition 11.2: eta > .245026263334771, and eta < eta+ from Table 15.
    assert sin_upper(ETA_PRINTED)<1/BHI
    assert sine_bounds(ETA_UPPER)[0]>1/BLO
    # (11.7) with m = 12: omega_12 = pi - 11 eta and the printed omega_12^+.
    A=F('3.141592653589793239')-11*ETA_PRINTED
    assert A==PIHI-11*ETA_PRINTED
    ca=cos_lower(A)
    assert 0<PILO-11*ETA_UPPER          # 0 < omega_12
    #   omega_12 < omega_12^+ because pi < PIHI and eta > ETA_PRINTED (checked above).
    assert A<PILO/2                     # omega_12^+ < pi/2
    cutoff=BHI-4/BHI                    # c(b) <= c(BHI): c is increasing
    assert cutoff<BLO*ca                # c < b20^- cos(omega_12^+)
    assert RCAP**2+BHI**2-2*RCAP*BHI*ca<4   # D(2.806, b20^+; omega_12^+) < 4
    print('CERTIFIED (11.7): 0 < omega_12 < omega_12^+ < pi/2, c < b- cos(omega_12^+), D(2.806, b+; omega_12^+) < 4')

def parameters(k):
    assert k==8
    constants()
    start=ceil_grid(RCAP,RQ)            # [0, 2.806] rounded outward (Proposition 11.4)
    assert start<4*2**40                    # Appendix H.3: radius numerators < 4 * 2^40
    assert RCAP<=F(start,RQ)
    for t in TARGETS:assert (t*TARGET_DEN).denominator==1
    radius=TARGET_RADIUS*TARGET_DEN
    assert radius.denominator==1
    compositions,orbits=composition_counts(20,12,8)
    assert (compositions,orbits)==(50388,3260)        # Proposition 11.4
    return ('PARAMETERS N=20 K=8 RQ=%d AQ=%d TWO_PI_UP=%d START=0,%d GAPS=%s TARGET_DEN=%d '
            'TARGET=%s TARGET_RADIUS=%d COMPOSITIONS=%d ORBITS=%d'%(RQ,AQ,TWO_PI_UP,start,
            ','.join(map(str,GAPS)),TARGET_DEN,','.join(str(int(t*TARGET_DEN)) for t in TARGETS),
            int(radius),compositions,orbits))

def validate(path):
    seen=set()
    for line in path.read_text().splitlines():
        xi,yi,ni=map(int,line.split())
        assert -1<=xi<=yi and (xi,yi) not in seen
        seen.add((xi,yi))
        assert ni>=0
        xl,xh=(BLO,BHI) if xi==-1 else (F(xi,RQ),F(xi,RQ))
        yl,yh=(BLO,BHI) if yi==-1 else (F(yi,RQ),F(yi,RQ))
        t=F(ni,AQ)
        assert 0<=t<=PILO
        if ni==0:continue
        # Radius zero: a positive bound is valid only when the pair is infeasible.
        if xl==0 or yl==0:
            assert xh+yh<2,(xi,yi,ni)
            continue
        num=xh*xh+yh*yh-4
        den=2*xl*yl if num>=0 else 2*xh*yh
        zupper=num/den
        if zupper<=-1:continue
        assert zupper<1 and cos_lower(t)>=zupper,(xi,yi,ni)
    print('CERTIFIED',len(seen),'exact rational angular lower bounds')
if __name__=='__main__':
    if sys.argv[1:2]==['--parameters']:
        assert len(sys.argv)==3
        print(parameters(int(sys.argv[2])))
    else:
        assert len(sys.argv)>1
        constants()
        for p in sys.argv[1:]:validate(Path(p))
