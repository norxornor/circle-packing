#!/usr/bin/env python3
"""Rigorous existence/feasibility certificate for Goldberg's 20-circle candidate
(Proposition 11.1, (11.6) and Proposition 11.7). Contact lists are compared with
the paper by label in check_reference_certificates.py.
Standard library only; integer outward-rounded interval arithmetic.
The global exclusion and local determination are checked separately.
"""
from math import isqrt
if not __debug__:
    raise RuntimeError('Run without -O: assertions are part of this certificate.')
from fractions import Fraction
from decimal import Decimal, localcontext

D=10**60
class I:
    def __init__(self,a,b=None,raw=False):
        if raw:self.lo,self.hi=a,b;return
        a=Fraction(a);b=a if b is None else Fraction(b)
        self.lo=(a.numerator*D)//a.denominator
        self.hi=-((-b.numerator*D)//b.denominator)
    @classmethod
    def bounds(cls,a,b):return cls(a,b,True)
    @staticmethod
    def co(a):return a if isinstance(a,I) else I(a)
    def __add__(self,o):
        o=I.co(o);return I.bounds(self.lo+o.lo,self.hi+o.hi)
    __radd__=__add__
    def __neg__(self):return I.bounds(-self.hi,-self.lo)
    def __sub__(self,o):return self+-I.co(o)
    def __rsub__(self,o):return I.co(o)+-self
    def __mul__(self,o):
        o=I.co(o);v=[a*b for a in (self.lo,self.hi) for b in (o.lo,o.hi)]
        return I.bounds(min(v)//D,-((-max(v))//D))
    __rmul__=__mul__
    def __truediv__(self,o):
        o=I.co(o);assert o.lo>0 or o.hi<0,'division interval contains zero'
        values=[Fraction(a*D,b) for a in (self.lo,self.hi) for b in (o.lo,o.hi)]
        low=min(values);high=max(values)
        return I.bounds(low.numerator//low.denominator,-((-high.numerator)//high.denominator))
    def __rtruediv__(self,o):return I.co(o)/self
    def sqrt(self):
        assert self.lo>=0,'negative square-root radicand'
        a=isqrt(self.lo*D);b=isqrt(self.hi*D)
        if b*b<self.hi*D:b+=1
        return I.bounds(a,b)
    def square(self):
        low=0 if self.lo<=0<=self.hi else min(self.lo*self.lo,self.hi*self.hi)
        high=max(self.lo*self.lo,self.hi*self.hi)
        return I.bounds(low//D,-((-high)//D))
    def describe(self):
        with localcontext() as ctx:
            ctx.prec=18
            return '[%s, %s]'%(Decimal(self.lo)/D,Decimal(self.hi)/D)

class AD:
    """First derivative enclosure, based on the same rational intervals."""
    def __init__(self,v,d):self.v,self.d=v,d
    @staticmethod
    def const(a):return AD(I(a),I(0))
    @staticmethod
    def co(a):return a if isinstance(a,AD) else AD.const(a)
    def __add__(self,o):
        o=AD.co(o);return AD(self.v+o.v,self.d+o.d)
    __radd__=__add__
    def __neg__(self):return AD(-self.v,-self.d)
    def __sub__(self,o):return self+-AD.co(o)
    def __rsub__(self,o):return AD.co(o)+-self
    def __mul__(self,o):
        o=AD.co(o);return AD(self.v*o.v,self.d*o.v+self.v*o.d)
    __rmul__=__mul__
    def __truediv__(self,o):
        o=AD.co(o);return AD(self.v/o.v,(self.d*o.v-self.v*o.d)/o.v.square())
    def __rtruediv__(self,o):return AD.co(o)/self
    def square(self):return AD(self.v.square(),2*self.v*self.d)
    def sqrt(self):
        v=self.v.sqrt();return AD(v,self.d/(2*v))

def add(p,q):return tuple(a+b for a,b in zip(p,q))
def sub(p,q):return tuple(a-b for a,b in zip(p,q))
def mul(a,p):return tuple(a*x for x in p)
def turn(p):return (-p[1],p[0])
def norm2(p):return sum(x.square() for x in p)
def reflect(p):return (-p[0],p[1])

def construct(B):
    C0=I if isinstance(B,I) else AD.const
    t=(B.square()-1).sqrt()
    c=1-2/B.square();s=2*t/B.square()
    def rot(p):return add(mul(c,p),mul(s,turn(p)))
    def meet(p,q):
        d=sub(q,p);v=(4/norm2(d)-Fraction(1,4)).sqrt()
        return add(mul(C0(Fraction(1,2)),add(p,q)),mul(v,turn(d)))
    A=(C0(1),-t);C=rot(A);H=rot(C);M=rot(H);U=rot(M);L=rot(U)
    F=add(A,(C0(0),C0(2)))
    E=meet(F,H);J=meet(E,U)
    K=(C0(0),J[1]+(4-J[0].square()).sqrt())
    P=[reflect(A),A,reflect(C),C,reflect(F),F,reflect(H),H,reflect(E),E,
       (C0(0),C0(0)),reflect(M),M,reflect(J),J,reflect(U),U,K,reflect(L),L]
    return norm2(sub(L,K))-4,P

CONTACTS={(1,2),(1,3),(2,4),(1,5),(2,6),(5,6),(3,7),(4,8),
          (5,9),(7,9),(6,10),(8,10),(7,12),(8,13),(9,14),(10,15),
          (12,16),(14,16),(13,17),(15,17),(14,18),(15,18),(16,19),
          (18,19),(17,20),(18,20)}
BOUNDARY={1,2,3,4,7,8,12,13,16,17,19,20}
RATTLER=11
LO='4.1223207369915283214476857921'
HI='4.1223207369915283214476857923'

def main(verbose=True):
    flo,_=construct(I(LO));fhi,_=construct(I(HI))
    assert (flo.hi<0 and fhi.lo>0) or (flo.lo>0 and fhi.hi<0),(flo.describe(),fhi.describe())
    df,_=construct(AD(I(LO,HI),I(1)))
    assert Fraction(df.d.lo,D)>Fraction('16.035')
    f,P=construct(I(LO,HI))
    noncontact_slacks=[]
    for i in range(20):
        for j in range(i+1,20):
            d2=norm2(sub(P[i],P[j]))
            if (i+1,j+1) in CONTACTS:
                # Sanity check only; the paper proves the identities.
                assert d2.lo<=4*D<=d2.hi
            else:
                assert d2.lo>4*D,(i+1,j+1,d2.describe())
                noncontact_slacks.append(d2.lo-4*D)
    inner_slacks=[]
    for i,p in enumerate(P,1):
        slack=I(LO,HI).square()-norm2(p)
        if i not in BOUNDARY:
            assert slack.lo>0,(i,slack.describe())
            inner_slacks.append(slack.lo)
        else:assert slack.lo<=0<=slack.hi
    # (11.6): every noncentral center has radius > 2.17, so every |z| <= 17/100
    # is at distance > 2 from all nineteen fixed centers; also 17/100 < b20.
    assert Fraction('2.17')**2==Fraction(47089,10000)
    for i,p in enumerate(P,1):
        if i!=RATTLER:assert Fraction(norm2(p).lo,D)>Fraction('2.17')**2
    assert Fraction('2.17')-Fraction('0.17')==2 and Fraction('0.17')<Fraction(LO)
    # Recover the nineteen retained centres before outward replacement.
    B = I(LO, HI)
    cutoff = B - 4/B
    inner = set(range(1, 21)) - BOUNDARY - {RATTLER}
    for j in inner:
        assert norm2(P[j-1]).hi < cutoff.square().lo
    fixed = {i for i in BOUNDARY
             if any(tuple(sorted((i, j))) in CONTACTS for j in inner)}
    witnesses = {3: (5, '1.3556'), 4: (6, '1.3556'),
                 12: (9, '1.5971'), 13: (10, '1.5971')}
    assert BOUNDARY - fixed == set(witnesses)
    for i, (j, upper) in witnesses.items():
        assert any(tuple(sorted((i, a))) in CONTACTS for a in fixed)
        moved = mul(cutoff/B, P[i-1])
        bound = Fraction(upper)
        assert Fraction(norm2(sub(moved, P[j-1])).hi, D) < bound < 4
    if verbose:
        print('PASS original-position checks: all 12 retained outer centres fixed')
    assert len(CONTACTS)==26 and len(noncontact_slacks)==164
    assert len(BOUNDARY)==12 and len(inner_slacks)==8
    assert Fraction(min(noncontact_slacks),D)>Fraction('0.2346221317')
    assert Fraction(min(inner_slacks),D)>Fraction('9.1237296549')
    if verbose:
        print('f(B_lo):',flo.describe());print('f(B_hi):',fhi.describe())
        print('f prime on interval:',df.d.describe())
        print('Strict noncontact pairs:',len(noncontact_slacks))
        print('Minimum certified noncontact squared-distance slack:',I.bounds(min(noncontact_slacks),min(noncontact_slacks)).describe())
        print('Interior points:',len(inner_slacks))
        print('Minimum certified interior squared-radius slack:',I.bounds(min(inner_slacks),min(inner_slacks)).describe())
        print('By IVT and exact contact identities, feasible packing exists with')
        print(' '+str(Fraction(LO)+1)+' < R < '+str(Fraction(HI)+1))
        print('The movable centre is placed at the origin for the feasibility check.')
        print('Construction and original-position checks passed; see verify.py for the full proof checks.')
    return P
if __name__=='__main__':main()
