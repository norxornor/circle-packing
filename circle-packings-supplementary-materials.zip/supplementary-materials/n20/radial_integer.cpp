// Exact integer replay; floating proposals require separate exact validation.
#include "../integer_bounds.hpp"
#include <algorithm>
#include <array>
#include <cassert>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <limits>
#include <map>
#include <string>
#include <set>
#include <vector>
#ifdef PROPOSE_BOUNDS
#include <cmath>
#endif
// RQ is the radial denominator and AQ the angular denominator.
// Radius index -1 denotes the exact construction boundary radius.
// A GapCounts entry counts outer points between consecutive inner directions.
// RadiusBox intervals are closed and contain real radii, not only grid points.
using namespace std;
using GapCounts = vector < int >;
constexpr int N = 20, KMAX = 8;
constexpr Z RQ = Z(1) << 40, AQ = Z(1) << 40, TWO_PI_UP = 6908435304716LL;
int K, M;
Z start_hi();
const Z TARGET[7] = { 2171529956399LL, 2805316132579LL, 2171529956399LL, 2193139842425LL,
    2235344370918LL, 2235344370918LL, 2193139842425LL };
constexpr Z TQ = 1000000000000LL, TM = 10000000;
// Following outer counts of the seven retained inner centres, Proposition 11.4.
const int GAPS[7] = { 1, 1, 2, 2, 2, 2, 2 };
constexpr int COMPOSITIONS = 50388, ORBITS = 3260;
struct RadiusBox {
    array < Z, KMAX > lo, hi;
};
map < pair < Z, Z >, Z > angles;
vector < int > order;
Z nodes_visited, pair_exclusions, gap_exclusions, cycle_exclusions, retained_boxes, total_nodes = 0,
    total_retained = 0;
Z angle_lower(Z x, Z y) {
    if (y < x)
        swap(x, y);
    auto key = make_pair(x, y);
    auto it = angles.find(key);
    if (it != angles.end())
        return it->second;
#ifdef PROPOSE_BOUNDS
    long double X = x < 0 ? 4.122320736991529L : (long double) x / RQ;
    long double Y = y < 0 ? 4.122320736991529L : (long double) y / RQ;
    long double theta = 0;
    if (fabsl(X - Y) >= 2)
        theta = 0;
    else if (X + Y <= 2)
        theta = acosl(- 1.L);
    else theta = acosl(max(- 1.L, min(1.L, (X * X + Y * Y - 4) / (2 * X * Y))));
    Z n = max(Z(0), Z(floorl((theta - 1e-12L) * AQ)));
    angles[key] = n;
    return n;
#else
    cerr << "missing " << x << "," << y << endl;
    fail("unvalidated angle");
#endif
}
Z angle_box_lower(Z a, Z b, Z c, Z d) {
    return min({ angle_lower(a, c), angle_lower(a, d), angle_lower(b, c), angle_lower(b, d) });
}
// Each rejection applies to every real radius in the closed intervals.
// Pair bounds shorten intervals; angle sums and positive cycles exclude them.
bool excluded(RadiusBox & z, const GapCounts & p) {
    for (int rep = 0; rep < 2; rep++)
        for (int i = 0; i < K; i++)
            for (int j = i + 1; j < K; j++) {
                if (z.hi[i] + z.hi[j] < 2 * RQ) {
                    pair_exclusions++;
                    return true;
                }
                z.lo[i] = max(z.lo[i], 2 * RQ - z.hi[j]);
                z.lo[j] = max(z.lo[j], 2 * RQ - z.hi[i]);
            }
    Z pair_angles[KMAX + 1][KMAX + 1] = { };
    for (int i = 0; i < K; i++)
        for (int j = i + 1; j < K; j++)
            pair_angles[i][j] = pair_angles[j][i] = angle_box_lower(z.lo[i], z.hi[i], z.lo[j], z.hi[j]);
    for (int i = 0; i < K; i++)
        pair_angles[i][K] = pair_angles[K][i] = angle_box_lower(z.lo[i], z.hi[i], - 1, - 1);
    pair_angles[K][K] = angle_lower(- 1, - 1);
    Z sum = 0;
    for (int i = 0; i < K; i++) {
        int j = (i + 1) % K;
        Z chain = p[i] ? pair_angles[i][K] + pair_angles[j][K] + (p[i] - 1) * pair_angles[K][K] : 0;
        sum += max(pair_angles[i][j], chain);
    }
    if (sum > TWO_PI_UP) {
        gap_exclusions++;
        return true;
    }
    Z d[N][N];
    for (int i = 0; i < N; i++) {
        d[i][i] = 0;
        for (int j = i + 1; j < N; j++) {
            Z v = pair_angles[order[i ]][order[j ]];
            d[i][j] = v;
            d[j][i] = v - TWO_PI_UP;
        }
    }
    if (positive_cycle(d)) {
        cycle_exclusions++;
        return true;
    }
    return false;
}
// Acceptance only places every represented arrangement in one of the
// paper's stated neighbourhoods. Local rigidity is checked separately.
bool within_reference_ranges(const RadiusBox & z, const GapCounts & p) {
    // All twenty centres enter the exclusion inequalities. Here only,
    // try each omitted inner centre and retain the other nineteen.
    // Delete one inner direction and merge its neighboring outer counts.
    // The remaining seven radii must match the seven retained inner centres, in either orientation.
    for (int core = 0; core < K; core++) {
        vector < int > ids;
        for (int i = 0; i < K; i++)
            if (i != core)
                ids.push_back(i);
        vector < int > q;
        for (int j = 0; j < 7; j++) {
            int a = ids[j], b = ids[(j + 1) % 7], gap = 0;
            for (int u = a; u != b; u = (u + 1) % K)
                gap += p[u];
            q.push_back(gap);
        }
        for (int start = 0; start < 7; start++)
            for (int rev : { - 1, 1 }) {
                bool match = true;
                for (int j = 0; j < 7; j++) {
                    int t = (start + rev * j + 14) % 7, gt = (t + (rev == 1 ? 0 : 6)) % 7;
                    if (q[j] != GAPS[gt] || (__int128) z.lo[ids[j ]] * TQ < (__int128)(TARGET[t] - TM) *
                        RQ || (__int128) z.hi[ids[j ]] * TQ > (__int128)(TARGET[t] + TM) * RQ)
                        match = false;
                }
                if (match)
                    return true;
            }
    }
    return false;
}
// Depth-first subdivision. The two children share their midpoint and
// cover the complete parent interval. A surviving box must satisfy the
// explicit local conditions; reaching the grid limit is a failure.
void search(const GapCounts & p) {
    order.clear();
    for (int i = 0; i < K; i++) {
        order.push_back(i);
        for (int k = 0; k < p[i]; k++)
            order.push_back(K);
    }
    assert(order.size() == N);
    RadiusBox initial;
    initial.lo.fill(0);
    initial.hi.fill(start_hi());
    vector < RadiusBox > stack { initial };
    nodes_visited = pair_exclusions = gap_exclusions = cycle_exclusions = retained_boxes = 0;
    while (!stack.empty()) {
        if (++ nodes_visited > 50000000)
            fail("node limit");
        RadiusBox z = stack.back();
        stack.pop_back();
        if (excluded(z, p))
            continue;
        if (within_reference_ranges(z, p)) {
            retained_boxes++;
            continue;
        }
        // A subdivision heuristic, not a geometric assertion: prefer resolving
        // the other coordinates when one radius interval lies below one.
        int core = - 1;
        for (int i = 0; i < K; i++)
            if (z.hi[i] < RQ)
                core = i;
        int split = 0;
        Z width = 0;
        for (int i = 0; i < K; i++)
            if (i != core && z.hi[i] - z.lo[i] > width) {
                width = z.hi[i] - z.lo[i];
                split = i;
            }
        if (width <= 1024 && core >= 0 && z.hi[core] - z.lo[core] > width) {
            split = core;
            width = z.hi[core] - z.lo[core];
        }
        if (width < 2)
            fail("unresolved final grid cell");
        Z mid = (z.lo[split] + z.hi[split]) / 2;
        RadiusBox other = z;
        z.hi[split] = mid;
        other.lo[split] = mid;
        stack.push_back(other);
        stack.push_back(z);
    }
    assert(nodes_visited == 2 * (pair_exclusions + gap_exclusions + cycle_exclusions + retained_boxes) -
        1);
    for (int k : p)
        cout << k << ",";
    cout << " nodes=" << nodes_visited << " pair=" << pair_exclusions << " fast=" << gap_exclusions <<
        " full=" << cycle_exclusions << " local=" << retained_boxes << endl;
    total_nodes += nodes_visited;
    total_retained += retained_boxes;
}
// Every constant used by the search, checked against the paper by
// validate_angles.py --parameters 8 and the verification driver.
Z start_hi() {
    return (2806 * RQ + 999) / 1000;
}
void print_parameters() {
    cout << "PARAMETERS N=20 K=" << K << " RQ=" << RQ << " AQ=" << AQ << " TWO_PI_UP=" << TWO_PI_UP
         << " START=0," << start_hi() << " GAPS=";
    for (int i = 0; i < 7; i++) cout << (i ? "," : "") << GAPS[i];
    cout << " TARGET_DEN=" << TQ << " TARGET=";
    for (int i = 0; i < 7; i++) cout << (i ? "," : "") << TARGET[i];
    cout << " TARGET_RADIUS=" << TM << " COMPOSITIONS=" << COMPOSITIONS << " ORBITS=" << ORBITS << endl;
}
// Keep one representative under rotations and reflection of the order.
GapCounts canonical_pattern(GapCounts p) {
    auto best = p;
    for (int s = 0; s < K; s++)
        for (int r : { - 1, 1 }) {
            GapCounts q(K);
            for (int i = 0; i < K; i++)
                q[i] = p[(s + r * i + 2 * K) % K];
            best = min(best, q);
        }
    return best;
}
Z composition_count = 0;
void gen(GapCounts p, int sum, set < GapCounts > & out) {
    if (p.size() == K - 1) {
        ++composition_count;
        p.push_back(M - sum);
        out.insert(canonical_pattern(p));
        return;
    }
    for (int a = 0; a <= M - sum; a++) {
        p.push_back(a);
        gen(p, sum + a, out);
        p.pop_back();
    }
}
int main(int argc, char * * argv) {
    K = 8;
    M = 12;
    if (argc == 2 && string(argv[1]) == "--parameters") {
        print_parameters();
        return 0;
    }
    print_parameters();
#ifndef PROPOSE_BOUNDS
    if (argc != 2)
        fail("supply validated angle table");
    ifstream input(argv[1]);
    if (!input)
        fail("cannot open angle table");
    Z x, y, n;
    while (input >> x >> y >> n) {
        if (x > y || x < - 1 || n < 0 || n > TWO_PI_UP / 2)
            fail("bad record");
        if (!angles.emplace(make_pair(x, y), n).second)
            fail("duplicate record");
    }
    if (!input.eof())
        fail("parse error");
#endif
    set < GapCounts > patterns;
    gen({}, 0, patterns);
    assert(composition_count == COMPOSITIONS);
    assert(patterns.size() == size_t(ORBITS));
    cout << "K=" << K << " M=" << M << " patterns=" << patterns.size() << endl;
    for (auto p : patterns)
        search(p);
    cout << "TOTAL nodes=" << total_nodes << " local=" << total_retained << " angles=" << angles.size()
        << endl;
#ifdef PROPOSE_BOUNDS
    ofstream output("radial20_angles.tsv");
    for (auto &[key, n] : angles)
        output << key.first << '\t' << key.second << '\t' << n << '\n';
    if (!output)
        fail("write failed");
    cout << "PROPOSAL COMPLETE; exact validation required" << endl;
#else
    cout << "PASS exact integer replay" << endl;
#endif
}
