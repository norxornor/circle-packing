#!/usr/bin/env python3
"""Exact local rigidity certificate for the 19-center scaffold of n=20.
The omitted center 11 (one-based) is unconstrained by this local theorem.
This supplies the linear hypotheses of the paper's small-change lemma.
The main proof combines them with the exhaustive radius and order bounds.
"""
if not __debug__:
    raise RuntimeError('Run without -O: assertions are part of this certificate.')
from fractions import Fraction as F
from pathlib import Path
import importlib.util,json
ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('candidate20',ROOT/'verify20_exact.py')
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)

def verify(verbose=True):
    _,full=c.construct(c.I(c.LO,c.HI))
    keep=[i for i in range(20) if i!=10]
    labels={j:i for i,j in enumerate(keep)}
    points=[full[i] for i in keep]
    Q=c.D;m=38
    rows=[]
    for ii,jj in sorted(c.CONTACTS):
        assert ii!=11 and jj!=11
        i,j=labels[ii-1],labels[jj-1]
        row=[c.I(0) for _ in range(38)]
        for d in range(2):
            z=2*(points[i][d]-points[j][d]);row[2*i+d]=z;row[2*j+d]=-z
        rows.append(row[1:]+[c.I(1)])
    for ii in sorted(c.BOUNDARY):
        assert ii!=11
        i=labels[ii-1];row=[c.I(0) for _ in range(38)]
        for d in range(2):row[2*i+d]=-2*points[i][d]
        rows.append(row[1:]+[c.I(1)])
    assert len(rows)==m and all(len(row)==m for row in rows)
    data=json.loads(Path(__file__).with_name('inverse20.json').read_text())
    S=data['scale'];P=data['inverse'];assert S>0 and len(P)==m
    assert all(len(row)==m and all(isinstance(x,int) for x in row) for row in P)
    maximum=0
    for i in range(m):
        total=0
        for j in range(m):
            lo=hi=0
            for k in range(m):
                a,b=rows[k][j].lo,rows[k][j].hi;v=P[i][k]
                lo+=min(v*a,v*b);hi+=max(v*a,v*b)
            target=Q*S if i==j else 0
            total+=max(abs(target-lo),abs(target-hi))
        maximum=max(maximum,total)
    rho=F(maximum,Q*S)
    pnorm=F(max(sum(abs(v) for v in row) for row in P),S)
    assert rho<F(1,10**10)
    error=rho*pnorm/(1-rho)
    assert pnorm+error<7
    stress_lower=min(F(v,S)-error for v in P[-1])
    assert stress_lower>F(1,150)
    if verbose:
        print('CERTIFIED n=20 nineteen retained centres (omitting centre 11): bordered Jacobian invertible')
        print('CERTIFIED inverse infinity norm <7, normalized positive stress >1/150')
        print('residual norm upper bound:',float(rho))
        print('inverse norm upper bound:',float(pnorm+error))
        print('minimum stress lower bound:',float(stress_lower))
        print('LOCAL THEOREM: fix x_1=-1 (one-based labels); if every scaffold')
        print('coordinate differs from candidate by <1/8400, all scaffold centers')
        print('equal the candidate. No closeness requirement on center11.')
    return rho,pnorm+error,stress_lower
if __name__=='__main__':verify()
