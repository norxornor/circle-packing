"""Exact radial-box -> Cartesian-neighborhood certificate for n=20 supported scaffold.
After rotation aligns the competing boundary point with reference sigma(A),
every coordinate displacement is strictly less than 1/8400.
The radical construction and the angle corner lemma are prerequisites.
"""

# Locate the shared arithmetic from any working directory.
from pathlib import Path as _Path
import sys as _sys
_sys.path.insert(0, str(_Path(__file__).resolve().parents[1]))
from exact_arithmetic import (
    cosine_lower_34 as cos_lower,
)
if not __debug__:
    raise RuntimeError('Run without -O: assertions are part of this certificate.')
from fractions import Fraction as F
from math import acos,floor
from functools import lru_cache
from verify20_exact import I,D as SCALE,LO,HI,construct,norm2

AQ=2**40
PILO,PIHI=F(3141592653589793238,10**18),F(3141592653589793239,10**18)
TWO_PI_UP=6908435304716

def constants():
    def atan(x):
        lower=sum(((-1)**j*x**(2*j+1)/(2*j+1) for j in range(20)),F(0))
        return lower,lower+x**41/41
    al,au=atan(F(1,5));bl,bu=atan(F(1,239))
    assert PILO<16*al-4*bu and 16*au-4*bl<PIHI
    assert F(TWO_PI_UP,AQ)>=2*PIHI


nominal=list(map(F,['2.171529956399','2.805316132579','2.171529956399','2.193139842425',
                   '2.235344370918','2.235344370918','2.193139842425']))
EPS=F(1,10**5)
ranges=[(x-EPS,x+EPS) for x in nominal]+[(F(LO),F(HI))]
# Point11 (the free centre) is omitted entirely.
order=[0,7,1,7,2,7,7,3,7,7,4,7,7,5,7,7,6,7,7]
labels=[14,19,17,18,13,15,11,8,6,2,4,0,1,5,3,7,9,12,16]

@lru_cache(None)
def lower(x,y):
    xl,xh=(F(LO),F(HI)) if x is None else (x,x)
    yl,yh=(F(LO),F(HI)) if y is None else (y,y)
    num=xh*xh+yh*yh-4
    den=2*(xl*yl if num>=0 else xh*yh)
    z=num/den
    if z>=1:return 0
    if z<=-1:return floor(PILO*AQ)
    n=max(0,floor(acos(float(z))*AQ)-2)
    while cos_lower(F(n,AQ))<z:n-=1
    assert 0<=F(n,AQ)<=PILO and cos_lower(F(n,AQ))>=z
    return n

def main():
    constants()
    _,P=construct(I(LO,HI))
    for i,label in enumerate([14,17,13,8,4,5,9]):
        radius=norm2(P[label]).sqrt()
        assert ranges[i][0]<=F(radius.lo,SCALE)<=F(radius.hi,SCALE)<=ranges[i][1]
    # Verify the exact construction has the stated cyclic order. Work in
    # coordinates whose positive horizontal axis is original point1's ray.
    refpos=labels.index(0)
    cyclic=labels[refpos:]+labels[:refpos]
    anchor=P[0]
    def cross(a,b):return a[0]*b[1]-a[1]*b[0]
    def dot(a,b):return a[0]*b[0]+a[1]*b[1]
    halves=[]
    for label in cyclic:
        X=dot(P[label],anchor);Y=cross(anchor,P[label])
        if label==0:
            assert X.lo>0
            half=0  # Exact identity cross(anchor,anchor)=0.
        elif Y.lo>0:half=0
        elif Y.hi<0:half=1
        else:raise AssertionError(('unresolved candidate half-plane',label))
        halves.append(half)
    assert halves==sorted(halves)
    for i,a in enumerate(cyclic):
        for j in range(i+1,len(cyclic)):
            b=cyclic[j]
            if halves[i]!=halves[j]:continue
            assert cross(P[a],P[b]).lo>0,('candidate order',a,b)
    print('Exact candidate supported cyclic order certified.')
    g=[[0]*8 for _ in range(8)]
    for i in range(8):
        for j in range(8):
            a=[None] if i==7 else ranges[i]
            b=[None] if j==7 else ranges[j]
            g[i][j]=min(lower(x,y) for x in a for y in b)
    # Rational pair bounds printed in the paper's worked example for F.
    # Indices 0,1,5,6,7 denote J,K,F,E,and the outer radius.
    paper_bounds = [(7,7,538818451292), (5,7,240544847290),
                    (5,6,1030220889616), (6,0,1046670915227),
                    (0,1,867347980931), (1,7,490714158647)]
    for i,j,numerator in paper_bounds:
        assert numerator <= g[i][j]
    outer, af, fe, ej, jk, kl = [entry[2] for entry in paper_bounds]
    paper_lower = outer + af
    paper_reverse = fe + ej + jk + kl + 5*outer - TWO_PI_UP
    assert paper_lower == 779363298582
    assert paper_reverse == -779389103835
    assert -paper_reverse - paper_lower == 25805253
    D=[[0]*19 for _ in range(19)]
    for i in range(19):
        for j in range(i+1,19):
            t=g[order[i]][order[j]]
            D[i][j]=t;D[j][i]=t-TWO_PI_UP
    for k in range(19):
        for i in range(19):
            for j in range(19):D[i][j]=max(D[i][j],D[i][k]+D[k][j])
    assert all(D[i][i]==0 for i in range(19))
    ref=labels.index(0);maximum=F(0)
    target=labels.index(5)
    assert D[ref][target] >= paper_lower and D[target][ref] >= paper_reverse
    print('Worked angle chains for F verified in exact arithmetic.')
    for j,label in enumerate(labels):
        width=F(-D[j][ref]-D[ref][j],AQ)
        assert width>=0
        dr=2*EPS if order[j]!=7 else F(0)
        upper=dr+F(HI)*width
        assert 0<=upper<F(1,8400),(label,upper)
        maximum=max(maximum,upper)
        print('point',label+1,'relative-angle numerators:',D[ref][j],-D[j][ref],
              'width numerator:',-D[j][ref]-D[ref][j],'denominator:',AQ)
        print('point',label+1,'angle-width <=',float(width),'position-distance <=',float(upper))
    assert maximum<F('0.00011675')
    print('PASS: after rotational alignment, every supported coordinate error <1/8400')
    print('Maximum exact error bound:',maximum)
if __name__=='__main__':main()
