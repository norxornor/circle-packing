"""Validate the angle table of energy_integer.cpp with exact rational arithmetic
and derive from the paper every constant energy_integer.cpp uses
(Proposition 11.3).

Usage:
  energy_integer_validate.py TABLE        validate the angle table
  energy_integer_validate.py --parameters print the PARAMETERS line that
                                          energy_integer.cpp must print
"""
from fractions import Fraction as F
from pathlib import Path
import importlib.util,sys
if not __debug__:raise RuntimeError('Assertions must be enabled.')
spec=importlib.util.spec_from_file_location('energy20',Path(__file__).with_name('energy20.py'))
e=importlib.util.module_from_spec(spec);spec.loader.exec_module(e)
RQ=1<<30;AQ=1<<40                     # Appendix C: radial grid 2^30 for this count; (B.7) Q_theta

def floor_grid(x,q):return (x*q).numerator//(x*q).denominator
def ceil_grid(x,q):return -((-(x*q).numerator)//(x*q).denominator)

def pi_lower():
    # Sharper lower pi enclosure from the same Machin identity.
    def atan_bounds(x):
        lo=sum(((-1)**j*x**(2*j+1)/F(2*j+1) for j in range(30)),F(0))
        return lo,lo+x**61/F(61)
    a,b=atan_bounds(F(1,5));c,d=atan_bounds(F(1,239))
    return 16*a-4*d

def parameters():
    e.constants_check()                     # premises: c(b) < C, monotonicity, eta and pi bounds
    start=ceil_grid(e.C,RQ)                 # [0, 3.151994] rounded outward to denominator 2^30
    assert start<4*2**40                    # Appendix H.3: radius numerators < 4 * 2^40
    grid_c=F(start,RQ)
    assert e.C<=grid_c
    assert grid_c*grid_c<e.B_LO*e.B_LO-4    # monotonicity of f_b also on the enlarged interval
    piup=ceil_grid(e.PI_HI,AQ)              # pi < 355/113 <= PIUP/AQ
    eta_lo=floor_grid(e.ETA_LO,AQ)          # ETA_LO/AQ <= eta-
    eta_hi=ceil_grid(e.ETA_HI,AQ)           # ETA_HI/AQ >= eta+
    assert F(piup,AQ)>=e.PI_HI and F(eta_lo,AQ)<=e.ETA_LO and F(eta_hi,AQ)>=e.ETA_HI
    ks=e.EXCLUDED_K
    assert ks==list(range(ks[0],ks[-1]+1))
    return 'PARAMETERS N=20 RQ=%d AQ=%d START=0,%d PIUP=%d ETA_LO=%d ETA_HI=%d K=%d..%d'%(
        RQ,AQ,start,piup,eta_lo,eta_hi,ks[0],ks[-1])

def validate(path):
    e.constants_check()
    pil=pi_lower()
    count=0;seen=set()
    for line in path.read_text().splitlines():
        x,y,n=map(int,line.split());assert x<=y and (x,y) not in seen
        seen.add((x,y));count+=1
        assert x>=-1 and y>=-1
        # Key -1 denotes b+ = B_HI: g(r, b+) <= h_b(r) by (4.9).
        r=e.B_HI if x==-1 else F(x,RQ)
        s=e.B_HI if y==-1 else F(y,RQ)
        t=F(n,AQ);assert 0<=t<=pil
        if abs(r-s)>=2:assert n==0
        elif r+s<=2:pass # Impossible, or pi is required.
        else:
            z=(r*r+s*s-4)/(2*r*s)
            assert e.cos_lower(t)>=z,(x,y,n)
    print('PASS:',count,'exact angle bounds validated')

if __name__=='__main__':
    if sys.argv[1:]==['--parameters']:
        print(parameters())
    else:
        assert len(sys.argv)==2,'usage: energy_integer_validate.py TABLE | --parameters'
        validate(Path(sys.argv[1]))
