"""Validate all integer energy angle proposals using exact rational arithmetic."""
from fractions import Fraction as F
from pathlib import Path
import importlib.util
spec=importlib.util.spec_from_file_location('energy20',Path(__file__).with_name('energy20.py'))
e=importlib.util.module_from_spec(spec);spec.loader.exec_module(e)
e.constants_check()
RQ=1<<30;AQ=1<<40
GRID_C=F((3151994*RQ+999999)//1000000,RQ)
assert GRID_C*GRID_C < e.B_LO*e.B_LO-4
# Sharper lower pi enclosure is proved by the same Machin identity.
def atan_bounds(x):
    lo=sum(((-1)**j*x**(2*j+1)/F(2*j+1) for j in range(30)),F(0))
    return lo,lo+x**61/F(61)
a,b=atan_bounds(F(1,5));c,d=atan_bounds(F(1,239));pil=16*a-4*d
count=0;seen=set()
path=Path(__file__).with_name('energy20_angles.tsv')
for line in path.read_text().splitlines():
    x,y,n=map(int,line.split());assert x<=y and (x,y) not in seen
    seen.add((x,y));count+=1
    assert x>=-1 and y>=-1
    r=e.B_HI if x==-1 else F(x,RQ)
    s=e.B_HI if y==-1 else F(y,RQ)
    t=F(n,AQ);assert 0<=t<=pil
    if abs(r-s)>=2:assert n==0
    elif r+s<=2:pass # Impossible, or pi is required.
    else:
        z=(r*r+s*s-4)/(2*r*s)
        assert e.cos_lower(t)>=z,(x,y,n)
print('PASS:',count,'exact angle bounds validated')
