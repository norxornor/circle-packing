// Exact integer energy exclusion. PROPOSE_BOUNDS proposes a table; Python validates it.
// Replay-only builds never evaluate transcendental functions.
#include <algorithm>
#include <array>
#include <cassert>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <map>
#include <vector>
#ifdef PROPOSE_BOUNDS
#include <cmath>
#endif
#ifdef NDEBUG
#error "Assertions are proof checks; do not compile with NDEBUG."
#endif
using namespace std;
using Z = int64_t;
constexpr int MAXK = 14;
constexpr Z RQ = Z(1) << 30, AQ = Z(1) << 40;
constexpr Z RHI = (3151994 * RQ + 999999) / 1000000;
constexpr Z PIUP = (355 * AQ + 112) / 113;
constexpr Z ETA_LO = (245026263334LL * (__int128) AQ) / 1000000000000LL;
constexpr Z ETA_HI = (245026263395LL * (__int128) AQ + 999999999999LL) / 1000000000000LL;
struct Box {
    array < Z, MAXK > lo, hi;
};
map < pair < Z, Z >, Z > angles;
long long nodes, energy, angular, pairpr;
[[ noreturn ]] void fail(const char * s) {
    cerr << s << '\n';
    exit(1);
}
Z g(Z x, Z y) {
    if (x > y)
        swap(x, y);
    auto key = make_pair(x, y);
    auto it = angles.find(key);
    if (it != angles.end())
        return it->second;
#ifdef PROPOSE_BOUNDS
    long double r = x < 0 ? 4.122320737L : (long double) x / RQ, s = y < 0 ? 4.122320737L : (long double) y / RQ;
    Z a;
    if (fabsl(r - s) >= 2)
        a = 0;
    else if (r + s <= 2)
        a = Z(3141592) * AQ / 1000000;
    else a = max(Z(0), Z(floorl((acosl(clamp((r * r + s * s - 4) / (2 * r * s), - 1.L, 1.L)) - 1e-8L) * AQ)));
    angles[key] = a;
    return a;
#else
    cerr << "missing angle " << x << ' ' << y << '\n';
    fail("missing table entry");
#endif
}
Z gm(Z a, Z b, Z c, Z d) {
    return min({ g(a, c), g(a, d), g(b, c), g(b, d) });
}
bool excluded(Box & z, int k) {
    for (int rep = 0; rep < 2; rep++) {
        for (int i = 1; i < k; i++) {
            z.lo[i] = max(z.lo[i], z.lo[0]);
            z.hi[0] = min(z.hi[0], z.hi[i]);
        }
        z.hi[1] = min(z.hi[1], z.hi[k - 1]);
        z.lo[k - 1] = max(z.lo[k - 1], z.lo[1]);
        for (int i = 0; i < k; i++)
            for (int j = i + 1; j < k; j++) {
                z.lo[i] = max(z.lo[i], 2 * RQ - z.hi[j]);
                z.lo[j] = max(z.lo[j], 2 * RQ - z.hi[i]);
            }
        Z cost = 0;
        for (int i = 0; i < k; i++) {
            if (z.lo[i] > z.hi[i]) {
                pairpr++;
                energy++;
                return true;
            }
            cost += max(Z(0), g(z.lo[i], - 1) - ETA_HI);
        }
        if (cost > PIUP - (20 - k) * ETA_LO) {
            energy++;
            return true;
        }
    }
    Z a[MAXK][MAXK] = { };
    for (int i = 0; i < k; i++)
        for (int j = i + 1; j < k; j++) {
            Z v = gm(z.lo[i], z.hi[i], z.lo[j], z.hi[j]);
            a[i][j] = v;
            a[j][i] = v - 2 * PIUP;
        }
    for (int t = 0; t < k; t++) {
        for (int i = 0; i < k; i++)
            for (int j = 0; j < k; j++) {
                __int128 v = (__int128) a[i][t] + a[t][j];
                if (v > INT64_MAX || v < INT64_MIN)
                    fail("overflow");
                a[i][j] = max(a[i][j], (Z) v);
            }
        for (int i = 0; i < k; i++)
            if (a[i][i] > 0) {
                angular++;
                return true;
            }
    }
    return false;
}
void search(int k) {
    Box z;
    z.lo.fill(0);
    z.hi.fill(RHI);
    vector < Box > stack { z };
    nodes = energy = angular = pairpr = 0;
    while (!stack.empty()) {
        z = stack.back();
        stack.pop_back();
        nodes++;
        if (excluded(z, k))
            continue;
        int j = 0;
        Z width = 0;
        for (int i = 0; i < k; i++)
            if (z.hi[i] - z.lo[i] > width) {
                j = i;
                width = z.hi[i] - z.lo[i];
            }
        if (width < 2)
            fail("unresolved grid cell");
        Z mid = (z.hi[j] + z.lo[j]) / 2;
        Box other = z;
        z.hi[j] = mid;
        other.lo[j] = mid;
        stack.push_back(other);
        stack.push_back(z);
        if (nodes > 20000000)
            fail("node limit");
    }
    assert(nodes == 2 * (energy + angular) - 1);
    cout << "CERTIFIED k=" << k << " nodes=" << nodes << " energy=" << energy << " angular=" << angular << " empty_radial=" << pairpr << '\n';
}
int main(int argc, char * * argv) {
#ifndef PROPOSE_BOUNDS
    if (argc != 2)
        fail("supply validated table");
    ifstream in(argv[1]);
    Z x, y, a;
    while (in >> x >> y >> a) {
        if (x > y || a < 0 || a > PIUP || !angles.emplace(make_pair(x, y), a).second)
            fail("malformed table");
    }
    if (!in.eof())
        fail("table parse");
#endif
    for (int k = 9; k <= 14; k++)
        search(k);
#ifdef PROPOSE_BOUNDS
    ofstream out("energy20_angles.tsv");
    for (auto &[p, a] : angles)
        out << p.first << '\t' << p.second << '\t' << a << '\n';
    if (!out)
        fail("write failed");
    cout << "PROPOSED angles=" << angles.size() << '\n';
#else
    cout << "PASS integer energy replay\n";
#endif
}
