"""Exact rational radial-energy exclusion for N=15, k=6,7,8 (Proposition 7.3).
Floating point is used only to propose an angular lower bound. Each such
bound is validated by exact Fraction arithmetic and a Taylor inequality.
"""

# Locate the shared arithmetic from any working directory.
from pathlib import Path as _Path
import sys as _sys
_sys.path.insert(0, str(_Path(__file__).resolve().parents[1]))
from exact_arithmetic import (
    cosine_lower_26 as cos_lower,
    sine_bounds as sin_bounds,
    sqrt_bounds as sqrt_bounds,
)
from fractions import Fraction as F
from functools import lru_cache
from math import acos, floor, isqrt
from time import monotonic

Q = 2**20
PI_HI = F(355,113)
B_LO, B_HI = F(35213569,10**7), F(3521357,10**6)
ETA_LO, ETA_HI = F(287943,10**6), F(287944,10**6)
EXCLUDED_K = [6, 7, 8]   # Table 17
C = F(1193,500)

# For 0<=x<=355/113, the omitted alternating Taylor tail has
# decreasing terms. Last terms below have the indicated signs.



def constants_check():
    """Premises of this search; constants.py (C0) checks the paper's
    Lemma 2.6 hypotheses, the count bounds and that these constants are the
    Table 14/15 values."""
    # B_LO < b15 < B_HI with b15^2 = 6+2/sqrt5+4 sqrt(1+2/sqrt5), (7.5).
    l,u=sqrt_bounds(F(5))
    tlo,thi=2/u,2/l
    vlo,vhi=sqrt_bounds(1+tlo)[0],sqrt_bounds(1+thi)[1]
    blo,bhi=sqrt_bounds(6+tlo+4*vlo)[0],sqrt_bounds(6+thi+4*vhi)[1]
    assert B_LO < blo and bhi < B_HI
    assert B_HI-4/B_HI < C          # c(b) < C: the start box [0,C] contains every inner radius
    assert C*C < B_LO*B_LO-4        # (4.7): h_b and f_b are nondecreasing on [0,C], so (4.8) holds
    assert sin_bounds(ETA_LO)[1] < 1/B_HI   # ETA_LO < eta(b)
    assert sin_bounds(ETA_HI)[0] > 1/B_LO   # ETA_HI > eta(b)
    # pi bounds via Machin's identity: 3.141592 < pi < 355/113.
    def atan_bounds(x):
        lo=sum(((-1)**j*x**(2*j+1)/F(2*j+1) for j in range(20)),F(0))
        hi=lo+x**41/F(41)
        return lo,hi
    a,b=atan_bounds(F(1,5));c,d=atan_bounds(F(1,239))
    assert 16*b-4*c < PI_HI
    assert 16*a-4*d > F(3141592,10**6)

@lru_cache(None)
def angular_lower(x,y):
    """Lower bound for the required angular separation at given radii."""
    if abs(x-y)>=2:
        return F(0)
    if x+y<=2:
        # Impossible when <2. For equality true separation is pi.
        return F(3141592,10**6)
    z=(x*x+y*y-4)/(2*x*y)
    # z in (-1,1). acos only proposes a rational t, never certifies one.
    n=max(0,floor(acos(max(-1.,min(1.,float(z))))*Q)-1)
    while n and cos_lower(F(n,Q)) < z:
        n-=1
    t=F(n,Q)
    assert 0 <= t <= F(3141592,10**6)
    assert t==0 or cos_lower(t)>=z
    return t

@lru_cache(None)
def cost_lower(r):
    # h(r)=g(r,B) increases on [B-2,C], and decreases as B increases.
    # h=0 below B-2, including any radii where our B_HI surrogate
    # exceeds r by at least two.
    return max(F(0), angular_lower(r,B_HI)-ETA_HI)

@lru_cache(None)
def corner_lower(a,b,c,d):
    return min(angular_lower(a,c),angular_lower(a,d),
               angular_lower(b,c),angular_lower(b,d))

def exclude(k, use_energy=True):
    budget=PI_HI-(15-k)*ETA_LO
    stack=[([F(0)]*k,[C]*k)]
    counts={'boxes':0,'pair':0,'energy':0,'angle':0}
    minwidth=C
    def ruled(lo,hi):
        for rep in range(2):
            # Choose point zero of smallest radius; use reflection to
            # put radius 1 <= radius k-1. These are label symmetries.
            for i in range(1,k):
                lo[i]=max(lo[i],lo[0]); hi[0]=min(hi[0],hi[i])
            hi[1]=min(hi[1],hi[k-1]);lo[k-1]=max(lo[k-1],lo[1])
            for i in range(k):
                for j in range(i+1,k):
                    if hi[i]+hi[j]<2:
                        counts['pair']+=1;return True
                    lo[i]=max(lo[i],2-hi[j]);lo[j]=max(lo[j],2-hi[i])
            if any(lo[i]>hi[i] for i in range(k)):
                counts['pair']+=1;return True
            if use_energy and sum(map(cost_lower,lo))>budget:
                counts['energy']+=1;return True
        g=[[F(0)]*k for _ in range(k)]
        for i in range(k):
            for j in range(i+1,k):
                g[i][j]=g[j][i]=corner_lower(lo[i],hi[i],lo[j],hi[j])
        if sum(g[i][(i+1)%k] for i in range(k))>2*PI_HI:
            counts['angle']+=1;return True
        # Difference bounds on ordered angular coordinates:
        # theta_j-theta_i >= g_ij, theta_i-theta_j >= g_ij-2*pi.
        # Replace pi by a rigorous upper bound; this weakens constraints.
        v=[[F(0)]*k for _ in range(k)]
        for i in range(k):
            for j in range(i+1,k):
                v[i][j]=g[i][j];v[j][i]=g[i][j]-2*PI_HI
        for z in range(k):
            for i in range(k):
                for j in range(k):
                    v[i][j]=max(v[i][j],v[i][z]+v[z][j])
            if any(v[i][i]>0 for i in range(k)):
                counts['angle']+=1;return True
        return False
    start=monotonic()
    while stack:
        lo,hi=stack.pop();counts['boxes']+=1
        if ruled(lo,hi):continue
        i=max(range(k),key=lambda i:hi[i]-lo[i]);width=hi[i]-lo[i]
        minwidth=min(minwidth,width)
        assert width>F(1,10**6), 'Unresolved box: certificate failed.'
        mid=(lo[i]+hi[i])/2
        hi2=hi.copy();hi2[i]=mid
        lo2=lo.copy();lo2[i]=mid
        stack.append((lo2,hi.copy()));stack.append((lo.copy(),hi2))
    assert counts['boxes']==2*(counts['pair']+counts['energy']+counts['angle'])-1
    print('CERTIFIED',k,'energy' if use_energy else 'capacity',counts,flush=True)
    print('TIMING k=%d minimum_split_width=%s seconds=%s'%(k,float(minwidth),round(monotonic()-start,3)),flush=True)
    return counts

if __name__=='__main__':
    constants_check()
    import sys
    ns=list(map(int,sys.argv[1:])) or EXCLUDED_K
    for k in ns:exclude(k,use_energy=True)
