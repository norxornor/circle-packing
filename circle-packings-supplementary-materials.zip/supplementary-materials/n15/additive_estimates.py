#!/usr/bin/env python3
"""Exact checks for Section 7.5-7.6 and Appendix E (fifteen circles).

  * (7.15): a(1-1/200) < 1.693 <= r_i <= 1.709 < a(1+1/200), with the same
    target interval [1.693, 1.709] that the search of Proposition 7.4 accepts;
  * Appendix E: 2.23606^2 < 5 < 2.23607^2, 1.70130 < a < 1.70131,
    1.692 < a(1-1/200) < 1.693, 1.709 < a(1+1/200) < 1.711, the domain claims
    |r-s| < .019 < 2 < r+s and |b15-r| < 1.829357 < 2 < r+b15, (E.2)-(E.6);
  * Lemma 7.7: 1 < t < 3/2, hence t > chi = 1/t > 2/3, and 2chi/5 - 20eps > 1/6.
"""
from fractions import Fraction as F
from pathlib import Path
import sys
if not __debug__:
    raise RuntimeError('Assertions must be enabled.')
sys.path.insert(0, str(Path(__file__).resolve().parent))
from radial_integer_validate import TARGET

slo, shi = F('2.23606'), F('2.23607')
assert slo*slo < 5 < shi*shi
alo, ahi = F('1.70130'), F('1.70131')
assert alo*alo < 2+2/shi and 2+2/slo < ahi*ahi          # a^2 = 2+2/sqrt5, (7.4)
v = F(199,200); w = F(201,200); eps = F(1,200)
# (7.15) with the accepted target interval of Proposition 7.4.
assert TARGET == (F('1.693'), F('1.709'))
assert ahi*v < TARGET[0] and TARGET[1] < alo*w
# Appendix E: both varying radii lie in (1.692, 1.711).
assert F('1.692') < alo*v and ahi*v < F('1.693')
assert F('1.709') < alo*w and ahi*w < F('1.711')
rlo, rhi = F('1.692'), F('1.711')
blo, bhi = F('3.5213569'), F('3.521357')                # Table 14, certified in constants.py
assert rhi - rlo == F('.019') and F('.019') < 2 < 2*rlo  # |r-s| < .019 < 2 < r+s
assert bhi - rlo == F('1.829357') and F('1.829357') < 2 < rlo + blo   # |b15-r| < 1.829357 < 2 < r+b15
# (E.2)
L, U = rlo**2, rhi**2
DL, DU = blo**2, bhi**2
# Claim E.2, (E.3)-(E.4)
di = 4*L*L-(2*U-4)**2
assert 2*L-4 > 0 and di > 25
R = (16*U*(2*U-4)+32*U*U)/(5*di)                         # M1
V = (U-L+4)/5                                            # M2
assert (R+V)/(v*v) < 4 < 20
# Claim E.3, (E.5)-(E.6)
do = 4*L*DL-(U+DU-4)**2
assert do > 9 and U-DL+4 < 0 and L+DL-4 > 0
T = 16*U*(U+DU-4)/(3*do)                                 # M3
W = (DU-L-4)/3                                           # M4
assert (T+W)/(v*v) < F('14.918') < 15 < 20
# Lemma 7.7: t^2 = 1+2/sqrt5, so 1 < t < 3/2 and chi = 1/t > 2/3.
t2hi = 1 + 2/slo
assert 1 < 1 + 2/shi and t2hi < F(9, 4)
chi_lower = F(2, 3)                                      # strict: chi > 2/3
assert F(2,5)*chi_lower - 20*eps == F(1,6)               # so 2chi/5 - 20eps > 1/6 strictly
print('PASS proportional radius estimates; strict local coefficient >1/6')
