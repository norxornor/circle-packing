#!/usr/bin/env python3
"""Exact bounds for proportional radius changes in Appendix D."""
from fractions import Fraction as F
if not __debug__:
    raise RuntimeError('Assertions must be enabled.')
slo, shi = F('2.23606'), F('2.23607')
assert slo*slo < 5 < shi*shi
alo, ahi = F('1.70130'), F('1.70131')
assert alo*alo < 2+2/shi and 2+2/slo < ahi*ahi
v = F(199,200); w = F(201,200)
assert F('1.692') < alo*v and ahi*v < F('1.693')
assert F('1.709') < alo*w and ahi*w < F('1.711')
L, U = F('1.692')**2, F('1.711')**2
DL, DU = F('3.5213569')**2, F('3.521357')**2
di = 4*L*L-(2*U-4)**2
assert 2*L-4 > 0 and di > 25
R = (16*U*(2*U-4)+32*U*U)/(5*di)
V = (U-L+4)/5
assert (R+V)/(v*v) < 4 < 20
do = 4*L*DL-(U+DU-4)**2
assert do > 9 and U-DL+4 < 0 and L+DL-4 > 0
T = 16*U*(U+DU-4)/(3*do)
W = (DU-L-4)/3
assert (T+W)/(v*v) < F('14.918') < 15 < 20
assert F(2,5)*F(2,3)-20*F(1,200) == F(1,6)
print('PASS proportional radius estimates; strict local coefficient >1/6')
