#!/usr/bin/env python3
"""Exact certificates for the fifteen-circle construction and Proposition 7.2.

Checked here (all with exact rational or Q(sqrt5) arithmetic):
  * Section 7.1: cos(pi/5) = (1+sqrt5)/4 is a root of (gamma+1)(4gamma^2-2gamma-1),
    which equals 4gamma^3+2gamma^2-3gamma-1; the identities (7.4) a^2 = 2+2/sqrt5,
    t^2 = 1+2/sqrt5, (7.5) b15^2 = (t+2)^2+1 = 6+2/sqrt5+4t; a < 2 and 1 < t < 3/2;
    the exact values of cos and sin of pi/5 and 2pi/5 used by the construction.
  * Lemma 7.1 (feasibility of P15): the 20 contacts (square identities) agree with
    the interval coordinates, and the other 85 squared distances exceed 4.
  * Proposition 7.2 for m = 10: every hypothesis in (3.9), the bounds (7.8) and
    2.385 < c(b15) < 2.386.
  * Table 2: every printed strict bound, derived as in Section 7.3 from (7.8) and
    sin w <= w, cos w >= 1-w^2/2, cos 2w >= 1-2w^2, including the worked value
    3.95468237582; every printed bound is less than 4 (Lemma 3.4).
The remaining hypotheses of Lemma 2.6, (4.7) and the counts are checked in
constants.py.
"""

from fractions import Fraction as Q
from math import isqrt


class Interval:
    """Closed interval with exact rational endpoints."""

    def __init__(self, lo, hi=None):
        self.lo = Q(lo)
        self.hi = Q(lo if hi is None else hi)
        assert self.lo <= self.hi

    def __add__(self, other):
        other = interval(other)
        return Interval(self.lo + other.lo, self.hi + other.hi)

    __radd__ = __add__

    def __neg__(self):
        return Interval(-self.hi, -self.lo)

    def __sub__(self, other):
        return self + -interval(other)

    def __rsub__(self, other):
        return interval(other) + -self

    def __mul__(self, other):
        other = interval(other)
        products = (self.lo * other.lo, self.lo * other.hi,
                    self.hi * other.lo, self.hi * other.hi)
        return Interval(min(products), max(products))

    __rmul__ = __mul__

    def __truediv__(self, other):
        other = interval(other)
        assert other.lo * other.hi > 0
        return self * Interval(1 / other.hi, 1 / other.lo)

    def __rtruediv__(self, other):
        return interval(other) / self

    def __pow__(self, n):
        assert n == 2
        upper = max(self.lo * self.lo, self.hi * self.hi)
        lower = 0 if self.lo <= 0 <= self.hi else min(self.lo**2, self.hi**2)
        return Interval(lower, upper)

    def __repr__(self):
        return f"[{float(self.lo):.16g}, {float(self.hi):.16g}]"


def interval(value):
    return value if isinstance(value, Interval) else Interval(value)


def sqrt(value):
    value = interval(value)
    assert value.lo >= 0
    scale = 10**35
    lo = isqrt(value.lo.numerator * scale**2 // value.lo.denominator)
    hi = isqrt(value.hi.numerator * scale**2 // value.hi.denominator)
    return Interval(Q(lo, scale), Q(hi + 1, scale))


def atan_point(value, terms=30):
    assert 0 <= value < 1
    total = sum(((-1)**k * value**(2*k + 1) / Q(2*k + 1)
                 for k in range(terms)), Q(0))
    remainder_bound = (-1)**terms * value**(2*terms + 1) / Q(2*terms + 1)
    return Interval(min(total, total + remainder_bound),
                    max(total, total + remainder_bound))


def trig_point(value, cosine=False, terms=18):
    # On [0, 11/8] every term ratio z^2/((n+1)(n+2)) <= (11/8)^2/2 < 1, so the
    # alternating tails are bounded by their first terms (Appendix B.2).
    assert Q(11, 8)**2 < 2
    assert 0 <= value <= Q(11, 8)
    term = Q(1) if cosine else value
    total = term
    for k in range(1, terms):
        denominator = (2*k - 1)*(2*k) if cosine else (2*k)*(2*k + 1)
        term *= -value*value / Q(denominator)
        total += term
    denominator = ((2*terms - 1)*(2*terms) if cosine
                   else (2*terms)*(2*terms + 1))
    next_term = term * (-value*value / Q(denominator))
    return Interval(min(total, total + next_term), max(total, total + next_term))


def sin(value):
    # [0,11/8] lies inside the interval of increase [0,pi/2].
    value = interval(value)
    return Interval(trig_point(value.lo).lo, trig_point(value.hi).hi)


def cos(value):
    value = interval(value)
    return Interval(trig_point(value.hi, True).lo,
                    trig_point(value.lo, True).hi)


def asin(value):
    value = interval(value)
    assert 0 < value.lo <= value.hi < Q(4, 5)
    lo, hi = Q(0), Q(1)
    for _ in range(100):
        mid = (lo + hi) / 2
        sine = trig_point(mid)
        if sine.hi < value.lo:
            lo = mid
        elif sine.lo > value.hi:
            hi = mid
        else:
            break
    return Interval(lo, hi)


def inside(value, lo, hi):
    assert Q(lo) < value.lo <= value.hi < Q(hi)


class R5:
    """Exact numbers x + y sqrt5 with rational x, y."""
    def __init__(self, x, y=0):
        self.x, self.y = Q(x), Q(y)
    def __add__(a, b):
        b = b if isinstance(b, R5) else R5(b); return R5(a.x + b.x, a.y + b.y)
    __radd__ = __add__
    def __neg__(a): return R5(-a.x, -a.y)
    def __sub__(a, b): return a + -(b if isinstance(b, R5) else R5(b))
    def __rsub__(a, b): return R5(b) - a
    def __mul__(a, b):
        b = b if isinstance(b, R5) else R5(b)
        return R5(a.x*b.x + 5*a.y*b.y, a.x*b.y + a.y*b.x)
    __rmul__ = __mul__
    def inverse(a):
        n = a.x*a.x - 5*a.y*a.y
        assert n != 0
        return R5(a.x/n, -a.y/n)
    def __truediv__(a, b):
        return a * (b if isinstance(b, R5) else R5(b)).inverse()
    def __rtruediv__(a, b):
        return R5(b) * a.inverse()
    def __eq__(a, b):
        b = b if isinstance(b, R5) else R5(b); return a.x == b.x and a.y == b.y
    def interval(a):
        return a.x + a.y*sqrt(5)


def exact_identities():
    """Section 7.1 identities and the exact trigonometric values used below."""
    root5 = R5(0, 1)
    gamma = (1 + root5)/4                                   # cos(pi/5)
    # Triple/double angle: 4g^3-3g = -(2g^2-1)  <=>  (g+1)(4g^2-2g-1) = 0.
    # Polynomial identity, compared coefficientwise (constant term first).
    def polymul(p, q):
        r = [0]*(len(p) + len(q) - 1)
        for i, x in enumerate(p):
            for j, y in enumerate(q): r[i + j] += x*y
        return r
    assert polymul([1, 1], [-1, -2, 4]) == [-1, -3, 2, 4]   # = 4g^3+2g^2-3g-1
    assert 4*gamma*gamma - 2*gamma - 1 == R5(0)
    assert gamma.x > 0                                      # the positive root
    sin2 = 1 - gamma*gamma                                  # sin^2(pi/5)
    assert sin2 == R5(Q(10, 16), Q(-2, 16))                 # = (10-2sqrt5)/16
    a2, t2 = 1/sin2, gamma*gamma/sin2                       # csc^2, cot^2
    assert a2 == 2 + 2/root5 and t2 == 1 + 2/root5          # (7.4)
    # (7.5): (t+2)^2+1 = t^2+4t+5 = 6+2/sqrt5+4t once t^2 = 1+2/sqrt5.
    assert t2 + 5 == 6 + 2/root5
    # Double angle values used by construction_certificate.
    c2 = 2*gamma*gamma - 1
    assert c2 == (root5 - 1)/4                              # cos(2pi/5)
    assert 1 - c2*c2 == R5(Q(10, 16), Q(2, 16))             # sin^2(2pi/5) = (10+2sqrt5)/16
    assert 4*sin2*gamma*gamma == 1 - c2*c2                  # sin(2pi/5) = 2 sin(pi/5) cos(pi/5)
    # a < 2 and 1 < t < 3/2, from a^2 < 4 and 1 < t^2 < 9/4.
    a2i, t2i = a2.interval(), t2.interval()
    assert a2i.hi < 4 and 1 < t2i.lo and t2i.hi < Q(9, 4)
    print("Exact Q(sqrt5) identities (7.4), (7.5), cos and sin of pi/5, 2pi/5; a < 2, 1 < t < 3/2: PASS")


def pentagon_certificate():
    pi = 16*atan_point(Q(1, 5)) - 4*atan_point(Q(1, 239))
    z = 2 / sqrt(5)
    B = sqrt(6 + z + 4*sqrt(1 + z))
    eta = asin(1 / B)
    m = 10
    lam, A, ell = pi - m*eta, pi - (m - 1)*eta, B - 2       # (3.1), (3.8)

    def radial_inverse(angle):                              # t_b(theta), (3.7)
        return B*cos(angle) - sqrt(4 - B**2*sin(angle)**2)

    u = radial_inverse(A)                                   # u_gap
    v = 2 - radial_inverse(eta + lam/4)                     # v_gap
    c = B - 4/B
    E = sqrt(B**2 - 1) - sqrt(3)                            # r*(b), (2.10)
    # (3.9), one condition at a time.
    assert lam.lo > 0                                       # lambda_m > 0
    assert 0 < v.lo and v.hi < ell.lo and ell.hi < E.lo and E.hi < u.lo and u.hi < c.lo
    assert E.hi < (2 - v).lo and (2 - v).hi < c.lo          # r* < 2 - v_gap < c
    assert u.hi < (B*cos(A)).lo                             # u_gap < b cos(omega_m)
    assert (B*sin(A)).hi < 2                                # b sin(omega_m) < 2
    assert 0 < A.lo and A.hi < (pi/2).lo                    # 0 < omega_m < pi/2
    # (7.8) and the cutoff bounds of Proposition 7.2.
    inside(u, Q(2220, 1000), Q(2221, 1000))
    inside(v, Q(281, 1000), Q(283, 1000))
    inside(ell, Q(1521, 1000), Q(1522, 1000))
    inside(A, 0, Q(551, 1000))
    inside(c, Q(2385, 1000), Q(2386, 1000))
    print("Proposition 7.2: (3.9) for m = 10, (7.8) and 2.385 < c < 2.386: PASS")
    for name, value in (("B", B), ("eta", eta), ("omega_10", A), ("u_gap", u), ("v_gap", v)):
        print(f"  {name} = {value}")
    return B


def table2():
    """Table 2 from (7.8) with sin w <= w, cos w >= 1-w^2/2, cos 2w >= 1-2w^2."""
    u0, u1 = Q('2.220'), Q('2.221')
    v0, v1 = Q('.281'), Q('.283')
    l0, l1 = Q('1.521'), Q('1.522')
    w = Q('.551')                                           # 0 < omega_10 < .551
    cos_w, sin_w, cos_2w = 1 - w*w/2, w, 1 - 2*w*w           # bounds valid for 0 < omega < w
    assert cos_w > 0 and cos_2w > 0                         # the subtracted products stay positive
    rows = [("u_gap, v+",  u1**2 + v1**2 - 2*u0*v0*cos_w,  '3.955'),
            ("u_gap, l+",  u1**2 + l1**2 - 2*u0*l0*cos_w,  '1.522'),
            ("l+, l-",     4*l1**2*sin_w**2,               '2.814'),
            ("v+, v-",     4*v1**2*sin_w**2,               '.098'),
            ("l+, v-",     l1**2 + v1**2 - 2*l0*v0*cos_2w, '2.062'),
            ("l+, v+",     (l1 - v0)**2,                   '1.541')]
    assert rows[0][1] == Q('3.95468237582')                 # worked value in Section 7.3
    assert rows[5][1] == Q('1.540081')
    for name, value, bound in rows:
        assert value < Q(bound) < 4, name
        print(f"  Table 2 {name}: {float(value):.9f} < {bound} < 4")
    print("Table 2: all printed strict bounds verified; all are less than 4: PASS")


def construction_certificate(B):
    root5 = sqrt(5)
    cq = (root5 + 1)/4
    sq = sqrt(10 - 2*root5)/4
    c2q = (root5 - 1)/4
    s2q = sqrt(10 + 2*root5)/4
    a, t = 1/sq, cq/sq
    h = t + 2
    assert a.hi < 2  # Gives eta<q/2 in the analytic feasibility proof.

    def rotate(point):
        x, y = point
        return c2q*x - s2q*y, s2q*x + c2q*y

    points = {}
    inner = (a, Interval(0))
    normal = (cq, sq)
    for i in range(5):
        points[("A", i)] = inner
        nx, ny = normal
        points[("-", i)] = (h*nx + ny, h*ny - nx)
        points[("+", i)] = (h*nx - ny, h*ny + nx)
        inner, normal = rotate(inner), rotate(normal)

    def edge(x, y):
        return frozenset((x, y))

    exact_contacts = set()
    for i in range(5):
        exact_contacts.update((
            edge(("A", i), ("A", (i+1) % 5)),
            edge(("-", i), ("+", i)),
            edge(("A", i), ("-", i)),
            edge(("A", (i+1) % 5), ("+", i)),
        ))
    assert len(exact_contacts) == 20
    # The twenty contact equalities are proved by the square identities in the
    # module docstring. Interval containment below is a consistency check only.
    names = list(points)
    noncontacts = []
    for j, name in enumerate(names):
        x, y = points[name]
        for earlier in names[:j]:
            xx, yy = points[earlier]
            distance2 = (x-xx)**2 + (y-yy)**2
            if edge(name, earlier) in exact_contacts:
                assert distance2.lo <= 4 <= distance2.hi
            else:
                assert distance2.lo > 4
                noncontacts.append(distance2)
    assert len(noncontacts) == 85
    # Containment equalities are likewise exact from |A_i|=a and
    # |h*n_i +/- J*n_i|**2=h*h+1=B*B.
    for name, (x, y) in points.items():
        target = a**2 if name[0] == "A" else B**2
        radius2 = x**2 + y**2
        assert radius2.lo <= target.hi and target.lo <= radius2.hi
    smallest_lower_bound = min(value.lo for value in noncontacts)
    assert smallest_lower_bound > 4
    print("Candidate feasibility: 20 exact square contacts; 85 noncontacts > 2.")
    print("  Smallest certified noncontact squared-distance lower bound:",
          float(smallest_lower_bound))


if __name__ == "__main__":
    exact_identities()
    candidate_radius = pentagon_certificate()
    table2()
    construction_certificate(candidate_radius)
    print("PASS: identities, Proposition 7.2 constants, Table 2 and feasibility of P15.")
