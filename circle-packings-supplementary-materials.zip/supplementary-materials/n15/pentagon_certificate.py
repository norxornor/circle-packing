#!/usr/bin/env python3
"""Exact certificates for two auxiliary n=15 circle-packing statements.

This program checks the following geometric inequalities. The remaining
parts of the optimality proof are checked by verify.py:

1. The diameter estimates used in the distinct-boundary-gap lemma, conditional
   on the radial normalization and shadow inequality stated below.
2. Feasibility of the proposed fifteen-centre configuration: its twenty contact
   distances are exact identities and its other eighty-five distances exceed 2.

Only Python's standard library is used. All bounds are Fractions. Floating-point
conversion occurs only when printing results, never in an assertion.

Distinct-gap lemma assumptions and proof
----------------------------------------
Let B=sqrt(6+2/sqrt(5)+4*sqrt(1+2/sqrt(5))) and eta=asin(1/B).
Assume a separated fifteen-point configuration has ten points on radius B and
five interior points with radii below c=B-4/B. Define ell=B-2 and
  h(r)=0 for r<=ell, otherwise acos((B*B+r*r-4)/(2*B*r));
  f(r)=max(h(r)-eta,0).
Assume the shadow inequality sum(f(r_i))<=S=pi-10*eta.

The maximum boundary gap is 2*A, where A=pi-9*eta. Since h is increasing on
[ell,c], every interior radius is at most
  u=B*cos(A)-sqrt(4-B*B*sin(A)**2).
Set alpha=eta+S/4, s=B*cos(alpha)-sqrt(4-B*B*sin(alpha)**2), v=2-s.
If r_i<v, the other four radii exceed s by the triangle inequality, contradicting
sum f<=S. Therefore v<=r_i<=u.

Rotate a boundary gap to have endpoints at angles +/-a, a<=A. Replacing those
endpoints by P_+/-=B*(cos(A),+/-sin(A)) increases their distances to every point
in the original gap: both angular differences increase and stay below pi.
In the upper half of the enlarged gap, a feasible point (x,y) obeys
  x<=F(y)=B*cos(A)-sqrt(4-(y-B*sin(A))**2).
Indeed x<=u<B*cos(A), so the other branch is excluded. The square root is real:
0<=y<=u*sin(A)<B*sin(A)<2. The wedge gives x>=y*cot(A). The function F is
decreasing on that interval and intersects this line at y=ell*sin(A), so
0<=y<=ell*sin(A). Also F''>0, so F lies below its endpoint chord from
U=(u,0) to L_+=ell*(cos(A),sin(A)). Finally r>=v gives x>=v*cos(A).
Reflection gives containment in the convex pentagon with vertices
  U, L_+/-, V_+/-, where V_+/-=v*(cos(A),+/-sin(A)).
All six classes of its vertex distances are strictly less than 2, as checked
below. The diameter of a convex polygon equals a distance between vertices.
Thus no closed boundary gap contains two interior points. This includes points
on a boundary ray, so consecutive interior rays have a boundary ray strictly
between them.

Feasible fifteen-centre construction
------------------------------------
Put q=pi/5, a=csc(q), t=cot(q), h=t+2, and let J rotate by pi/2.
For i modulo 5, define
  A_i=a*e(2*i*q), n_i=e((2*i+1)*q), tau_i=J*n_i,
  B_i^-=h*n_i-tau_i, B_i^+=h*n_i+tau_i.
The identities A_i=t*n_i-tau_i and A_(i+1)=t*n_i+tau_i give five squares of
side 2, producing exactly twenty contacts. The noncontact checks below use
radical coordinates and exact interval arithmetic. Alternatively, all distances
follow analytically: if eta=atan(1/h), outer angular gaps alternate between
2*eta and 2*q-2*eta. Because h=t+2>t+a=cot(q/2), eta<q/2, so every outer distance
is at least 2*B*sin(eta)=2. The inner pentagon has edge 2. The least angular
separation between an inner and outer point is q-eta, at the exact square
contacts; distance for fixed radii increases with angle in [0,pi].
"""

from fractions import Fraction as Q
from math import isqrt


class Interval:
    """Closed interval with exact rational endpoints."""

    def __init__(self, lo, hi=None):
        self.lo = Q(lo)
        self.hi = Q(lo if hi is None else hi)
        assert self.lo <= self.hi

    def __add__(self, other):
        other = interval(other)
        return Interval(self.lo + other.lo, self.hi + other.hi)

    __radd__ = __add__

    def __neg__(self):
        return Interval(-self.hi, -self.lo)

    def __sub__(self, other):
        return self + -interval(other)

    def __rsub__(self, other):
        return interval(other) + -self

    def __mul__(self, other):
        other = interval(other)
        products = (self.lo * other.lo, self.lo * other.hi,
                    self.hi * other.lo, self.hi * other.hi)
        return Interval(min(products), max(products))

    __rmul__ = __mul__

    def __truediv__(self, other):
        other = interval(other)
        assert other.lo * other.hi > 0
        return self * Interval(1 / other.hi, 1 / other.lo)

    def __rtruediv__(self, other):
        return interval(other) / self

    def __pow__(self, n):
        assert n == 2
        upper = max(self.lo * self.lo, self.hi * self.hi)
        lower = 0 if self.lo <= 0 <= self.hi else min(self.lo**2, self.hi**2)
        return Interval(lower, upper)

    def __repr__(self):
        return f"[{float(self.lo):.16g}, {float(self.hi):.16g}]"


def interval(value):
    return value if isinstance(value, Interval) else Interval(value)


def sqrt(value):
    value = interval(value)
    assert value.lo >= 0
    scale = 10**35
    lo = isqrt(value.lo.numerator * scale**2 // value.lo.denominator)
    hi = isqrt(value.hi.numerator * scale**2 // value.hi.denominator)
    return Interval(Q(lo, scale), Q(hi + 1, scale))


def atan_point(value, terms=30):
    assert 0 <= value < 1
    total = sum(((-1)**k * value**(2*k + 1) / Q(2*k + 1)
                 for k in range(terms)), Q(0))
    remainder_bound = (-1)**terms * value**(2*terms + 1) / Q(2*terms + 1)
    return Interval(min(total, total + remainder_bound),
                    max(total, total + remainder_bound))


def trig_point(value, cosine=False, terms=18):
    # For this domain even the initial absolute Taylor terms decrease.
    assert 0 <= value <= Q(11, 8)
    term = Q(1) if cosine else value
    total = term
    for k in range(1, terms):
        denominator = (2*k - 1)*(2*k) if cosine else (2*k)*(2*k + 1)
        term *= -value*value / Q(denominator)
        total += term
    denominator = ((2*terms - 1)*(2*terms) if cosine
                   else (2*terms)*(2*terms + 1))
    next_term = term * (-value*value / Q(denominator))
    return Interval(min(total, total + next_term), max(total, total + next_term))


def sin(value):
    # [0,11/8] lies inside the interval of increase [0,pi/2].
    value = interval(value)
    return Interval(trig_point(value.lo).lo, trig_point(value.hi).hi)


def cos(value):
    value = interval(value)
    return Interval(trig_point(value.hi, True).lo,
                    trig_point(value.lo, True).hi)


def asin(value):
    value = interval(value)
    assert 0 < value.lo <= value.hi < Q(4, 5)
    lo, hi = Q(0), Q(1)
    for _ in range(100):
        mid = (lo + hi) / 2
        sine = trig_point(mid)
        if sine.hi < value.lo:
            lo = mid
        elif sine.lo > value.hi:
            hi = mid
        else:
            break
    return Interval(lo, hi)


def inside(value, lo, hi):
    assert Q(lo) < value.lo <= value.hi < Q(hi)


def pentagon_certificate():
    pi = 16*atan_point(Q(1, 5)) - 4*atan_point(Q(1, 239))
    z = 2 / sqrt(5)
    B = sqrt(6 + z + 4*sqrt(1 + z))
    eta = asin(1 / B)
    S, A, ell = pi - 10*eta, pi - 9*eta, B - 2

    def radial_inverse(angle):
        return B*cos(angle) - sqrt(4 - B**2*sin(angle)**2)

    u = radial_inverse(A)
    s = radial_inverse(eta + S/4)
    v = 2 - s
    c = B - 4/B
    E = sqrt(B**2 - 1) - sqrt(3)
    assert 2 < c.lo and c.hi < Q(5, 2)
    assert (c - 4/c).hi < 1
    assert (10*eta).hi < pi.lo and pi.hi < (11*eta).lo
    assert 0 < E.lo and E.hi < c.lo
    assert (c**2 - E**2).hi < 4
    inside(c, Q(2385, 1000), Q(2386, 1000))
    inside(E, Q(1644, 1000), Q(1645, 1000))
    assert B.lo * B.lo - 4 > c.hi * c.hi  # h increases up to c.
    assert 0 < v.lo < v.hi < ell.lo < ell.hi < u.lo < u.hi < c.lo
    assert u.hi < (B*cos(A)).lo
    assert (B*sin(A)).hi < 2
    inside(u, Q(2220, 1000), Q(2221, 1000))
    inside(v, Q(281, 1000), Q(283, 1000))
    inside(ell, Q(1521, 1000), Q(1522, 1000))
    inside(A, Q(550, 1000), Q(551, 1000))

    distances_squared = {
        "U--V": u**2 + v**2 - 2*u*v*cos(A),
        "U--L": u**2 + ell**2 - 2*u*ell*cos(A),
        "L+--L-": 4*ell**2*sin(A)**2,
        "V+--V-": 4*v**2*sin(A)**2,
        "L--opposite V": ell**2 + v**2 - 2*ell*v*cos(2*A),
        "L--same-side V": (ell-v)**2,
    }
    print("Exact rational interval certificate for the auxiliary pentagon:")
    for name, value in (("B", B), ("eta", eta), ("A", A), ("u", u), ("v", v)):
        print(f"  {name} = {value}")
    for name, value in distances_squared.items():
        assert value.hi < 4
        print(f"  {name} squared = {value}; upper endpoint < 4")
    return B


def construction_certificate(B):
    root5 = sqrt(5)
    cq = (root5 + 1)/4
    sq = sqrt(10 - 2*root5)/4
    c2q = (root5 - 1)/4
    s2q = sqrt(10 + 2*root5)/4
    a, t = 1/sq, cq/sq
    h = t + 2
    assert a.hi < 2  # Gives eta<q/2 in the analytic feasibility proof.

    def rotate(point):
        x, y = point
        return c2q*x - s2q*y, s2q*x + c2q*y

    points = {}
    inner = (a, Interval(0))
    normal = (cq, sq)
    for i in range(5):
        points[("A", i)] = inner
        nx, ny = normal
        points[("-", i)] = (h*nx + ny, h*ny - nx)
        points[("+", i)] = (h*nx - ny, h*ny + nx)
        inner, normal = rotate(inner), rotate(normal)

    def edge(x, y):
        return frozenset((x, y))

    exact_contacts = set()
    for i in range(5):
        exact_contacts.update((
            edge(("A", i), ("A", (i+1) % 5)),
            edge(("-", i), ("+", i)),
            edge(("A", i), ("-", i)),
            edge(("A", (i+1) % 5), ("+", i)),
        ))
    assert len(exact_contacts) == 20
    # The twenty contact equalities are proved by the square identities in the
    # module docstring. Interval containment below is a consistency check only.
    names = list(points)
    noncontacts = []
    for j, name in enumerate(names):
        x, y = points[name]
        for earlier in names[:j]:
            xx, yy = points[earlier]
            distance2 = (x-xx)**2 + (y-yy)**2
            if edge(name, earlier) in exact_contacts:
                assert distance2.lo <= 4 <= distance2.hi
            else:
                assert distance2.lo > 4
                noncontacts.append(distance2)
    assert len(noncontacts) == 85
    # Containment equalities are likewise exact from |A_i|=a and
    # |h*n_i +/- J*n_i|**2=h*h+1=B*B.
    for name, (x, y) in points.items():
        target = a**2 if name[0] == "A" else B**2
        radius2 = x**2 + y**2
        assert radius2.lo <= target.hi and target.lo <= radius2.hi
    smallest_lower_bound = min(value.lo for value in noncontacts)
    assert smallest_lower_bound > 4
    print("Candidate feasibility: 20 exact square contacts; 85 noncontacts > 2.")
    print("  Smallest certified noncontact squared-distance lower bound:",
          float(smallest_lower_bound))


if __name__ == "__main__":
    candidate_radius = pentagon_certificate()
    construction_certificate(candidate_radius)
    print("PASS: geometric constants, gap diameter, and candidate feasibility.")
