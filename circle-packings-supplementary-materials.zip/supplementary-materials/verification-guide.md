# Verification guide

Every statement in the paper whose truth depends on a computation is listed
here with the program (and driver stage) that checks it. Stage names are those
printed by `verify.py`. Statements that are proved in the text by algebra or
analysis (for example Lemmas 2.1-2.8, 3.1-3.4, 4.1, 5.1-5.6, the derivative
formulas and the construction identities) are not computations; where code
re-checks such an identity exactly it is listed as well.

## Section 1
| Statement | Check |
|---|---|
| Table 1: R_15, ..., R_20 to the nearest 10^-9 | `check_shared_claims.py::table_1` (SHARED) |
| Theorem 1.1: b16, b17, b20 are roots of (8.5), (9.6), (11.3) in their intervals; uniqueness for 17, 20 | `n16/certify_construction16.py` (C16), `n17/verify17_exact.py` (C17), `n20/verify20_exact.py` (C20) |
| (1.2) equals Q6 plus b18 e(theta); feasible for every theta in [pi/6, pi/3]; theta = pi/6, pi/4 not congruent | `n18/check_references18.py::family` (T18) |
| every z with norm <= 17/100 lies in A | `n20/verify20_exact.py` (C20): all 19 noncentral radii > 2.17, 0.17 < b20 |

## Section 4
| Statement | Check |
|---|---|
| 4.5 example: 1.2 + 1.1 = 2.3, 2.3 + 4.0 = 6.3 > 6.284 > 2 pi | `check_shared_claims.py::section_4_5` (SHARED) |
| 4.6: pi < 355/113 | every inner-count program `constants_check` (E15-E18), `n20/energy_integer_validate.py` |
| 4.4 / B.3 angle certification | every angle validator (R*.bounds, E20.bounds) |
| 4.7 Proposition 4.2 coverage: every box excluded or accepted, tree identity | every search program (asserts), driver exact `TOTAL` lines |

## Section 5
| Statement | Check |
|---|---|
| 5.5 example: inverse, stress (1/3,1/3,1/3), row sums 4/3 | `check_shared_claims.py::section_5_5` (SHARED) |
| Lemma 5.6 / (5.26) residual certificates | `n16/certify_local16.py`, `n17/certify_local17.py`, `n18/certify_m10.py`, `n18/certify_m11_limits.py`, `n18/certify_local18.py`, `n20/certify_local20.py`; independently `check_reference_certificates.py` |

## Section 7 (N = 15)
| Statement | Check |
|---|---|
| (gamma+1)(4gamma^2-2gamma-1); (7.4) a^2 = 2+2/sqrt5, t^2 = 1+2/sqrt5; (7.5); a < 2; 1 < t < 3/2 | `n15/pentagon_certificate.py::exact_identities` (G15) |
| Lemma 7.1 feasibility of P15 (20 contacts, 85 noncontacts > 4, containment) | `n15/pentagon_certificate.py::construction_certificate` (G15) |
| Prop 7.2: 3.5213569 < b15 < 3.521357, .287943 < eta < .287944, Lemma 2.6 and (4.7) hypotheses, 11 eta > pi, 8 arcsin(1/2.386) > pi, 2.386 - 4/2.386 < 1 | `constants.py` (C0) |
| Prop 7.2: (3.9) for m = 10 (each condition), (7.8), 2.385 < c < 2.386 | `n15/pentagon_certificate.py::pentagon_certificate` (G15) |
| Counts m <= 10, k <= 8, 5 <= k <= 8 | `constants.py` (C0, Table 16) |
| Prop 7.3: k = 6, 7, 8 excluded; 1819, 1149, 81 boxes | `n15/inner_energy_certificate.py` (E15); counts in CONSISTENCY |
| Table 2 printed bounds, the worked value 3.95468237582, all < 4 | `n15/pentagon_certificate.py::table2` (G15) |
| 126 compositions, 16 representatives | `check_compositions.py` (ORDERS); search asserts |
| Prop 7.4: start box, 1307 bounds, 63 846 boxes, 175 accepted, target (2,2,2,2,2), [1.693, 1.709] | `n15/radial_integer_validate.py` (R15.bounds, R15.params), `n15/radial_integer.cpp` (R15.paramcheck, R15) |
| (7.15), Appendix E, Lemma 7.5 bounds, chi > 2/3, 2chi/5 - 20eps > 1/6 | `n15/additive_estimates.py` (L15) |

## Section 8 (N = 16)
| Statement | Check |
|---|---|
| A.1 endpoints; both in (3.61542559487319, 3.61542559487320) | `n16/check_printed_bounds.py` (G16.printed) |
| Prop 8.1: domains, endpoint signs, 21 contacts and 99 other pairs > .15861, inner radii < c | `n16/certify_construction16.py` (C16); contact list by label in REFERENCE |
| Prop 8.2: Table 14/15 data, 12 eta > pi, 8 arcsin(1/2.510) > pi, 2.510 - 4/2.510 < 1 | `constants.py` (C0) |
| Prop 8.2: (3.9) for m = 11 (each condition), (8.7), vertex distances < 2.512607 | `n16/certify_geometry16.py` (G16) |
| Prop 8.3: k = 6, 7, 8 excluded | `n16/energy16.py` (E16); counts in CONSISTENCY |
| 210 vectors, 26 representatives; Prop 8.4 targets (8.8), 4805 bounds, 44 580 boxes, 190 accepted | ORDERS; `n16/radial_integer_validate.py` (R16.bounds, R16.params), R16.paramcheck, R16 |
| (8.9) order; Prop 8.5, Table 3, Appendix D.1 (Table 21, both chains, printed comparisons) | `n16/coordinate_nearness.py` (P16); Table 3 rows in CONSISTENCY |
| Prop 8.6: kappa = 5, sigma* = 1/250, residual < 1e-10, threshold 1/10000 | `n16/certify_local16.py` (L16) |
| Prop 8.7 (8.11) | `n16/certify_construction16.py` (C16); independently REFERENCE |

## Section 9 (N = 17)
| Statement | Check |
|---|---|
| Prop 9.1: domains, signs, F17' < 0, 25 contacts (list (9.7)), 111 pairs > .1412526818, b^2 - norm^2 > 7.8901595432 | `n17/verify17_exact.py` (C17); contact list by label in REFERENCE |
| Prop 9.2: Table 14/15 data, 12 eta > pi, 9 arcsin(1/2.738) > pi, (2.738 - 4/2.738)^2 < 2 | `constants.py` (C0) |
| Prop 9.2: eta > .266867098322829, omega_11^+, (9.9) each condition including 0 < omega_11 | `n17/validate_angles.py::constants` (R17.bounds) |
| Prop 9.3: k = 8, ..., 11 excluded | `n17/energy17.py` (E17); counts in CONSISTENCY |
| 4368 / 8008 vectors, 392 / 600 representatives | ORDERS; search asserts |
| Prop 9.4: start boxes [0, 2.368], [0, 2.738]; targets (9.11), (9.12); reversal statements; counts | `n17/validate_angles.py` (R17.*.params), R17.*.paramcheck, R17.11, R17.10 |
| (9.13); Prop 9.5, Table 4, Appendix D.2 | `n17/coordinate_nearness17.py` (P17); Table 4 rows in CONSISTENCY |
| Prop 9.6: kappa = 8, sigma* = 1/250, threshold 1/16000 | `n17/certify_local17.py` (L17) |

## Section 10 (N = 18)
| Statement | Check |
|---|---|
| (10.1), (10.2), P18 feasible, P18 plus O feasible | `n18/check_references18.py` (T18); `n18/exact18.py` (C18, ring18) |
| eta = pi/12, c = 2 sqrt2 | T18; `n18/validate_angles.py` |
| Prop 10.1, m <= 12, k <= 12 | `constants.py` (C0) |
| Prop 10.2: k = 9, ..., 12 excluded | `n18/energy18.py` (E18); counts in CONSISTENCY |
| 10.3: four contact angles; Table 5 rows via (10.5); (10.6); Q3 example; omitted directions; field example | T18 |
| Prop 10.3, Table 6 | `n18/exact18.py` (C18) |
| Table 7 example (merged counts give Q3) | T18 |
| Prop 10.4: start range, acceptance windows, templates from Table 5, counts | `n18/validate_angles.py` (R18.*.params), R18.*.paramcheck, R18.11, R18.10 |
| Prop 10.5, Table 8, thresholds 1/1536, 1/2400, 1/2240 | `n18/certify_m10.py`, `n18/certify_m11_limits.py`, `n18/certify_local18.py` (L18.*) |
| Prop 10.6, Table 9, Appendix F (Table 24, b18 and c bounds), Lemma 10.7, Table 10 | `n18/certify_bridges18.py` (P18) |
| 10.7: Q6 contact between directions 0 and pi/12 | T18 |
| Table 26 order | T18; independently REFERENCE |

## Section 11 (N = 20)
| Statement | Check |
|---|---|
| Prop 11.1: domains, signs, F20' > 16.035, 26 contacts, 164 pairs > .2346221317, slack > 9.1237296549, radii > 2.17 | `n20/verify20_exact.py` (C20); contact list by label in REFERENCE |
| Prop 11.2: Table 14/15 data, 13 eta > pi, 10 arcsin(1/3.151994) > pi, 3.151994 - 4/3.151994 < 2 | `constants.py` (C0) |
| Prop 11.2: eta > .245026263334771, omega_12^+, (11.7) each condition including 0 < omega_12 | `n20/validate_angles.py::constants` (R20.bounds) |
| Prop 11.3: k = 9, ..., 14 excluded; start [0, 3.151994] rounded outward | `n20/energy_integer_validate.py` (E20.bounds, E20.params), E20.paramcheck, E20 |
| (11.8): K radius below 2.806 | `n20/coordinate_nearness20.py` (P20) |
| Prop 11.4: 50 388 vectors, 3260 representatives, Table 11, 26 878 bounds, 5 822 866 boxes, 5406 accepted | `n20/validate_angles.py` (R20.params), R20.paramcheck, R20 |
| (11.9); Prop 11.5, Table 12, Appendix D.3; (11.10) | `n20/coordinate_nearness20.py` (P20); Table 12 rows in CONSISTENCY |
| Prop 11.6: kappa = 7, sigma* = 1/150, threshold 1/8400 | `n20/certify_local20.py` (L20) |
| Prop 11.7 | `n20/verify20_exact.py` (C20); independently REFERENCE |

## Section 12
| Statement | Check |
|---|---|
| c(2s) = 2(s - 1/s); b = 1 + sqrt5 gives c(b) = 2 | `check_shared_claims.py::section_12` (SHARED) |

## Appendices
| Statement | Check |
|---|---|
| A.2, Table 13 (endpoint enclosures, radicand and divisor margins, derivative enclosures; 4, 5, 4 radicands) | `certificate_summary.py` (SUMMARY) |
| A.3, Tables 14-16, (A.1); Table 17 coverage of every count | `constants.py` (C0); Table 17 vs Table 18 in CONSISTENCY |
| B.2 tail conditions for degrees 25, 26, 27, 29, 34, 37 | `exact_arithmetic.py` (asserted on import), `constants.py` |
| B.4 Machin identity steps, (B.6), (B.7) | `check_shared_claims.py::appendix_b` (SHARED) |
| C: Tables 18-20 | CONSISTENCY, driver exact lines, validators' parameter lines |
| D.1-D.3 | P16, P17, P20 |
| E | L15 |
| F, Table 24 | P18 |
| G: Tables 25, 27, scales Q_P, Q_V; contact-row order | REFERENCE; the certificates themselves |
| G: Table 28 | SUMMARY |
| H.3 grids and 4 * 2^40 * 10^15 < 2^92; radius numerators < 4 * 2^40 | SHARED; every validator's `parameters` |

## Constants used by the compiled searches
Every constant of `radial_integer.cpp` (N = 15, 16, 17, 18, 20) and
`energy_integer.cpp` is printed by the program on a `PARAMETERS` line. The
corresponding validator derives the same line from the values printed in the
paper, asserting each rounding direction (start boxes outward, acceptance
windows inward, pi and eta bounds in the safe direction). The driver requires
the two lines to be identical (stages `*.params`, `*.paramcheck`, and again in
the replay itself). The position-bound programs import the same targets from
the validators.
