"""Check that invalid data and disabled assertions cause verification failure.
All deliberately changed inputs and compiled programs stay in a temporary directory.
"""
from pathlib import Path
import subprocess,tempfile,shutil,sys
ROOT=Path(__file__).resolve().parent
results=[]
def failed(label,args,cwd):
    r=subprocess.run(args,cwd=cwd,capture_output=True,text=True)
    assert r.returncode!=0,(label,'unexpected success')
    results.append(label)
with tempfile.TemporaryDirectory(prefix='circle-failure-checks-') as td:
    td=Path(td);copies=td/'checks';shutil.copytree(ROOT,copies)
    for n in (15,16,17,18,20):
        file={15:'radial_integer_validate.py',16:'radial_integer_validate.py'}.get(n,'validate_angles.py')
        directory=copies/f'n{n}';script=directory/file
        source=next(directory.glob('*angles*.tsv'));rows=source.read_text().splitlines()
        bad=directory/'invalid.tsv';x,y,_=rows[0].split()
        bad.write_text(f'{x}\t{y}\t{3*2**40}\n')
        failed(f'n{n}: false angle bound',[sys.executable,'-E','-B',str(script),str(bad)],directory)
        bad.write_text(rows[0]+'\n'+rows[0]+'\n')
        failed(f'n{n}: duplicate angle key',[sys.executable,'-E','-B',str(script),str(bad)],directory)
        bad.write_text('unreadable record\n')
        failed(f'n{n}: malformed angle record',[sys.executable,'-E','-B',str(script),str(bad)],directory)
        failed(f'n{n}: missing angle file',[sys.executable,'-E','-B',str(script),str(directory/'absent.tsv')],directory)
    for n in (16,17,20):
        import json
        directory=copies/f'n{n}';path=directory/f'inverse{n}.json';data=json.loads(path.read_text());data['inverse'][0][0]+=10*data['scale'];path.write_text(json.dumps(data))
        failed(f'n{n}: incorrect inverse array',[sys.executable,'-E','-B',str(directory/f'certify_local{n}.py')],directory)
    for n,args in [(15,[]),(16,[]),(17,['6']),(18,['7']),(20,[])]:
        exe=td/f'n{n}-radial_integer'
        subprocess.run(['g++','-O2','-std=c++17',str(copies/f'n{n}/radial_integer.cpp'),'-o',str(exe)],check=True,capture_output=True)
        empty=td/'empty.tsv';empty.write_text('')
        failed(f'n{n}: missing lookup entry',[str(exe),*args,str(empty)],td)
        failed(f'n{n}: missing table',[str(exe),*args,str(td/'missing.tsv')],td)
    for n,file in [(15,'radial_integer.cpp'),(16,'radial_integer.cpp'),(17,'radial_integer.cpp'),(18,'radial_integer.cpp'),(20,'radial_integer.cpp'),(20,'energy_integer.cpp')]:
        failed(f'n{n} {file}: disabled assertions',['g++','-std=c++17','-DNDEBUG','-fsyntax-only',str(copies/f'n{n}'/file)],td)
    # A changed constant in a compiled search is caught by the parameter comparison.
    mutations=[(15,'radial_integer.cpp','radial_integer_validate.py',[],'constexpr Z TWO_PI_UP = 6908435304716LL;','constexpr Z TWO_PI_UP = 6908435304715LL;'),
               (16,'radial_integer.cpp','radial_integer_validate.py',[],'181155445LL * RQ + 99999999','181155444LL * RQ + 99999999'),
               (17,'radial_integer.cpp','validate_angles.py',['7'],'192575180443LL','192575180444LL'),
               (18,'radial_integer.cpp','validate_angles.py',['7'],'{ 1, 2, 2, 2, 3, 1 }','{ 1, 2, 2, 3, 2, 1 }'),
               (20,'radial_integer.cpp','validate_angles.py',['8'],'(2806 * RQ + 999) / 1000','(2805 * RQ + 999) / 1000'),
               (20,'energy_integer.cpp','energy_integer_validate.py',[],'constexpr Z PIUP = (355 * AQ + 112) / 113;','constexpr Z PIUP = (355 * AQ) / 113 - 1;')]
    for n,file,validator,vargs,old,new in mutations:
        source=copies/f'n{n}'/file;text=source.read_text();assert text.count(old)==1,(n,file,old)
        mutated=copies/f'n{n}'/('mutated_'+file);mutated.write_text(text.replace(old,new))
        exe=td/f'mutated-{n}-{file}'
        subprocess.run(['g++','-O2','-std=c++17',str(mutated),'-o',str(exe)],check=True,capture_output=True)
        expected=subprocess.run([sys.executable,'-E','-B',str(copies/f'n{n}'/validator),'--parameters',*vargs],cwd=copies/f'n{n}',capture_output=True,text=True,check=True).stdout.splitlines()[-1]
        bargs=[] if n==20 else vargs   # the N=20 programs take no inner count
        got=subprocess.run([str(exe),*bargs,'--parameters'],capture_output=True,text=True,check=True).stdout.strip()
        assert expected.startswith('PARAMETERS ') and got!=expected,(n,file)
        results.append(f'n{n} {file}: altered constant detected by the parameter comparison')
    failed('driver: disabled Python assertions',[sys.executable,'-O',str(ROOT/'verify.py')],ROOT)
    failed('driver: refuses to write into the supplementary directory',[sys.executable,'-E','-B',str(copies/'verify.py'),'--output',str(copies)],copies)
print('\n'.join('PASS '+s for s in results))
print('ALL',len(results),'FAILURE-PATH CHECKS PASSED')
