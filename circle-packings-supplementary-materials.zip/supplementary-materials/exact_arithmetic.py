"""Rational elementary bounds used by several case checks.

All decimal input must first be converted to Fraction.  On [0, 355/113]
the omitted sine/cosine tails below alternate with decreasing magnitudes.
The last retained term therefore determines the direction of each bound.
See the paper's appendices on rational arithmetic and remainders.
"""
from fractions import Fraction as F
from math import isqrt

if not __debug__:
    raise RuntimeError("Assertions are part of the verification; do not use -O.")

TRIG_LIMIT = F(355, 113)


def check_alternating_tail(degree, limit=TRIG_LIMIT):
    """Appendix B.2: after a partial sum of the given degree, the omitted
    terms of the sine/cosine series decrease in absolute value on [0, limit].
    The term of degree n+2 is the term of degree n times -z^2/((n+1)(n+2)).
    Every omitted term has n >= degree, so limit^2 < (degree+1)(degree+2)
    makes every such ratio smaller than 1 in absolute value."""
    assert limit*limit < (degree + 1)*(degree + 2), degree
    return True


# Degrees used for sine (25, 27, 29, 37) and cosine (26, 34), Appendix B.2.
for _degree in (25, 26, 27, 29, 34, 37):
    check_alternating_tail(_degree)


def cosine_lower_26(x):
    """Cosine lower polynomial through degree 26 (last term negative)."""
    assert 0 <= x <= TRIG_LIMIT
    term = F(1)
    total = term
    for j in range(1, 14):
        term *= -x*x / ((2*j - 1)*(2*j))
        total += term
    return total


def cosine_lower_34(x):
    """Cosine lower polynomial through degree 34 (last term negative)."""
    assert 0 <= x <= TRIG_LIMIT
    term = F(1)
    total = term
    for j in range(1, 18):
        term *= -x*x / ((2*j - 1)*(2*j))
        total += term
    return total


def sine_bounds(x):
    """Lower degree-27 and upper degree-29 sine polynomials."""
    assert 0 <= x <= TRIG_LIMIT
    term = x
    total = term
    for j in range(1, 14):
        term *= -x*x / (2*j*(2*j + 1))
        total += term
    return total, total - term*x*x / (28*29)


def sine_upper_37(x):
    """Sine upper polynomial through degree 37 (last term positive)."""
    assert 0 <= x <= TRIG_LIMIT
    term = x
    total = term
    for j in range(1, 19):
        term *= -x*x / (2*j*(2*j + 1))
        total += term
    return total


def sqrt_bounds(x):
    """Enclose a nonnegative rational square root on the 10^-20 grid."""
    assert x >= 0
    scale = 10**20
    n = isqrt(x.numerator*scale*scale // x.denominator)
    lower, upper = F(n, scale), F(n + 1, scale)
    assert lower*lower <= x < upper*upper
    return lower, upper
