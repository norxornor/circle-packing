#!/usr/bin/env python3
"""Exact outward-rounded summaries printed in the construction/matrix appendices.

This repeats the existing rational interval certificates. It neither proposes
data nor changes any search. All rounding below uses fractions and integers.
"""
from pathlib import Path
from fractions import Fraction as F
import importlib.util
import json
import sys

if not __debug__:
    raise RuntimeError('Run without -O: assertions are proof checks.')
ROOT = Path(__file__).resolve().parent


def module(relative):
    path = ROOT / relative
    sys.path.insert(0, str(path.parent))
    spec = importlib.util.spec_from_file_location('summary_' + path.stem, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def rounded(value, places, upper=False):
    """Return an exact decimal, rounded in the specified direction."""
    scale = 10**places
    scaled = value * scale
    integer = -((-scaled.numerator)//scaled.denominator) if upper else scaled.numerator//scaled.denominator
    result = F(integer, scale)
    assert (result >= value) if upper else (result <= value)
    sign = '-' if integer < 0 else ''
    integer = abs(integer)
    return sign + str(integer//scale) + '.' + str(integer % scale).zfill(places)


def root_summary(n):
    relative = 'n16/certify_construction16.py' if n == 16 else f'n{n}/verify{n}_exact.py'
    c = module(relative)
    scale = c.Q if n == 16 else c.D
    endpoints = (c.BL, c.BH) if n == 16 else (c.LO, c.HI)
    construct = c.construction if n == 16 else c.construct
    bounds = (lambda z: (F(z.l, scale), F(z.h, scale))) if n == 16 else (lambda z: (F(z.lo, scale), F(z.hi, scale)))
    # Track the domains of every radical and division in the defining formulas.
    radicals, denominators = [], []
    original_sqrt, original_div = c.I.sqrt, c.I.__truediv__

    def checked_sqrt(value):
        low, _ = bounds(value)
        assert low > 0
        radicals.append(low)
        return original_sqrt(value)

    def checked_div(value, other):
        other = c.I(other) if n == 16 else c.I.co(other)
        low, high = bounds(other)
        assert low > 0 or high < 0
        denominators.append(min(abs(low), abs(high)))
        return original_div(value, other)

    c.I.sqrt, c.I.__truediv__ = checked_sqrt, checked_div
    try:
        construct(c.I(*endpoints))
    finally:
        c.I.sqrt, c.I.__truediv__ = original_sqrt, original_div
    # Scale endpoint values to avoid long runs of zeros in the printed table.
    power = 63 if n == 16 else 27
    values = []
    for endpoint in endpoints:
        low, high = bounds(construct(c.I(endpoint))[0])
        values.append([rounded(low*10**power, 3), rounded(high*10**power, 3, True)])
    assert F(values[0][1]) < 0 < F(values[1][0]) or F(values[1][1]) < 0 < F(values[0][0])
    result = {'power': power, 'endpoint_enclosures': values,
              'radicand_lower': rounded(min(radicals), 3),
              'denominator_absolute_lower': rounded(min(denominators), 3)}
    assert F(result['radicand_lower']) > 0 and F(result['denominator_absolute_lower']) > 0
    if n != 16:
        derivative, _ = construct(c.AD(c.I(*endpoints), c.I(1)))
        low, high = bounds(derivative.d)
        result['derivative_enclosure'] = [rounded(low, 3), rounded(high, 3, True)]
    return result


def matrix_summary():
    data = {}
    for n in (16, 17, 20):
        c = module(f'n{n}/certify_local{n}.py')
        data[str(n)] = c.verify(False)
    c = module('n18/certify_m10.py')
    for j, name in enumerate(('m10_a', 'm10_b', 'm11_lim3', 'm11_lim6', 'm11_lim8'), 1):
        data[f'18,{j}'] = c.verify(name, False)
    data['18,6'] = module('n18/certify_local18.py').verify(False)
    return {name: {'residual_upper_times_1e12': rounded(rho*10**12, 3, True),
                   'inverse_norm_upper': rounded(norm, 5, True),
                   'stress_lower': rounded(stress, 6)}
            for name, (rho, norm, stress) in data.items()}


def main():
    result = {'roots': {str(n): root_summary(n) for n in (16, 17, 20)},
              'matrices': matrix_summary()}
    expected_path = ROOT / 'certificate_summary.json'
    if expected_path.exists():
        assert result == json.loads(expected_path.read_text()), 'Printed certificate summary differs'
    else:
        raise RuntimeError('The exact expected certificate summary is required.')
    print(json.dumps(result, indent=2))
    print('PASS exact printed certificate summaries')


if __name__ == '__main__':
    main()
